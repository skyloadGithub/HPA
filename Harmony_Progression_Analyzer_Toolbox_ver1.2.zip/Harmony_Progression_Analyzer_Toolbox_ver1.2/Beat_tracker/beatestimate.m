function Beats=beatestimate(BeatStrength,sr,hop,startbpm,...
    beat_tightness)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
% Beats=beatestimate(BeatStrength,sr,hop,startbpm,...
%        beat_tightness)
% 
% This function estimates the beat times from the beat strength.
%
% INPUTS  - BeatStrength. The strength of the beat, time windowed by a stft
%         - sr. Sample rate of BeatStrength (note this might have been
%           resampled.
%         - hop. number of samples hopped in BeatStrength
%         - startbpm. The start point of the search.
%         - tightness. How tightly to stick to the startbpm.
%
% OUTPUTS - Beats. The beat times in seconds
%
%---------------------------------------------
%Function created by M. McVicar
%Function revised by Y. Ni
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%% 0. estimating (rough) start BPM %%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Find rough global period (empirically, 0s-90s)
duration_time = 90;  %in seconds
upper_time_zone = 90; %in seconds
bpm_std=0.7;             %the variance of the bpm window
alpha=0.8;           %a update weight for part 3.

% sample rate for specgram frames (due to the hop_length)
fftres=sr/hop;

% Get the lower bound and the upper bound in the beat strength vector
maxcol = min(round(upper_time_zone*fftres),length(BeatStrength));
mincol = max(1,maxcol-round(duration_time*fftres));

% Use auto-correlation out of 4 seconds (empirically set?)
acmax = round(4*fftres);
xcr = xcorr(BeatStrength(mincol:maxcol),BeatStrength(mincol:maxcol),acmax);

% Find local max in the global auto-correlation
rawxcr = xcr(acmax+1+[0:acmax]); %The right side of correlation part

% Creating a hamming like window around default bpm
bpms = 60*fftres./([0:acmax]+0.1);
xcrwin = exp(-.5*((log(bpms/startbpm)/log(2)*bpm_std).^2));

% The weighted auto-correlation
xcr = rawxcr.*xcrwin;

% %Add in 2x, 3x, choose largest combined peak
% lxcr = length(xcr);
% xcr00 = [0, xcr, 0];
% xcr2 = xcr(1:ceil(lxcr/2))+.5*(.5*xcr00(1:2:lxcr)+xcr00(2:2:lxcr+1)+.5*xcr00(3:2:lxcr+2));
% xcr3 = xcr(1:ceil(lxcr/3))+.33*(xcr00(1:3:lxcr)+xcr00(2:3:lxcr+1)+xcr00(3:3:lxcr+2));
% 
% 
% %Get the bpm position of the peak
% if max(xcr2) > max(xcr3)
%   [vv, startpd] = max(xcr2);
%   startpd = startpd -1;
%   startpd2 = startpd*2;
% else
%   [vv, startpd] = max(xcr3);
%   startpd = startpd -1;
%   startpd2 = startpd*3;
% end

% %Get the local max (the picks)
xpks = localmax(xcr);  
%Not include any peaks in first down slope (before goes below
% zero for the first time)
xpks(1:min(find(xcr<0))) = 0;

%Largest local max away from zero
maxpk = max(xcr(xpks));

%Find the position of the first largest pick
startpd = -1 + find((xpks.*xcr) == maxpk);
startpd = startpd(1);

% Choose best peak out of .33 .5 2 3 x this period
candpds = round([.33 .5 2 3]*startpd);
candpds = candpds(candpds < acmax);

[trash,bestpd2] = max(xcr(1+candpds));
startpd2 = candpds(bestpd2);

% %Weight startpd and startpd2
% pratio = xcr(1+startpd)/(xcr(1+startpd)+xcr(1+startpd2));
% if (pratio>0.5)
%     startbpm=(60*fftres)/startpd;
% else
%     startbpm=(60*fftres)/startpd2;
% end

%Always use the faster one
startbpm=(60*fftres)/(min(startpd,startpd2));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% 1. Smooth the BeatStrength %%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%BeatStrength=BeatStrength/std(BeatStrength);

startpd = (60*fftres)/startbpm;
pd = startpd;
  
% Smooth beat events with a gaussian window
templt = exp(-0.5*(((-pd:pd)/(pd/32)).^2));

% convolve the window with the BeatStrength
localscore = conv(templt,BeatStrength);
localscore = localscore(round(length(templt)/2)+[1:length(BeatStrength)]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 2. Initialise  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

backlink = zeros(1,length(localscore));
cumscore = zeros(1,length(localscore));

% search range for previous beat. prange is the number of samples to look
% back and forward
prange = round(-2*pd):-round(pd/2);

% Make a score window, which begins biased towards 120bpm and skewed.
%txwt = (-beat_tightness*abs((log(prange/-pd)).^2));
txwt = exp(-0.5*(beat_tightness*(log(prange/-pd))).^2);


% 'Starting' is 1 for periods of (near) silence.
starting = 1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%% 3. Forwards step  %%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Main forward loop. Go through each window, padding zeros backwards if
% needed, and add the cumulative score to the prior (txwt).
for i=1:length(localscore)
  
  % Move the time window along  
  timerange = i + prange;
  
  % Are we reaching back before time zero?
  zpad = max(0, min(1-timerange(1),length(prange)));

  % Search over all possible predecessors and apply transition 
  % weighting
  scorecands = txwt.*[zeros(1,zpad),cumscore(timerange(zpad+1:end))];
  
  % Find best predecessor beat
  [current_score,beat_location] = max(scorecands);
  
  % Add on local score
  cumscore(i) = alpha*current_score + (1-alpha)*localscore(i);

  % special case to catch first onset. Stop if the local score is small (ie
  % if there's near silence)
  if starting == 1 && (localscore(i) < 0.01*max(localscore));
    backlink(i) = -1; % default
  else
    % found a probable beat, store it and leave the starting/silence
    % scenario.
    backlink(i) = timerange(beat_location); 
    starting = 0;
  end % end silence check
  
end % end i


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%% 4. Find the last beat  %%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% cumscore now stores the score through the song, backlink the best
% previous frame.

% get the median non zero score
maxes=localmax(cumscore);
max_indices=find(maxes);
peak_scores=cumscore(max_indices);

medscore = median(peak_scores);

% look for beats above 0.5 * median
bestendposs = find(cumscore .* localmax(cumscore) > 0.5*medscore);

% The last of these is the last beat (since the score generally increases)
bestendx = max(bestendposs);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%% 4. Backward Step   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% begin on last beat
b = bestendx;

% go while backlink is positive (we set it to be -1 in silence)
while backlink(b(end)) > 0
    % append the previous beat
  b = [b,backlink(b(end))];
end

% Beats are currently backwards, so flip
b = fliplr(b);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% 5. First and last Beats   %%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Look at the beat probabilities themselves to determine the first and last
% beats
% Predicted_beatscores = localscore(b);
% 
% % hamming window the beat scores within 5 beats. Parameter?
% bwinlen = 5;
% Windowed_beatscores = conv(hanning(bwinlen),Predicted_beatscores);
% 
% % take from the start of the window to the end
% z = Windowed_beatscores(floor(bwinlen/2)+1:length(Predicted_beatscores));
% Deviation = 0.5*sqrt(mean(z.^2));
% 
% % Keep only beats from first to last time that 
% % smoothed beat onset times exceeds the threshold
% Beats_frames = b(min(find(z>Deviation)):max(find(z>Deviation)));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 6. Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% return beat times in secs
%Beats = Beats_frames/fftres;
Beats=b/fftres;