function [bts, bpm]=estimate_beats(d,sr,startbpm,tightness)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
% [bts, bpm]=estimate_beats(d,sr,startbpm,tightness)
%
% Get beat times (in seconds) and bpm of a wav file.
%
% INPUTS  
%         - d. The waveform, matlab mono vector.
%         - sr. Waveform sampling rate.
%         - startbpm. The start point of the search.
%         - tightness. How tightly to stick to the startbpm.
%
% OUTPUTS 
%         - bts. vector of beat occurances in seconds.
%         - bpm. Estimate of the beats per minute.
%
% Use "beat tracker" (last argument is 0 for noplot)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Get the beat times
[BeatStrength,options]=calculate_beat_strength(d,sr);
bts=beatestimate(BeatStrength,options.downsample,options.hop_len,startbpm,tightness);

%bts = beat(d,sr,startbpm,tightness,0);

% Estimate bpm as median beat difference. Take round to get integer.
bpm=60/median(diff(bts));

 % Post-processing: if bpm<120, double everything.
if bpm<120
    new_beats=[bts(1)];
    for b=2:length(bts)
        new_beats=[new_beats (bts(b-1)+bts(b))/2 bts(b)];
    end
    bts=new_beats;
end
    
 