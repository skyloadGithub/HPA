function [BeatStrength, options]=calculate_beat_strength(x,sr,downsample,win_len,...
    hop_len, mel_channels)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
%[BeatStrength, estimateBPM, options]=calculate_beat_strength(x,sr,downsample,win_len,...
%                                     hop_len, mel_channels)
% 
% This function calculates the beat strength through a file, which can be fed into
% beatestimate.m to estimate beat positions. 

%Prerquist: hz2mel and mel2hz.
%
% INPUTS  - x. Mono waveform.
%         - sr. Sample rate of x.
%         - downsample. New sample frequency.
%         - win_len. Length of STFT to use.
%         - hop_len. Hop of STFT to use.
%         - mel_channels. Number of Mel bands to use.
%
% OUTPUTS - BeatStrength. The beat strengths.
%         - options. The options used in this function.
%
%---------------------------------------------
%Function created by M. McVicar
%Function revised by Y. Ni
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% defaults
options=struct;
if nargin < 3; downsample=8000; end
if nargin < 4; win_len=256; end
if nargin < 5; hop_len=32; end
if nargin < 6; mel_channels=40; end

options.downsample=downsample;
options.win_len=win_len;
options.hop_len=hop_len;
options.mel_channels=mel_channels;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 1. Resample %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% hcf of new sr and sr
gg=gcd(downsample,sr);

% Resample and use downsample from now on
x=resample(x,downsample/gg,sr/gg);
sr=downsample;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%% 2. FFT Spectra %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

D=specgram(x,win_len,sr,win_len,win_len-hop_len);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%% 3. Get Mel Weights %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Mel parameters
width = 1.0;
minfrq = 0;
maxfrq = sr/2; % Use the Nyquist
htkmel = 0;

% Initialise weights
wts = zeros(mel_channels, win_len);

% Get the normal fft frequencies
fftfrqs=(0:(win_len/2))/win_len*sr;

% Get the centers of the Mel frequencies
mimel_channels = hz2mel(minfrq, htkmel);
maxmel = hz2mel(maxfrq, htkmel);

% binfrqs are the nearest fft frequencies to the mel frequencies 
binfrqs = mel2hz(mimel_channels+(0:(mel_channels+1))/(mel_channels+1)*...
    (maxmel-mimel_channels), htkmel);

% work out weights
for i=1:mel_channels

  fs = binfrqs(i+[0 1 2]);
  
  % scale by width
  fs = fs(2)+width*(fs - fs(2));
  
  % lower and upper slopes for all bins
  loslope = (fftfrqs - fs(1))/(fs(2) - fs(1));
  hislope = (fs(3) - fftfrqs)/(fs(3) - fs(2));
  
  % intersect them with each other and zero
  wts(i,1+(0:(win_len/2))) = max(0,min(loslope, hislope));

end % end i

% Slaney-style mel is scaled to be approx constant E per channel
wts = diag(2./(binfrqs(2+(1:mel_channels))-binfrqs(1:mel_channels)))*wts;

% Make sure 2nd half of FFT is zero
wts(:,(win_len/2+1):win_len) = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%% 3. Use the weights %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Use these weights to convert the fft scale to mel scale
D_mel=wts(:,1:(win_len/2+1))*abs(D);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%% 4. Post Process %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Post-process. Take the non numerically zero part
D_nonzero = max(1e-10,D_mel);

% Convert to dB
D_dB=20*log10(D_nonzero);

% only look at top 80 dB
D_trimmed = max(D_dB, max(max(D_dB))-80);

% Take first difference
D_diff=diff(D_trimmed,1,2);

% Use nonzero part
D_nz=max(0,D_diff);

% Take average over mel bands
D_raw_envelope =mean(D_nz);

% filter with a simple window
D_windowed=filter([1 -1], [1 -.99],D_raw_envelope);

% % Divide by standard deviation
BeatStrength = D_windowed;%D_windowed/std(D_windowed);




