function [chord_bass_MLE_prob] = hmm_train_chord_bass_MLEtransmat(chord_transpositions, bass_transpositions, chord_bass_restriction,pseudo_count_trans)


%1. Configulation
if (nargin<4)
    pseudo_count_trans=0;
end

[nstates,num_bass]=size(chord_bass_restriction);
chord_bass_MLE=zeros(num_bass,num_bass,nstates);
N=length(chord_transpositions);

%2. Count the transitions
for i=1:N
    for k=1:length(chord_transpositions{i})
        temp_chord_seq=chord_transpositions{i}{k};
        temp_bass_seq=bass_transpositions{i}{k};
        if (length(temp_chord_seq)>1 && length(temp_bass_seq)>1)
            for j=2:length(temp_chord_seq)
                if (temp_chord_seq(j)<=nstates && temp_bass_seq(j)<=num_bass && temp_bass_seq(j-1)<=num_bass)
                    if (temp_chord_seq(j)==1)
                        aa=1;
                    end
                    chord_bass_MLE(temp_bass_seq(j),temp_bass_seq(j-1),temp_chord_seq(j))=chord_bass_MLE(temp_bass_seq(j),temp_bass_seq(j-1),temp_chord_seq(j))+1;
                end
            end
        end
    end
end

%3. constraining the chord to bass emission
chord_bass_MLE=chord_bass_MLE+pseudo_count_trans;
for i=1:nstates
    chord_bass_MLE(:,:,i)=chord_bass_MLE(:,:,i).*(repmat(chord_bass_restriction(i,:)',[1,num_bass]));
end

%4. compute the MLE of the chord bass transition probability
chord_bass_MLE_prob=MLE_chord_bassProb(chord_bass_MLE,1000,0.0001);
% temp_MLE=sum(chord_bass_MLE,1);
% temp_MLE=temp_MLE+(temp_MLE==0);
% chord_bass_MLE_prob=chord_bass_MLE./(repmat(temp_MLE,[num_bass,1,1]));