function prob_matrix=MLE_chord_bassProb(observation,maxIter,epsilon)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
%Iterative proportional fitting for MLE estimation of phi1 (bass->bass) 
%and phi2 (chord->bass) probabilities.
%Reference: Sam Roweis, Iterative proportional fitting (lecture note).
%
% INPUTS
%observation - the counts of the (bass(t-1),bass(t),chord(t)) observations.
%maxIter - the maximum number of iterations.
%epsilon - the error epsilon for the log probability.
%
% OUTPUTS
%prob_matrix - the probability matrix.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%1. Configulation
Nbb=sum(observation,3); %n(b,b')
Nbc=sum(observation,2); %n(b,c)
Nb=size(observation,1); %#bass
Nc=size(observation,3); %#chord
Nobs=repmat(sum(observation,1),[Nb,1,1]); %n(b',c)


phi1=Nbb./repmat(sum(Nbb,2),[1,Nb]);    %A. phi1 phi(b,b')
phi2=Nbc./repmat(sum(Nbc,1),[Nb,1,1]);  %B. phi2 phi(b,c)

prob_t=zeros(Nb,Nb,Nc); %p(b|b',c)
prob_matrix=prob_t;     %the output p(b|b',c)
log_prob=0;             %the log likelihood

%2. Update
for i=1:maxIter
    
    %2.1 Calculating the p(b|b',c) matrix
    for b1=1:Nb
        for b2=1:Nb
            for c=1:Nc
                prob_t(b1,b2,c)=phi1(b1,b2)*phi2(b1,1,c);
            end
        end
    end
    
    %Normalization
    prob_t=prob_t./(repmat(sum(prob_t,1),[Nb,1,1]));
    
    %2.2 Calculating the log likelihood
    temp=sum(sum(sum(log(prob_t+eps*(prob_t==0)).*observation)));
%    disp(temp);
    if(abs(temp-log_prob)<epsilon)
        break;
    else
        log_prob=temp;
    end
    
    %2.3 Update phi1 and phi2
    %prob_t=prob_t.*observation;
    prob_bb=sum(Nobs.*prob_t./(repmat(phi1+(phi1==0),[1,1,Nc])),3);%sum(sum(prob_t,3)./(phi1+(phi1==0)),1);
    phi1=Nbb./(prob_bb+(prob_bb==0));%Nbb./repmat(prob_bb,Nb,1);
    
    prob_bc=sum(Nobs.*prob_t./(repmat(phi2+(phi2==0),[1,Nb,1])),2);%sum(sum(prob_t,2)./(phi2+(phi2==0)),1);
    phi2=Nbc./(prob_bc+(prob_bc==0));%Nbc./(repmat(prob_bc,[Nb,1,1]));
end

%3. output p(b|b',c)
for b1=1:Nb
    for b2=1:Nb
        for c=1:Nc
            prob_matrix(b1,b2,c)=phi1(b1,b2)*phi2(b1,1,c);
        end
    end
end
prob_matrix=prob_matrix./(repmat(sum(prob_matrix,1),[Nb,1,1]));


return;


    