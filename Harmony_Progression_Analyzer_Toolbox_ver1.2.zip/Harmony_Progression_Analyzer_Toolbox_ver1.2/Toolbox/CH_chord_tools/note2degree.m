%
%NOTE2DEGREE convert a note to a degree w.r.t. a given root
% 
% [degree,success,errormessage] = note2degree(note,root,{octave},{verbose})
% 
% Converts a note string to a degree with respect to a given root note.
% Optional value octave gives octave offset to account for extended
% intervals.
% 
% Success = 1 if note converted correctly, 0 otherwise.
% 
% Optional argument octave defaults to 0.  
% 
% If optional argument 'verbose' is 1, function prints any errormessage to 
% the screen.
% 
% calls: note2fifthposition
%
% returns:  degree (string)
%           success (boolean)
%           errormessage (string)
% 
%
% Author: Christopher Harte,  September 2005
% 
% Copyright: Centre for Digital Music, Queen Mary University of London 2005 
%
% This file is part of the C4DM Chord Toolkit.  
%
% The C4DM Chord Toolkit is free software; you can redistribute it and/or 
% modify it under the terms of the GNU General Public License as published 
% by the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% The C4DM Chord Toolkit is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with the C4DM Toolkit; if not, write to the Free Software
% Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

%		
function [degree,success,errormessage] = note2degree(note, root,octave, verbose)

% set verbose default to 0
if nargin < 3
   octave = 0; 
   verbose = 0;

elseif nargin < 4
   verbose = 0;
end

errormessage = '';
success = 1;
degree = '';

% interval translations on the line of fifths
fifthtranslations = [1,5,2,6,3,7,4];


% get note and root natural position and accidentals on line of fifths 
[noteposition, success1,error1] = note2fifthposition(note);
  
[rootposition, success2,error2] = note2fifthposition(root);

if success1 && success2

    % take the difference between the two note positions for relative positions
    % of notes with respect to one and other
    fifthsdifference = noteposition - rootposition + 1;

    % natural difference on line of fifths
    fifthsinterval = mod((fifthsdifference-1),7);

    i=0;

    % find number of accidentals apart on line of fifths
    if fifthsdifference < 0 % if above 0 then either natural or sharp

      %if final position is negative then calculate number of flats
        % remembering to include the extra first flat (-1)
        accidentals = fix((fifthsdifference+1)/7) -1;
    
    else
        % note is a natural or has a number of sharps
        accidentals = fix(fifthsdifference/7);

    end


    % put the required number of sharps or flats into the output string
    if accidentals > 0
        
        for i=1:accidentals
            
           degree = ['#' degree];
            
        end
        
    elseif accidentals <=0
        
        for i=1:abs(accidentals)
            
           degree = ['b' degree];
            
        end
    end    
    
    
    % find interval value from translation array
    interval = fifthtranslations(fifthsinterval+1);

    if octave >= 0
        interval = interval + 7.*octave;
    else
        success = 0;
        errormessage = 'Error in note2degree: Octave argument is negative';
    end



    degree = [degree num2str(interval)];

else
    success = 0;
    errormessage = [error1 error2];
end
    
if (success == 0) && (verbose == 1)   
    fprintf(1,errormessage);
end  


