%
%ADDSHORT2LIST Combine degrees of a shorthand with another degree list
% 
% [fulldegreelist, success, errormessage] = addshort2list(shorthand, degreelist, {verbose})
% 
% Combine shorthand and degreelist to form full degree list for a chord.  
% Takes into account the omit degree character '*' in producing final list.
% 
% Success = 1 if shorthand and degreelist combined correctly, 0 otherwise.
% 
% If optional argument 'verbose' is 1, function prints any errormessage to 
% the screen.
% 
% returns:  fulldegreelist (string)
%           success (boolean)
%           errormessage (string)
%
% Author: Christopher Harte,  August 2005
% 
% Copyright: Centre for Digital Music, Queen Mary University of London 2005 
%
% This file is part of the C4DM Chord Toolkit.  
%
% The C4DM Chord Toolkit is free software; you can redistribute it and/or 
% modify it under the terms of the GNU General Public License as published 
% by the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% The C4DM Chord Toolkit is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with the C4DM Toolkit; if not, write to the Free Software
% Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

%
function [fulldegreelist, success, errormessage] = addshort2list(shorthand, degreelist, verbose)

% set verbose default to 0
if nargin < 3
    verbose = 0;
end

errormessage = '';

% initialise variables
fulldegreelist = '';
shortintervals = [];
degreeintervals = [];
addlist = [];
success = 1;

% convert shorthand string to list of degrees
[shortdegrees, ok, errors]  = shorthand2degrees(shorthand);

if ok
    % if that works convert the shorthand degrees and degreelist to
    % intervals and accidentals
    
    % add the implied 1 interval to the shorthand list
    if isempty(shortdegrees)
        rootinterval = '1'; % no comma if shorthand is empty
    else
        rootinterval = '1,'; % comma shows that there are further degrees after this one
    end
        
    
    [shortintervals, ok, errors] = parsedegreelist([rootinterval shortdegrees]); 

    if (ok)

      
      % this part of the algorithm finds all the present intervals and sorts
      % them into ascending numeric order
  
      % First put the shorthand intervals into the full list
      
      [ilength,y] = size(shortintervals);
   
      for index = 1:ilength
          % convert interval to a semitone value  
          semitone = interval2semitone(shortintervals(index,1),shortintervals(index,2));
          
          % Using the semitone value as an index will find redundant
          % degrees and also sort them in number order. Multiplying the interval by its
          % presence value leaves either the interval value or 0. Any element 
          % in the array with interval of 0 will be discarded later
          % We add 1 to the semitone value to handle the '1'  or 'unity'
          % interval that would return a 0 semitone value
          
          % record the interval 
          addlist(semitone+1,1) = shortintervals(index,1) .* shortintervals(index,3);
          % record the accidentals as well
          addlist(semitone+1,2) = shortintervals(index,2);
          
      end
    else
        success = 0;
    end

    [degreeintervals, ok2, errors] = parsedegreelist(degreelist);
    ok = ok && ok2;
    
    if ok
      % Now add the degrees from the degreelist taking redundant and 
      % ommitted degrees into account 
      
      [ilength,y] = size(degreeintervals);
   
      for index = 1:ilength
          % convert interval to a semitone value  
          [semitone, ok, errors] = interval2semitone(degreeintervals(index,1),degreeintervals(index,2));
          
          if ok && semitone >= 0
          % record the interval 
          addlist(semitone+1,1) = degreeintervals(index,1) .* degreeintervals(index,3);
          % record the accidentals as well
          addlist(semitone+1,2) = degreeintervals(index,2);
          
          else
             success = 0; 
          end
          
      end
    else
        success=0;
    end
    
    
    % now create fulldegreelist
    if ok

        [ilength,y] = size(addlist);

        for index = 1:ilength

            % if there is a non zero interval in this element, convert 
            % it to a degree symbol and add it to the output list
            if(addlist(index,1) ~=0)

                degreesymbol = interval2degree(addlist(index,1),addlist(index,2));

                if isempty(fulldegreelist)
                    % if this is the first degree then start list
                    fulldegreelist = degreesymbol; 
                else
                    % add to list with a separating comma
                    fulldegreelist = [fulldegreelist ',' degreesymbol];
                end
            end
        end
    else

        success = 0;
        
    end
    
else
    
    success = 0;
    
end


if success == 0
    errormessage = [errors sprintf(['Error in addshort2list: unsuccessful '...
                    'combination  "' shorthand '" and "' degreelist '"\n'])];
    
    if verbose ==1
       fprintf(1,errormessage);
    end
       
       
end   

    