%
%LABREAD read lab file
%
% [times1, times2, labels] = labread(labfile);
% 
% read times and labels from a wavesurfer lab file
% 
% 
% returns: times1 (array of segment start-times)  
%          times2 (array of segment end-times)
%          labels (cell array of label strings)
%
% See also labwrite, mlf2lab, checklabsyntax.
%
% Author: Christopher Harte,  August 2005
% 
% Copyright: Centre for Digital Music, Queen Mary University of London 2005 
%
% This file is part of the C4DM Chord Toolkit.  
%
% The C4DM Chord Toolkit is free software; you can redistribute it and/or 
% modify it under the terms of the GNU General Public License as published 
% by the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% The C4DM Chord Toolkit is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with the C4DM Toolkit; if not, write to the Free Software
% Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
%
		
function [times1, times2, labels] = labread(labfile);

[times1,times2, labels] = textread(labfile, '%f %f %s');

