%
% CHORD2QUALITY return the chord quality of a given chord symbol
% 
% [quality,success, errormessage] = chord2quality(chordsymbol, {verbose})
% 
% Returns the chord quality of a given chord symbol. Quality values are from 
% the enumeration:
%
% 0   Major
% 1   Minor
% 2   Diminished
% 3   Augmented
% 4   Suspended
%
% Success = 1 if symbols parsed correctly, 0 otherwise. 
%
% If optional argument 'verbose' is 1, function prints any errormessage to 
% the screen.
% 
% calls:    getchordinfo
%           short2quality
%           degrees2quality
% 
% returns:  quality (integer)
%           success  (boolean)  
%           errormessage (string)
%
%
% Author: Christopher Harte,  August 2005
% 
% Copyright: Centre for Digital Music, Queen Mary University of London 2005 
%
% This file is part of the C4DM Chord Toolkit.  
%
% The C4DM Chord Toolkit is free software; you can redistribute it and/or 
% modify it under the terms of the GNU General Public License as published 
% by the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% The C4DM Chord Toolkit is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with the C4DM Toolkit; if not, write to the Free Software
% Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

%

function [quality, success, errormessage] = chord2quality(chordsymbol,verbose)

quality = 0;
errormessage = '';

if nargin < 2
    verbose = 0;
end

[rootnote,shorthand,degreelist,bassdegree,success,error] = getchordinfo(chordsymbol);

if success
    
    if ~isempty(shorthand)
    
        [quality, success, error] = short2quality(shorthand);
        
    else
   
        [quality, success, error] = degrees2quality(degreelist);
        
    end
    
end



if(success==0) 

    errormessage = sprintf([error 'Error in Chord2quality: Chord "' chordsymbol '"\n']);
    
    if verbose == 1
        fprintf(1, errormessage);
    end
end