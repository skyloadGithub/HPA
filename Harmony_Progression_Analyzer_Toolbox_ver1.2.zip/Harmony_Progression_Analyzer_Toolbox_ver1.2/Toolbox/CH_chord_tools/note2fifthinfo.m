%
%NOTE2FIFTHINFO find line of fifths natural-position and accidentals
% 
% [position, accidentals, success,errormessage] = note2fifthinfo(note,{verbose})
% 
% Converts a note string to a natural position on the line of fifths and its 
% corresponding number of sharps or flats. 
%
% *** NOTE! *** 
% Reference for natural positions on line of fifths for this function is F = 0.
% 
% Success = 1 if note converted correctly, 0 otherwise.
% 
% If optional argument 'verbose' is 1, function prints any errormessage to 
% the screen.
% 
% calls: parsenote
%
% returns:  position (integer)
%           accidentals (integer)
%           success (boolean)
%           errormessage (string)
% 
%
% Author: Christopher Harte,  September 2005
% 
% Copyright: Centre for Digital Music, Queen Mary University of London 2005 
%
% This file is part of the C4DM Chord Toolkit.  
%
% The C4DM Chord Toolkit is free software; you can redistribute it and/or 
% modify it under the terms of the GNU General Public License as published 
% by the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% The C4DM Chord Toolkit is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with the C4DM Toolkit; if not, write to the Free Software
% Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

%		
function [position,accidentals, success, errormessage] = note2fifthinfo(note, verbose)

% set verbose default to 0
if nargin < 3
   verbose = 0;
end

errormessage = '';
success = 1;
position = '';
accidentals = '';


[natural, accidentals, success, errormessage] = parsenote(note);

if success
    switch(natural)
        case 'F' 
            position = 0;

        case 'C' 
            position = 1;

        case 'G' 
            position = 2;

        case 'D' 
            position = 3;

        case 'A' 
            position = 4;

        case 'E' 
            position = 5;

        case 'B' 
            position = 6;

        otherwise
            errormessage = 'Error in note2fifthinfo: unrecognised natural';
            success=0;
    end
end
        
            
if (success == 0) && (verbose == 1)   
    fprintf(1,errormessage);
end  

