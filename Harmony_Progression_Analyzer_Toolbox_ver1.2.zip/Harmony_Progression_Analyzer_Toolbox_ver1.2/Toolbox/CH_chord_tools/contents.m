% C4DM Chord Symbols Toolkit 
%
% Version 1.0 November 05
% 
%TYPES
% types - help describes types, structures and enumerations used in toolbox
% 
%SYMBOL MANIPULATION FUNCTIONS
% parsechord           - Parse chord symbol to its constituent string elements
% parsenote            - Parse a note string to a natural plus accidentals
% parsedegree          - Parse a degree to an interval plus accidentals
% parsedegreelist      - Parse a degree list to intervals and accidentals 
% degree2semitone      - Convert a degree to equivalent number of semitones
% interval2semitone    - Convert interval + accidentals to semitone value
% interval2degree      - Convert interval + accidentals to a degree string
% degrees2semitones    - Convert a degree list to an array of semitone values
% degree2note          - Convert a degree to correctly spelled note w.r.t. a root
% degrees2quality      - Return the quality of a given degreelist
% note2pitchclass      - Convert a note to a pitchclass value w.r.t middle C
% notes2pitchclasses   - Convert a note list to an array pitchclasses
% note2fifthinfo       - Find line of fifths natural-position and accidentals  
% note2fifthposition   - Find note position on the line of fifths w.r.t. C=0
% notes2fifthpositions - Convert notes list to positions on line of fifths
% note2degree          - Convert a note to a degree w.r.t. a given root
% shorthand2degrees    - Convert a shorthand string to equivalent degreelist
% short2quality        - Return the quality of a given shorthand string
% 
% 
%HIGHER LEVEL FUNCTIONS
% getchordinfo         - Check chord symbol validity and return constituent parts
% syntaxcheck          - Check the syntax and validity of a chord symbol 
% addshort2list        - Combine degrees of a shorthand with another degree list
% chord2quality        - Returns the chord quality of a given chord symbol
% chord2notes          - Convert chord symbol to list of constituent notes
% chord2midinotes      - Generate MIDI note values for a given chord symbol
% chord2pitchclasses   - Convert chord symbol to array of pitch classes
% chord2fifthpositions - Convert chord symbol to pitch positions on line of fifths 
%
%LAB FILE FUNCTIONS
% labread              - Read in times and symbols from a lab file
% labwrite             - Write times and symbols to a lab file
% mlf2lab              - Convert an mlf transcription file to a lab file
% checklabsyntax       - Check the syntax of all chords in a lab file
% checklabs            - Check chord syntax in all lab files in a directory
% 
% Author: Christopher Harte, September 05 
%
% Copyright: Centre for Digital Music, Queen Mary University of London 2005 
%
% This file is part of the C4DM Chord Toolkit.  
%
% The C4DM Chord Toolkit is free software; you can redistribute it and/or 
% modify it under the terms of the GNU General Public License as published 
% by the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% The C4DM Chord Toolkit is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with the C4DM Toolkit; if not, write to the Free Software
% Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
