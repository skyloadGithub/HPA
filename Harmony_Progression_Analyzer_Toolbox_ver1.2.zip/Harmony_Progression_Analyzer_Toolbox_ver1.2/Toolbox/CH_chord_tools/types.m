%
%TYPES for C4DM Chord Toolkit
% 
% Help file on types, structures and enumerations used in chord symbol
% toolbox
% 
%
% *** STRING TYPES ***
%
%NATURAL
% 
% Character A|B|C|D|E|F|G
% 
% 
%MODIFIER
% 
% Character b|#
% 
% 
%NOTE
% 
% Character string containing one natural and optional modifiers. 
% Modifiers may only occur after the natural. 
% 
% note = <natural> | <note> <modifier>
% 
%
%INTERVAL
% 
% Character string containing digits 1|2|3|4|5|6|7|8|9|10|11|12|13
% 
% 
%DEGREE
% 
% Character string containing one interval and optional modifiers.
% Modifiers may only occur before the interval.
% 
% degree =  <interval> | <modifier> <degree>
% 
%
% *** OTHER TYPES ***
% 
%ACCIDENTALS
% 
% signed integer number of sharps or flats.  If positive then denotes 
% sharps, if negative then denotes flats.
% 
% 
%SEMITONE
% 
% Integer value signifying a number of semitone intervals. 
% 
% 
%PITCHCLASS
% 
% Integer value between 0 and 11 enumerating pitch classes with C as
% reference pitch class 0.
% 
% 
%CHORDTYPE
% 
% Enumerates shorthand chordtypes
% 
% 0   maj 
% 1   min 
% 2   dim 
% 3   aug 
% 4   maj7 
% 5   min7 
% 6   7 
% 7   dim7 
% 8   hdim7 
% 9   minmaj7 
% 10  maj6 
% 11  min6 
% 12  9 
% 13  maj9 
% 14  min9 
% 15  sus4 
% 16  sus2
% 
%QUALITY
% 
% Enumerates chord quality
% 
% 0   Major
% 1   Minor
% 2   Diminished
% 3   Augmented
% 4   Suspended
% 
% 
%
%
% Author: Christopher Harte,  August 2005
% 
% Copyright: Centre for Digital Music, Queen Mary University of London 2005 
%
% This file is part of the C4DM Chord Toolkit.  
%
% The C4DM Chord Toolkit is free software; you can redistribute it and/or 
% modify it under the terms of the GNU General Public License as published 
% by the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% The C4DM Chord Toolkit is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with the C4DM Toolkit; if not, write to the Free Software
% Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
%
