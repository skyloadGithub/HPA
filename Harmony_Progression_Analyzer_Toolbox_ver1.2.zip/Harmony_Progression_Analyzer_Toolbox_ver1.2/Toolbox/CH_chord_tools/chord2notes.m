%
%CHORD2NOTES Convert chord symbol to list of constituent notes
% 
% [chordnotes, bassnote, success, errormessage] = chord2notes(chordsymbol, {verbose})
% 
% Converts a chord symbol to a cell array of note strings and a bassnote string.
%
% In the case of the 'no chord' symbol 'N' function returns an empty array
%
% Success = 1 if notes extracted from chordsymbol correctly, 0 otherwise.
% 
% If optional argument 'verbose' is 1, function prints any errormessage to 
% the screen.
% 
% calls:    getnoteinfo
%           parsenote
%           addshort2list
%           degree2note
% 
% returns:  chordnotes  (cell array of note strings)
%           bassnote (string)           
%           success (boolean)
%           errormessage (string)
%
%
% Author: Christopher Harte,  August 2005
% 
% Copyright: Centre for Digital Music, Queen Mary University of London 2005 
%
% This file is part of the C4DM Chord Toolkit.  
%
% The C4DM Chord Toolkit is free software; you can redistribute it and/or 
% modify it under the terms of the GNU General Public License as published 
% by the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% The C4DM Chord Toolkit is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with the C4DM Toolkit; if not, write to the Free Software
% Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

%             
function [chordnotes, bassnote, success, errormessage] = chord2notes(chordsymbol, verbose)

% set verbose default to 0
if nargin < 2
    verbose = 0;
end

errormessage = '';
mainlist = '';
success = 1;
chordnotes = [];
bassnote = '';

% parse the chordsymbol
[rootnote,shorthand,degreelist,bass, success, errormessage] = getchordinfo(chordsymbol);




%if 'no chord' then return N
if (success == 1)
    

    
    if rootnote == 'N'
        
        chordnotes = [];
    else


        % combine shorthand and degreelist and obtain note names for each
        % degree
        if success

            [mainlist, success, errormessage] = addshort2list(shorthand, degreelist);

            if success

                % convert list of degrees to list of notes 
                [chordnotes,success,errormessage] = degrees2notes(mainlist,rootnote);
                 
            end

        end

        % Now find the bass note

        if success

            if ~isempty(bass)

                [bassnote,success,errormessage] = degree2note(bass, rootnote);

                if success
                    
                    ilength = length(chordnotes);
                    index = 1;
                    while index<=ilength
                        
                        % add an extra loop to check the notes of different
                        % size
                        for note=1:ilength
                            if  strcmp(bassnote,chordnotes(index))
                                index = ilength +1;
                                contains = 1;
                                break
                            else
                                contains = 0;
                                index = index +1;
                            end % end if
                        end % end note

                    end % end while
                    
                    if contains == 0
                        
                        chordnotes = [bassnote; chordnotes];
                    end
                end
            else
                bassnote = rootnote;
            end


        end
    end
end

if success == 0
    errormessage = [errormessage sprintf(['Error in chord2notes: Couldn''t convert chord"' chordsymbol '"\n'])];   
    if verbose ==1
       fprintf(1,errormessage);
    end
       
       
end  
    
    
    