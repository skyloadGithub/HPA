%
%NOTE2PITCHCLASS convert a note to a pitchclass value w.r.t middle C
% 
% [pitchclass, success, errormessage] = note2pitchclass(note, {verbose})
% 
% Converts a note string to a pitch class (integer) with C as reference 
% pitch class 0
% 
% Success = 1 if symbols parsed correctly, 0 otherwise.
%
% If optional argument 'verbose' is 1, function prints any errormessage to 
% the screen.
% 
% returns:  pitchclass (integer)
%           success (boolean)
%           errormessage (string)
%
%
% Author: Christopher Harte,  August 2005
% 
% Copyright: Centre for Digital Music, Queen Mary University of London 2005 
%
% This file is part of the C4DM Chord Toolkit.  
%
% The C4DM Chord Toolkit is free software; you can redistribute it and/or 
% modify it under the terms of the GNU General Public License as published 
% by the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% The C4DM Chord Toolkit is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with the C4DM Toolkit; if not, write to the Free Software
% Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

%
function [pitchclass, success, errormessage] = note2pitchclass(note, verbose)

if nargin < 2
    verbose = 0;
end

errormessage = '';

ilength = length(note);

index = 1;
success = 1;


% first char should be a natural name A-G
switch note(index)

    case 'C' % natural C
            pitchclass = 0; 
            index = index + 1;

    case 'D' % natural D
            pitchclass = 2; 
            index = index + 1;
    
    case 'E' % natural E
            pitchclass = 4; 
            index = index + 1;
    
    case 'F' % natural F
            pitchclass = 5; 
            index = index + 1;
    
    case 'G' % natural G
            pitchclass = 7; 
            index = index + 1;
    
    case 'A' % natural A
            pitchclass = 9; 
            index = index + 1;
    
    case 'B' % natural B
            pitchclass = 11; 
            index = index + 1;
            
    otherwise %Unrecognised character
            errormessage = sprintf(['Error in Note2PitchClass: Unrecognised note "' note '"\n']);
            index = ilength + 1;
            pitchclass=-1;
            success = 0;
         
end

% any other characters should be either flats or sharps
while index <= ilength
           
    switch(note(index))
        
        case 'b' % FLAT
            pitchclass = pitchclass - 1; %decrement pitchclass value
            index = index + 1;
            
        case '#' % SHARP
            pitchclass = pitchclass + 1; %increment pitchclass value
            index = index + 1;
        
        otherwise % Unrecognised character
            errormessage = sprintf(['Error in Note2PitchClass: Unrecognised note "' note '"\n']);
            index = ilength + 1;
            pitchclass=-1;
            success = 0;
    end        
            
end

% Use modulo command to make sure that we are back within range 0-12
if(success == 1)
    
    pitchclass = mod(pitchclass,12);
    
else
   if(verbose == 1)
      fprintf(1,errormessage); 
   end
end

            