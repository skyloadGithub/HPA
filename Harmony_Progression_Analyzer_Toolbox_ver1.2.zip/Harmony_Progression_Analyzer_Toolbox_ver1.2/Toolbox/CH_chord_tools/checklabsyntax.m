%
% CHECKLABSYNTAX Check the syntax of all chords in a lab file
% 
% [success] = checklabsyntax(labfile, {fid})
% 	
% Checks syntax of all chord symbols in a lab file. Any incorrect chords 
% will produce syntax errors and be quoted with time of chord from the 
% labfile given for inspection.
% 
% fid is the file id of the output log file.  If not given, the error log 
% will be printed to the screen
% 
% Success = 1 if all symbols have correct syntax, 0 otherwise.
%
% Returns: success (boolean)
% 
%
% Author: Christopher Harte,  August 2005
% 
% Copyright: Centre for Digital Music, Queen Mary University of London 2005 
%
% This file is part of the C4DM Chord Toolkit.  
%
% The C4DM Chord Toolkit is free software; you can redistribute it and/or 
% modify it under the terms of the GNU General Public License as published 
% by the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% The C4DM Chord Toolkit is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with the C4DM Toolkit; if not, write to the Free Software
% Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

%
function [success] = checklabsyntax(labfile,fid)

if nargin < 2
       fid = 1;
end

success = 1;

[times1,t2,symbols] = labread(labfile);

ilength = length(symbols);

% new file
fprintf(fid, ['*** File: ' labfile ' ***\n\n']);

errormessage = '';

for index = 1:ilength
    
    [ok, errormessage] = syntaxcheck(char(symbols(index)));
    
    
    if ok == 0
        
        success = 0;
        
        fprintf(fid,['Time: %f seconds\n' errormessage '\n\n'], times1(index));
        
    end
end


