%
% CHECKLABS check chord syntax in all lab files in a directory
% 
% success = checklabs(directory, logfile)
% 
% Check the syntax of chord symbols in every lab file in the target
% directory.  A log of syntax errors is created in the text file logfile
% 
% Success = 1 if all symbols have correct syntax, 0 otherwise.
%
% returns:  success (boolean)
%
%
% Author: Christopher Harte,  August 2005
% 
% Copyright: Centre for Digital Music, Queen Mary University of London 2005 
%
% This file is part of the C4DM Chord Toolkit.  
%
% The C4DM Chord Toolkit is free software; you can redistribute it and/or 
% modify it under the terms of the GNU General Public License as published 
% by the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% The C4DM Chord Toolkit is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with the C4DM Toolkit; if not, write to the Free Software
% Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

%
function [success] = checklabs(directory, logfile)

olddir = cd;

cd(directory);

files = dir('*.lab');

ilength = length(files);

success = 1;

fid = fopen(logfile, 'a');

for index = 1:ilength
    
    ok = checklabsyntax(files(index).name,fid);

    success = success && ok;

end

fclose(fid);

