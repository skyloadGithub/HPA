%
%DEGREE2NOTE convert a degree to correctly spelled note w.r.t. a root
% 
% [note,success,errormessage] = degree2note(degree, root {verbose})
% 
% Converts a degree to a note (string) with root as reference note 
% for degree interval.
% 
% Success = 1 if degree is converted correctly, 0 otherwise.
% 
% If optional argument 'verbose' is 1, function prints any errormessage to 
% the screen.
%
% returns:  note (string)
%           success (boolean)
%           errormessage (string)
%
% See also degrees2notes, parsenote.
%
%
% Author: Christopher Harte,  August 2005
% 
% Copyright: Centre for Digital Music, Queen Mary University of London 2005 
%
% This file is part of the C4DM Chord Toolkit.  
%
% The C4DM Chord Toolkit is free software; you can redistribute it and/or 
% modify it under the terms of the GNU General Public License as published 
% by the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% The C4DM Chord Toolkit is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with the C4DM Toolkit; if not, write to the Free Software
% Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

%
function [note,success,errormessage] = degree2note(degree, root,verbose)

if nargin < 3
    verbose = 0;
end
errormessage = '';

error1 = '';
error2 = '';

note = [];

intervaltranslation = [5,0,2,4,-1,1,3,5]; % scale degree translations on line of fifths 

fifthpositions = {'F','C','G','D','A','E','B'}; %order of naturals on line of fifths

success = 1;

% parse the root note
[rootnatural,rootaccs, rsuccess, error1] = parsenote(root);

%parse the degree
[interval, degreeaccs, present, dsuccess, error2] = parsedegree(degree);

% if parsing symbols was successful
if(rsuccess && dsuccess);

    switch(rootnatural) % find root natural position on line of fifths

        case 'F'
            fifthindex = 0;        
        case 'C'
            fifthindex = 1;
        case 'G'
            fifthindex = 2;
        case 'D'
            fifthindex = 3;
        case 'A'
            fifthindex = 4;
        case 'E'
            fifthindex = 5;
        case 'B'
            fifthindex = 6;

    end

    %locate enharmonic root on line of fifths (modulo 6 arithmetic)   
    
    fifthoffset = rootaccs*7;
    
    fifthindex = fifthindex + fifthoffset;
    
    
    % calculate interval translation on line of fifths (add 1 to account
    % for matlab referencing of array elements... 
    intervaloffset = intervaltranslation(mod(interval,7)+1); 
    finalposition = fifthindex + intervaloffset;
    
    
    naturalvalue = mod(finalposition,7);
    
    
    % calculate number of accidentals
    if finalposition <0 
        %if final position is negative then calculate number of flats
        % remembering to include the extra first flat (-1)
        accidentals = fix((finalposition+1)/7) + degreeaccs -1;
    
    else
        % note is a natural or has a number of sharps
        accidentals = fix(finalposition/7) + degreeaccs;
    end
    
    note = fifthpositions(naturalvalue+1);
    
    if accidentals > 0
        
        for i=1:accidentals
            
            note = strcat(note, '#');
            
        end
        
    elseif accidentals <=0
        
        for i=1:abs(accidentals)
            
            note = strcat(note, 'b');
            
        end
    end
        
else
 
    success=0;
    
end

if(success==0) % correct degree therefore return success = 1 
    % if not an integer then the degree string is incorrect
    errormessage = [error1 error2 sprintf(['Error in degree2note: Unrecognised degree "' degree '" or root "' root '"\n'])]; 
    
    if verbose == 1
       fprintf(1,errormessage); 
    end
    
end
    
    
    
    

    



