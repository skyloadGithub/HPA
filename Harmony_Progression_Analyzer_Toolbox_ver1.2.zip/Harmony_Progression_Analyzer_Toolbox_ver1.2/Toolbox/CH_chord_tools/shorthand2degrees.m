%
% SHORTHAND2DEGREES
% 
% [degreelist, success, errormessage] = shorthand2degrees(shorthand, {verbose})
% 
% Converts a shorthand string to a degree-list
% 
% Success = 1 if shorthand is recognised, 0 otherwise.
% 
% If optional argument 'verbose' is 1, function prints any errormessage to 
% the screen.
% 
% returns:  degreelist (string)
%           success (boolean)
%           errormessage (string)
%
% Author: Christopher Harte,  August 2005
% 
% Copyright: Centre for Digital Music, Queen Mary University of London 2005 
%
% This file is part of the C4DM Chord Toolkit.  
%
% The C4DM Chord Toolkit is free software; you can redistribute it and/or 
% modify it under the terms of the GNU General Public License as published 
% by the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% The C4DM Chord Toolkit is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with the C4DM Toolkit; if not, write to the Free Software
% Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

%
function [degreelist, success, errormessage] = shorthand2degrees(shorthand, verbose)

%set verbose to default to 0;;
if nargin <2
    verbose = 0;
end

degreelist = '';
errormessage = '';

success = 1;

switch(shorthand)
    
    % Empty:
    case ''
        degreelist = ''; %empty degreelist
        
    % Triad chords:
    case 'maj'
        degreelist = '3,5'; % major
    case 'min'
        degreelist = 'b3,5'; % minor
    case 'dim'
        degreelist = 'b3,b5'; % diminished  
    case 'aug'
        degreelist = '3,#5'; % augmented
    
    % Seventh chords:
    case 'maj7'
        degreelist = '3,5,7'; %major seventh
    case 'min7'
        degreelist = 'b3,5,b7'; % minor seventh
    case '7'
        degreelist = '3,5,b7'; % seventh
    case 'dim7'
        degreelist = 'b3,b5,bb7'; % diminished seventh
    case 'hdim7'
        degreelist = 'b3,b5,b7'; % half diminished seventh
    case 'minmaj7'
        degreelist = 'b3,5,7'; % minor (major seventh)
        
    % Sixth Chords:    
    case 'maj6'
        degreelist = '3,5,6'; % major sixth
    case 'min6'
        degreelist = 'b3,5,6'; % minor sixth
        
    % Ninth chords:
    case 'maj9'
        degreelist = '3,5,7,9'; % major ninth
    case 'min9'
        degreelist = 'b3,5,b7,b9'; % minor ninth
    case '9'
        degreelist = '3,5,b7,9'; % ninth
    
    % Suspended:
    case 'sus4'
        degreelist = '4,5'; % suspended fourth
        
    case 'sus2'
        degreelist = '2,5'; % suspended 2nd
    
    % Elevenths:
    case '11'
        degreelist = '3,5,b7,9,11'; % dominant 11
        
    case 'min11'
        degreelist = 'b3,5,b7,9,11'; % minor 11
        
    case 'maj11'
        degreelist = '3,5,7,9,11'; % major 11
        
    % Thirteenths:
    case '13'
        degreelist = '3,5,b7,9,11,13'; % dominant 13
        
    case 'min13'
        degreelist = 'b3,5,b7,9,11,13'; % minor 13
        
    case 'maj13'
        degreelist = '3,5,7,9,11,13'; % major 13        
        
        
    otherwise
        errormessage = sprintf(['Error in shorthand2degrees: Unrecognised shorthand string "' shorthand '"\n']);
        if verbose == 1
            fprintf(1,errormessage);
        end
        success = 0;
        
end


   
    
        