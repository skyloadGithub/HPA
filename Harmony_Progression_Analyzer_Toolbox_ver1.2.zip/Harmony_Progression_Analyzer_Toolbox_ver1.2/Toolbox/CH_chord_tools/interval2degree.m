%
% INTERVAL2DEGREE
% 
% [degree,success,errormessage] = interval2degree(interval,accidentals,{verbose})
% 
% Converts an interval and accidental pair to a degree string.
% 
% Success = 1 if interval converted correctly, 0 otherwise.
% 
% If optional argument 'verbose' is 1, function prints any errormessage to 
% the screen.
% 
% returns:  degree (string)
%           success (boolean)
%           errormessage (string)
%
% Author: Christopher Harte,  August 2005
% 
% Copyright: Centre for Digital Music, Queen Mary University of London 2005 
%
% This file is part of the C4DM Chord Toolkit.  
%
% The C4DM Chord Toolkit is free software; you can redistribute it and/or 
% modify it under the terms of the GNU General Public License as published 
% by the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% The C4DM Chord Toolkit is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with the C4DM Toolkit; if not, write to the Free Software
% Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

%		
function [degree,success,errormessage] = interval2degree(interval,accidentals, verbose)

% set verbose default to 0
if nargin < 3
    verbose = 0;
end

errormessage = '';


success = 1;
degree = '';


if accidentals >=1
   % then the interval is either a natural or has a number of sharps 
    if accidentals ~= 0
        for index = 1:accidentals 
            degree = [degree '#'];
        end
    end
    
else
    % then the interval has a number of flats
    
    for index = 1:abs(accidentals) 
   
        degree = [degree 'b'];
    end
    
end

if isnumeric(interval)
    
    intervalstring = num2str(interval);
    degree = [degree intervalstring];
    
else
   success = 0;
   errormessage = 'Error in interval2degree: incorrect interval';
end
    
if (success == 0) && (verbose == 1)   
    fprintf(1,errormessage);
end  


