%
% GETCHORDINFO Check chord symbol validity and return constituent parts
% 
% [rootnote, shorthand,degreelist,bassdegree, success, errormessage] = getchordinfo(chordsymbol, {verbose})
% 
% Checks symbol for correct syntax and returns chord information  Differs 
% from parsechord in that notes, shorthands, degrees and bass values are all 
% checked for validity in the process.
% 
% Success = 1 if all symbols have correct syntax, 0 otherwise.
% 
% If optional argument 'verbose' is 1, function prints any errormessage to 
% the screen.
% 
% Returns:	rootnote   (string)
%           shorthand  (string)
%           degreelist (string)
%           bassdegree (string)
%           success (boolean) true or false for correct syntax 
%           errormessage (string)  
%
% See also: syntaxcheck
%
% Author: Christopher Harte,  August 2005
% 
% Copyright: Centre for Digital Music, Queen Mary University of London 2005 
%
% This file is part of the C4DM Chord Toolkit.  
%
% The C4DM Chord Toolkit is free software; you can redistribute it and/or 
% modify it under the terms of the GNU General Public License as published 
% by the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% The C4DM Chord Toolkit is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with the C4DM Toolkit; if not, write to the Free Software
% Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

%		
function [rootnote, shorthand,degreelist,bassdegree, success, errormessage] = getchordinfo(chordsymbol, verbose)

if nargin < 2
    verbose = 0;
end
    
errormessage = '';
rootnote = '';
shorthand =  '';
degrees = '';
bassdegreel = '';


success = 0;

% parse the chord symbol into its constituent parts
[rootnote,shorthand, degreelist,bassdegree, success, errormessage] = parsechord(chordsymbol);

if success == 1
    
    if rootnote ~= 'N'
        
        % check validity of rootnote
        [temp, temp2, success, errormessage] = parsenote(rootnote);

        %check validity of shorthand list
        if ((success == 1) && ~(isempty(shorthand)))
           [temp, success, errormessage] = shorthand2degrees(shorthand);
        end        
        
        % check validity of degreelist
        if (success == 1) && ~(isempty(degreelist))
            [temp, success, errormessage] = parsedegreelist(degreelist);
        end
    
        % check validity of bass degree
        if (success == 1) && ~(isempty(bassdegree))
           [temp,temp2,temp3, success, errormessage] = parsedegree(bassdegree); 
        end
          
    end

end

if (success ==0) && (verbose == 1)
    fprintf(1,errormessage);
end
