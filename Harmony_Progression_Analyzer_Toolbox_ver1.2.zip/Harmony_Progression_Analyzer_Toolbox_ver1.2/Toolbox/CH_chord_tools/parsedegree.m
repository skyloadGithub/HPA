%
% PARSEDEGREE
% 
% [interval, accidentals, success, errormessage] = parsedegree(degree, {verbose})
% 
% Parse a degree to an interval value and a number of accidentals
% if accidentals is positive it denotes number of sharps,
% if it is negative it denotes number of flats.
% If the omit degree character '*' is found then present is returned as 0 
% otherwise it is 1. 
%
% Success = 1 if symbols parsed correctly, 0 otherwise.
%
% If optional argument 'verbose' is 1, function prints any errormessage to 
% the screen.
% 
% returns:  interval    (integer)
%           accidentals (integer) 
%           present     (boolean)
%           success     (boolean)
%           errormessage (string)  
%
% Author: Christopher Harte,  August 2005
% 
% Copyright: Centre for Digital Music, Queen Mary University of London 2005 
%
% This file is part of the C4DM Chord Toolkit.  
%
% The C4DM Chord Toolkit is free software; you can redistribute it and/or 
% modify it under the terms of the GNU General Public License as published 
% by the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% The C4DM Chord Toolkit is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with the C4DM Toolkit; if not, write to the Free Software
% Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

%
function [interval,accidentals,present,success, errormessage] = parsedegree(degree, verbose)

if nargin < 2
    verbose = 0;
end

ilength = length(degree);

errormessage = '';
accidentals = 0;
interval = 0;
success=1;
present = 1;

index = 1;
 
% if the input string is not empty   
if (isempty(degree) == 0)

    
    % check for omit degree '*'
    if degree(index) == '*' 
        present = 0;
        index = index +1;
    end


    tempstring = '';
    tempindex = 1;
    % parse the degree string
    while index <= ilength

        switch degree(index)

            case 'b' % FLAT
                accidentals = accidentals - 1; %decrement accidental count
                index = index + 1;

            case '#' % SHARP
                accidentals = accidentals + 1; %increment accidental count
                index = index + 1;
             
            case {'1','2','3','4','5','6','7','8','9'}
                % if neither of the above then remaining string should be
                % an integer interval value
                tempstring(tempindex) = degree(index);
                
                tempindex = tempindex+1;
                index = index+1;
                
            otherwise
                % unrecognised symbol
                success=0;
                index = ilength+1;
        end
    end
else
    success=0;
end

if success

% convert the interval string to an integer
    [interval, success] = str2num(tempstring); 

    % check it worked and that the interval is valid
    if isempty(interval) || (interval <= 0) 
        success = 0; 
    end
end            

if(success==0) % correct degree therefore return success = 1 
    % if not an integer then the degree string is incorrect
    errormessage = sprintf(['Error in parsedegree: Unrecognised degree "' degree '"\n']);
    interval = 0;
    if verbose == 1
        fprintf(1, errormessage);
    end
    
end
