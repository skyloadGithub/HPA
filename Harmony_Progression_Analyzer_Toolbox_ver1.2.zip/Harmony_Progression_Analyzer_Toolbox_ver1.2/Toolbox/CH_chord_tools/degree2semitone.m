%
% DEGREE2SEMITONE convert a degree to equivalent number of semitones
% 
% [semitone,success, errormessage] = degree2semitone(degree, {verbose})
% 
% Converts a degree string to equivalent number of semitones.
%
% Success = 1 if symbols parsed correctly, 0 otherwise. 
%
% If optional argument 'verbose' is 1, function prints any errormessage to 
% the screen.
% 
% calls:    parsedegree
%           interval2semitone
% 
% returns:  semitone (integer)
%           success  (boolean)  
%           errormessage (string)
%
%
% Author: Christopher Harte,  August 2005
% 
% Copyright: Centre for Digital Music, Queen Mary University of London 2005 
%
% This file is part of the C4DM Chord Toolkit.  
%
% The C4DM Chord Toolkit is free software; you can redistribute it and/or 
% modify it under the terms of the GNU General Public License as published 
% by the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% The C4DM Chord Toolkit is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with the C4DM Toolkit; if not, write to the Free Software
% Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

%		
function  [semitone, success, errormessage] = degree2semitone(degree, verbose)
    
if nargin <2 
    % verbose defaults 0
    verbose = 0;
end

errormessage = '';

ilength = length(degree);

success=0;
semitone = 0;

% parse the degree string

[interval, accidentals, present, ok] = parsedegree(degree);

if (ok == 1)
    
    % convert interval and accidentals to equivalent number of semitones 
    [semitone, ok, errors] = interval2semitone(interval,accidentals);
    
    success = 1;
    
else
    
    errormessage = sprintf(['Error in degree2semitone: incorrect degree "' degree '"\n']);

end

if (verbose ==1) && (success ==0)
    fprintf(1,errormessage); 
end

