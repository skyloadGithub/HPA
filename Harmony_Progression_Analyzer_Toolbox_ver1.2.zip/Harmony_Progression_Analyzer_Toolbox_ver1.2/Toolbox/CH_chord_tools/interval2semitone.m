%
% INTERVAL2SEMITONE
% 
% [semitone, success, errormessage] = interval2semitone(interval, accidental, {verbose})
% 
% Convert an interval and accidentals pair to a semitone value
% 
% Success = 1 if interval converted correctly, 0 otherwise.
% 
% If optional argument 'verbose' is 1, function prints any errormessage to 
% the screen.
% 
% returns:  semitone (string)
%           success (boolean)
%           errormessage (string)
%
% Author: Christopher Harte,  August 2005
% 
% Copyright: Centre for Digital Music, Queen Mary University of London 2005 
%
% This file is part of the C4DM Chord Toolkit.  
%
% The C4DM Chord Toolkit is free software; you can redistribute it and/or 
% modify it under the terms of the GNU General Public License as published 
% by the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% The C4DM Chord Toolkit is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with the C4DM Toolkit; if not, write to the Free Software
% Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

%		
function [semitone, success, errormessage] = interval2semitone(interval, accidentals, verbose)

if nargin < 3 
    % verbose defaults 0
    verbose = 0;
end

errormessage = '';

% semitone equivalents for intervals
%           interval   1,2,3,4,5,6,7         
semitonetranslation = [0,2,4,5,7,9,11];

semitone = 0;

success = 1;

if (interval > 0) && (interval < 50)

% semitone value is the number of semitones equivalent to the interval
% added to the number of accidentals (sharps are positive, flats are
% negative) and the number of octaves above the reference note to
% account for extensions 

semitone = semitonetranslation(mod(interval,8) + fix(interval/8)) + accidentals + 12*fix(interval/8);

else
    success = 0;
    
    errormessage = sprintf('Error in interval2semitone: out of range interval "%d"\n', interval);
    
    if verbose == 1
        fprintf(1,errormessage);
    end
end

