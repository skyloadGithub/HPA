%
% PARSEDEGREELIST
% 
% [pardegrees, success, errormessage] = parsedegreelist(degreelist, {verbose})
% 
% Parses a comma delimited list of degrees to an array of intervals, their 
% associated accidentals and whether or not they are present (presence 
% denoted by a '*' in front of a degree in the input degreelist). 
%
% Success = 1 if symbols parsed correctly, 0 otherwise.
%
% If optional argument 'verbose' is 1, function prints any errormessage to 
% the screen.
% 
% calls parsedegree
% 
% returns:  degrees       (array of int: [interval,accidental,present])
%           success       (boolean)
%           errormessage  (string) 
% 
%
% Author: Christopher Harte,  August 2005
% 
% Copyright: Centre for Digital Music, Queen Mary University of London 2005 
%
% This file is part of the C4DM Chord Toolkit.  
%
% The C4DM Chord Toolkit is free software; you can redistribute it and/or 
% modify it under the terms of the GNU General Public License as published 
% by the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% The C4DM Chord Toolkit is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with the C4DM Toolkit; if not, write to the Free Software
% Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

%
function [pardegrees, success, errormessage] = parsedegreelist(degreelist, verbose)

% set verbose default to 0
if nargin < 2
    verbose = 0;
end

errormessage = '';

ilength = length(degreelist);

index = 1;

tempindex = 1;

tempstring = '';

success = 1;

parindex  = 1;

pardegrees = [];


while index <= ilength
    
   
    while (degreelist(index) ~= ',')  
        
        tempstring(tempindex) = degreelist(index);
        tempindex = tempindex +1;
        index = index + 1;
        
        if(index > ilength)
            break;
        end
        
        if (degreelist(index) == ',') && (index == ilength)
            success = 0;
            errormessage = sprintf(['Error in parsedegreelist: degree list finishes with a comma "' degreelist '"\n']);
        end
            
            
    end
    
        [pardegrees(parindex,1),pardegrees(parindex,2),pardegrees(parindex,3),ok, error] = parsedegree(tempstring);
        % concatenate error messages if there are any...
        errormessage = [errormessage error];
        
        if(ok == 1)
            tempstring = '';
            tempindex = 1;
            parindex = parindex + 1;
            index = index + 1;
        else

            errormessage = [errormessage sprintf(['Error in parsedegreelist: incorrect degree in list "' degreelist '"\n'])];
            success = 0;
            index = ilength +1;            
        end
    
    
end

if (success == 0) && (verbose == 1)

    fprintf(1,errormessage)
    
end    


    
              






