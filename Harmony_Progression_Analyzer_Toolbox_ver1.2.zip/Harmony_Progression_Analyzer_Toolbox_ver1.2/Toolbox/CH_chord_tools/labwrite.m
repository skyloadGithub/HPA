%
%LABWRITE write a labfile to disk
%
% labwrite(times1, times2, labels, labfile, {protect})
%
% Write time indices and labels to a wavesurfer .lab transcription file
% with file name labfile
%  
% If optional argument 'protect' is 1 then if a lab file of the given name 
% already exists it will be copied to a backup file with extension '.labx' 
% before writing new data to the lab file   
%
% See also labread, mlf2lab, checklabsyntax.
%
% Author: Christopher Harte,  August 2005
% 
% Copyright: Centre for Digital Music, Queen Mary University of London 2005 
%
% This file is part of the C4DM Chord Toolkit.  
%
% The C4DM Chord Toolkit is free software; you can redistribute it and/or 
% modify it under the terms of the GNU General Public License as published 
% by the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% The C4DM Chord Toolkit is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with the C4DM Toolkit; if not, write to the Free Software
% Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
%
		
function labwrite(times1, times2, labels, labfile, protect)

if nargin<5
    protect = 0;
end

if (protect == 1)
   check = copyfile(labfile, [labfile 'x']);
end

fid = fopen(labfile, 'w');

for i = 1:length(times1)
    
    outtext = ['%f %f ' char(labels(i)) '\n'];
    
    fprintf(fid, outtext, times1(i), times2(i));
    
end

fclose(fid);


