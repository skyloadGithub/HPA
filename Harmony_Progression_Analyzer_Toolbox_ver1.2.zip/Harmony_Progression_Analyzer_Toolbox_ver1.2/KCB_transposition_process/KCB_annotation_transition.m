function [GT_transpositions,binarytable]=KCB_annotation_transition(chord_annotations,key_annotations, bass_annotations, binarytable, numKeys)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
%[GT_transpositions,binarytable]
%=KCB_annotation_transition(chord_annotations,key_annotations, bass_annotations, binarytable, numKeys)
%
%This function transposes all key/chord/bass annotations into 12 major/minor keys.
%
% INPUTS
%chord_annotations - the original chord annotation sequences. 1xN cells.
%key_annotations - the original key annotation sequences. The same size as
%                  chord_annotations. Default: 2xk is minor key; 2xk-1 is major
%                  key.
%bass_annotations - the original bass annotation sequences. 1 x N cells.
%binarytable - the binary table of the chords nstates x num_notes.
%numKeys - the number of keys. 
%
% OUTPUTS
%GT_transpositions - Default a 1xN cells, each one is a structured containing
%                    chord_annotations: all chord transpositions for a song.
%                    key_annotations: all key transpositions for a song.
%                    bass_annotations: all bass transpositions for a song.
%binarytable - the binary table of the chords (may be modified if new chords appeared).
%
%---------------------------------------------
%Function created by Y. Ni
%Function revised by M. McVicar
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%1. configulation
N=length(chord_annotations);
key_Nstate=numKeys+1;       %the no-key index
chord_Nstate=size(binarytable,1); %Get the no-chord index
num_note=12;                %default, 12 notes
bass_Nstate=13;             %default, label 13 is no-bass

warningCount=0;             %Count how many times new chord appears
                            %Currently set those chords as 0 (no further
                            %process)
                            
Xchord=chord_Nstate+1;      %For 'X' chords or no-key state 
Xbass=14;                   %For the bass of 'X' chords or no-key state
                            
c_annotations_transposition=cell(1,N);  %The chord annotations transposition
k_annotations_transposition=cell(1,N);  %The key annotations transposition
b_annotations_transposition=cell(1,N);  %The bass annotations transposition


%2. Create the chord mapping structure
%key i: original key
%key j: new key
%chord k: the original chord
%chord_key_dict(i,j,k)=the new transposed chord for key j
chord_key_dict=zeros(numKeys,numKeys,chord_Nstate);

%2.1 Major chord
for k1=1:2:numKeys
    original_pitch=(k1+1)/2;
    for k2=1:2:numKeys
        new_pitch=(k2+1)/2;
        %2.2. No chord
        chord_key_dict(k1,k2,chord_Nstate)=chord_Nstate;
        for c1=1:chord_Nstate-1
            new_chord=transpose_chords(c1, original_pitch, new_pitch, binarytable);
            if (new_chord>chord_Nstate)
                warning('In function chord_annotation_transition.m: the size of binary table increase! New chords appeared in transposition.');
                new_chord=Xchord;
                warningCount=warningCount+1;
            end
            chord_key_dict(k1,k2,c1)=new_chord;
        end
    end
end

%2.2 Minor chord
for k1=2:2:numKeys
    original_pitch=k1/2;
    for k2=2:2:numKeys
        new_pitch=k2/2;
        %2.2. No chord
        chord_key_dict(k1,k2,chord_Nstate)=chord_Nstate;
        for c1=1:chord_Nstate-1
            new_chord=transpose_chords(c1, original_pitch, new_pitch, binarytable);
            if (new_chord>chord_Nstate)
                warning('In function chord_annotation_transition.m: the size of binary table increase! New chords appeared in transposition.');
                new_chord=Xchord;
                warningCount=warningCount+1;
            end
            chord_key_dict(k1,k2,c1)=new_chord;
        end
    end
end

if (warningCount>0)
    warning(['In function chord_annotation_transition.m: there are ',int2str(warningCount),' new chords appeared in transposition (set as 0 currently).']);
end


%3. Create the bass mapping structure
%key i: original key
%key j: new key
%bass k: the original bass
%bass_key_dict(i,j,k)=the new transposed bass for key j
bass_key_dict=zeros(numKeys,numKeys,bass_Nstate);

%3.1 Major chord
for k1=1:2:numKeys
    original_pitch=(k1+1)/2;
    for k2=1:2:numKeys
        new_pitch=(k2+1)/2;
        %3.2. No bass
        bass_key_dict(k1,k2,bass_Nstate)=bass_Nstate;
        for b1=1:bass_Nstate-1
            pitchoff=new_pitch-original_pitch;
            
            temp_bassNote=mod(b1+pitchoff,num_note);
            if (temp_bassNote==0)
                bass_key_dict(k1,k2,b1)=num_note;
            else
                bass_key_dict(k1,k2,b1)=temp_bassNote;
            end
        end
    end
end

%3.1 Major chord
for k1=2:2:numKeys
    original_pitch=k1/2;
    for k2=2:2:numKeys
        new_pitch=k2/2;
        %3.2. No bass
        bass_key_dict(k1,k2,bass_Nstate)=bass_Nstate;
        for b1=1:bass_Nstate-1
            pitchoff=new_pitch-original_pitch;
            
            temp_bassNote=mod(b1+pitchoff,num_note);
            if (temp_bassNote==0)
                bass_key_dict(k1,k2,b1)=num_note;
            else
                bass_key_dict(k1,k2,b1)=temp_bassNote;
            end
        end
    end
end



%3. Do transposition
for i=1:N
    
    new_chord_annotations=cell(1,12);
    new_key_annotations=cell(1,12);
    new_bass_annotations=cell(1,12);
    
    if (~(isempty(key_annotations{i}) || isempty(chord_annotations{i}) || isempty(bass_annotations{i}))) %check whether key annotations exist
        ann_len=length(chord_annotations{i});
        for k=1:12
            temp_new_chord_annotations=zeros(1,ann_len);
            temp_new_key_annotations=zeros(1,ann_len);
            temp_new_bass_annotations=zeros(1,ann_len);
            for j=1:ann_len
                currentKey=key_annotations{i}(j);
                %3.1 If it is no key index
                if (currentKey==key_Nstate)
                    temp_new_key_annotations(j)=key_Nstate; 
                    temp_new_chord_annotations(j)= Xchord; %Not using no key index 
                    temp_new_bass_annotations(j)=Xbass; %Not using no key index
                %3.2 If it is a major key
                elseif (mod(currentKey,2)==1)
                    newKey=2*k-1;
                    temp_new_key_annotations(j) = newKey; %A major
                    if (chord_annotations{i}(j)>chord_Nstate) %If it is 'X'
                        temp_new_chord_annotations(j)=Xchord;
                    else
                        temp_new_chord_annotations(j)= chord_key_dict(currentKey,newKey,chord_annotations{i}(j));
                    end
                    
                    if (bass_annotations{i}(j)>bass_Nstate) %If it is 'X' chord's bass
                        temp_new_bass_annotations(j)=Xbass;
                    else
                        temp_new_bass_annotations(j)=bass_key_dict(currentKey,newKey,bass_annotations{i}(j));
                    end
                %3.3 If it is a minor
                else
                    newKey=2*k;
                    temp_new_key_annotations(j)=newKey; %A minor
                    if (chord_annotations{i}(j)>chord_Nstate)
                        temp_new_chord_annotations(j)=Xchord;
                    else
                        temp_new_chord_annotations(j)= chord_key_dict(currentKey,newKey,chord_annotations{i}(j));
                    end
                    
                    if (bass_annotations{i}(j)>bass_Nstate) %If it is 'X' chord's bass
                        temp_new_bass_annotations(j)=Xbass;
                    else
                        temp_new_bass_annotations(j)=bass_key_dict(currentKey,newKey,bass_annotations{i}(j));
                    end
                end
            end
            %3.4 Assigned the new key/chord/bass annotations
            new_chord_annotations{k}=temp_new_chord_annotations;
            new_key_annotations{k}=temp_new_key_annotations;
            new_bass_annotations{k}=temp_new_bass_annotations;
        end
    end
    %3.5 Assign the GT structure
    c_annotations_transposition{i}=new_chord_annotations;
    k_annotations_transposition{i}=new_key_annotations;
    b_annotations_transposition{i}=new_bass_annotations;
end

GT_transpositions=struct;
GT_transpositions.chord_annotations=c_annotations_transposition;
GT_transpositions.key_annotations=k_annotations_transposition;
GT_transpositions.bass_annotations=b_annotations_transposition;

return;

            
    
