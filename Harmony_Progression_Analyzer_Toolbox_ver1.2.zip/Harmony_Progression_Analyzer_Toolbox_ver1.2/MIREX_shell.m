%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MIREX chord Detection task 2011 shell
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
toolbox_dir = pwd;
addpath(genpath(toolbox_dir));

%0. Add backslash at the end
if (~(strcmp(toolbox_dir(end),'/') || strcmp(toolbox_dir(end),'\')))
    toolbox_dir=[toolbox_dir,'/'];
end

%%%%%%%%%%%%%%%USER SPECIFIED PARAMETERS%%%%%%%%%%%%%%%%
test_audio_file='audio_annotations_path_files.txt';               %The file containing all directories for the test audios (each line is a directory)
train_audio_annotation_file='audio_annotations_path_files.txt';   %The file containing all directories for the training audios and annotations
saveFile_dir='/home/enxyn/MIREX_database/temp_files/';           %The temporary directory to save features and some parameters
prediction_dir='/home/enxyn/MIREX_database/temp_predictions/';   %The directory to save the results
parallel_flag=1;                                                 %1. Do parallel computation, use <=8 cores; 0. non-parallel computation, use 1 core.
task_flag=1;                                                     %1. MIREX train-test system competition; 0. MIREX pre-trained system competition; 2. HP re-training scheme.
modelLabel='full';                                               %Only used in the pre-trained system: 
                                                                 %minmaj - using pre-trained major/minor chord system
                                                                 %full - using pre-trained full chord system
useKey_flag=0;                                                   %Only used in HP re-training scheme. 0. Not using key information; 1. otherwise.
parameter_saveFile=[saveFile_dir,'HPA_preTrain_parameters_',modelLabel,date];
%%%%%%%%%%%%%%%USER SPECIFIED PARAMETERS%%%%%%%%%%%%%%%%

                                                                 
%2. Main process
if (task_flag==1)
    MIREX_train_test_system(train_audio_annotation_file, saveFile_dir,test_audio_file, prediction_dir,  toolbox_dir, parallel_flag);
elseif (task_flag==0)
    MIREX_preTrainSystem(test_audio_file,saveFile_dir,prediction_dir,toolbox_dir, parallel_flag,modelLabel);
elseif (task_flag==2)
    if (strcmp(modelLabel,'minmaj'))
        chord_flag='minmaj';
    elseif(strcmp(modelLabel,'full'))
        chord_flag='mm';
    end

    HP_reTrain_system(train_audio_annotation_file, saveFile_dir, parameter_saveFile,  toolbox_dir, chord_flag, useKey_flag, parallel_flag);
end
    