/*
Instruction of the Harmony Progression Analyzer (HPA) software package
(For Audio Chord Estimation)

-------------------------------------------
Yizhao Ni, Matt Mcvicar, Raul Santos-Rodriguez and Tijl De Bie
Intelligent Systems Lab 
Department of Engineering Mathematics
University of Bristol
*/

The Harmony Progression Analyzer (HPA) is a key, chord and bass simultaneous recognition system that purely relies on machine learning techniques. It also uses a novel choromagram extraction method, which is inspired by loudness perception studies. Compared with other chord estimation systems, HPA is fast and memory-efficient, achieving an excellent tradeoff between performance and memory and time efﬁciencies.


/*
A. INSTALLATION
*/  

The HPA system is coded in Matlab. You need Matlab2008b or higher versions to run the system. You can still run the system on other Matlab versions, but you will encounter warnings since the system uses containers.Map(). 

If the system is running on a 32-bit WINDOWS/LINUX or a MAC, you need to run "code_compile_shell.m" first to compile the following Mex functions:

===========================================
1. ./Feature_extraction/HPSS_innerLoop.c
2. ./HMM_model/bass_viterbiDecoder_c.c
3. ./HMM_model/bass_viterbiDecoder_var_c.c
4. ./HMM_model/key_viterbiDecoder_c.c
5. ./HMM_model/key_viterbiDecoder_var_c.c
6. ./HMM_model/viterbiDecoder_c.c
===========================================

Otherwise, their 64-bit WINDOWS/LINUX executable functions have been included in the package.


/*
B. PARAMETERS
*/ 

We create a Matlab shell "MIREX_shell.m" to run the system. The user should specify the following parameters in MIREX_shell.m before running the system:

===========================================
1. test_audio_file - the file containing the paths to all test audios. 
   Remark: an audio file should end with ".wav".
2. train_audio_annotation_file - the file containing the paths to all training audios and annotations.
   Remark: this file is only used in the train-test system. An audio file should end with ".wav", and the filename of the annotation for "xxxx.wav" should be "xxxx.wav.txt".
3. saveFile_dir - the temporary directory to save features and parameters.
4. prediction_dir - the directory to save the results. 
   Remark: the filename of the prediction for "xxxx.wav" will be "xxxx_prediction.txt".
5. parallel_flag - the flag for parallel computations: 1. using parallel computations which takes <=8 cores; 0. using non-parallel computations which takes 1 core.
6. task_flag - 0. For using the HPA pre-trained system; 1. For MIREX Audio chord estimation 2011 train-test system evaluation; 2. For using the HPA re-training scheme.
7. modelLabel - only used in the pre-trained system (please used the default value 'full'). 'minmaj' - using pre-trained major/minor chord system; 'full' - using pre-trained full chord system.
===========================================

After setting the parameters, simply execute "MIREX_shell" to start the system. The system will then do the following steps:

===========================================
1. Extracting chroma features for test audios. In the train-test/re-training schemes (i.e. task_flag=1,2), it also extracts chrom features and annotations for training audios. The extracted features as well as annotations will be stored in the directory "saveFile_dir".
2. Using the HPA decoder to estimate chord progressions for test audios. In the train-test schme, the system first learns the HPA parameters from training chroma features and annotations, then does chord estimation.
3. Save chord predictions to the directory "prediction_dir". The filename of the prediction for "xxxx.wav" is "xxxx_prediction.txt".
===========================================


/*
C. RE-TRAINING PARAMETERS
*/

As a Machine Learning based system, one advantage of HPA is that users can re-train HPA's parameters (using Maximum Likelihood Estimation) when more data are available. To re-train the HPA-HMM parameters, simply change task_flag to 2 in "MIREX_shell.m", or running 'HP_reTrain_system(train_audio_annotation_dir, saveFile_dir, parameter_saveFile,  toolbox_dir, chord_flag, useKey_flag, parallel_flag)' with the following parameters:
 
===========================================
1. train_audio_annotation_dir - the file containing the paths to all training audios and annotations.
   Remark: For each piece of audio the user should provide three files. An audio file should end with ".wav", the corresponding chord annotation should be named as "xxxx.wav.txt", and the key annotation "xxxx.wav.keyInfo". If the user does not have key information, please set "useKey_flag=0".
2. saveFile_dir - the directory to save some temp files.
3. parameter_saveFile - the directory and filename for saving the trained parameters, e.g. parameter_saveFile='./my_HP_parameters'. After training, do remember to change the HPA system's parameter file (specified in line 90-94 in MIREX_preTrainSystem.m and line 309-314 in HP_system_GUI.m) to this new file.
4. toolbox_dir - the root directory of the HPA system.
5. chord_flag - currently support 'minmaj': 25 major/minor chord classes; 'mm': 121 complex chord classes.
6. useKey_flag - 1: using key information (the user should provide "xxxx.wav.keyInfo"); 0. Otherwise.
7. parallel_flag - the flag for parallel computations: 1. using parallel computations which takes <=8 cores; 0. using non-parallel computations which takes 1 core.
===========================================


/*
D. GUI INTERFACE
*/

Apart from the batch processing script "MIREX_shell.m", we also provide a GUI interface for regular users. Simply run "HP_system_GUI.m" and follow the instructions. Here is a general procedure:

===========================================
1. Open a .wav file.
2. Choose the ACE task on the task pannel (i.e. major/minor chord prediction, complex chord prediction and chroma feature extraction).
3. Tune (or use the default) parameters for the ACE task.
4. Click "Run" button to run the system.
5. Save the chroma features (automatically to a .chroma file) or the chord estimations.
=========================================== 


/*
E. PROCESSING TIME AND MEMORY CONSUMPTION
*/ 

The processing time and memory consumption are evaluated using the pre-trained system, which can be larger than the time/memory consumption for a train-test system. Hence, the processing times and memory consumptions shown below can be regarded as an upper bound of the time/memory consumption of the HPA system.

===========================================
1. Using parallel computation:
	1) This setting takes 8 cores (or less) to run "matlabpool".
	2) The peak memory consumption (for one core) is around 1.7G on the MIREX dataset.
	3) The processing time:
	   Feature extraction - ~30 minutes (running on 8 Intel (R) X5650 cores at 2.67GHz, 24G RAM).
	   HPA decoding - ~12 minutes (running on 1 Intel (R) X5650 core at 2.67GHz, 24G RAM).

2. Using non-parallel computation:
	1) This setting takes 1 core.
	2) The peak memory consumption is around 1.7G on the MIREX dataset.
	3) The processing time:
	   Feature extraction - ~240 minutes (running on 1 Intel (R) X5650 cores at 2.67GHz, 24G RAM).
	   HPA decoding - ~40 minutes (running on 1 Intel (R) X5650 core at 2.67GHz, 24G RAM).
===========================================


/*
F. CONTACT
*/ 

For any problem w.r.t. the HPA system, please contact

===========================================
Y. NI
Intelligent Systems Lab 
Department of Engineering Mathematics
University of Bristol
Email: Yizhao.NI@googlemail.com
===========================================

