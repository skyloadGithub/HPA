%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%C code compile shell
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mex ./Feature_extraction/HPSS_innerLoop.c
mex ./HMM_model/bass_viterbiDecoder_c.c
mex ./HMM_model/bass_viterbiDecoder_var_c.c
mex ./HMM_model/key_viterbiDecoder_c.c
mex ./HMM_model/key_viterbiDecoder_var_c.c
mex ./HMM_model/viterbiDecoder_c.c

disp('Success.');