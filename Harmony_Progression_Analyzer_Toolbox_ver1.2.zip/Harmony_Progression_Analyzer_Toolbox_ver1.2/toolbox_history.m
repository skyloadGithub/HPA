% History

% Thu, Mar 17, 2011. Initial Version sent to Matt

% Fri Mar 18, 2011. Tested by Matt. Edits:
%
% 1. Added getAllFiles.m, which works on all OS.
% 2. Added Chord_Key_toolboxtest.m, which tests the feature extraction part
%    of the toolbox 
% 3. Added check for empty options in extract_harmony_from_audio. Can now
%    just pass in the filename, defaults will be used.
% 4. Commented line 31 of estimate_beats.m
% 5. Added defaults for cal_hamming_window. Used current treble chroma as
%    defaults
% 6. Added defaults for cal_CQ_loudness.


% Modification by Ni

%24/03/11 Modification on the "HMM_model" folder
%Add key_bass_viterbi.m
%Add createHyperTransmat.m
%Add bass_viterbiDecoder_c.c
%Modified key_viterbiDecoder.m
%Add key_viterbiDecoder_c.c

%24/03/11 Modification on the "Ground_truth_extraction" folder
%1. Modified extract_ground_truth.m, now it can extract 'bass' from full chord
%annotations.
%2. Add reduce_to_bass.m

%29/03/11 Modification on the "HMM_model" folder
%Add bass_viterbiDecoder_var_c.c
%Add key_viterbiDecoder_var_c.c
%Add createHyperTransmat_var.m
%Modified key_bass_viterbi.m
%Modified key_viterbiDecoder.m

%04/04/11 Modification on the "beat_tracker" folder
%Modified beatestimat.me, now it is the same as beat.m 
%There are some problems in beat2.m so not use it in any further version.

%06/04/11 Modification on the "KCB_transposition_process" folder
%Modified KCB_annotation_transition.m set 'X' symbol as 0 so not in used
%for transition learning
%Modified hmm_train_transmat.m avoid using 'X' symbol in the transition
%matrix.

%06/04/11 Modification on the "Ground_truth_extraction" folder
%Modified extract_ground_truth.m, adding the reduce_to_MM options and modified the code to fit the option.

%07/04/11 Modification on the "Ground_truth_extraction" folder
%Modified reduce_to_MM.m, also extracting the chords without bass

%07/04/11 Modification on the "Ground_truth_extraction"
%Modified reduce_to_bass.m, modified the code to deal with the unknown
%chord 'X'.

%07/04/11 Modification on the "KCB_transposition_process" folder
%Modified KC_annotation_transition.m - fix the bug dealing with
%bass_annotation(j)=14 (due to chord 'X')

%07/04/11 Modification on the "HMM_model" folder.
%Modified gaussian_sigma_inverse.m to deal with the case that Sigma=0 (no
%this chord in the training set)

%18/04/11 Modification on the "Feature_extraction" folder.
%Add HPSS_innerLoop.c to speed up the HPSS process.

%19/04/11 Modification on Harmony_Progression_Toolbox.
%Add a folder "Mainprocess_script" form mainProcess templates.
%Add MIR_mainProcess_extractFeatures.m for extracting chromagrams (template).
%Add MIR_mainProcess_extractAnnotations.m for extracting annotations (template).
%Add MIREX_mainProcess_CBHMM_train_test.m for MIREX train-test competition (template).

%20/04/11 Modification on Harmony_Progression_Toolbox.
%Add a folder "pre_trainSystem" to store the pretrained parameters.
%Add the .mat file "MIREX_minmaj_PretrainSystem_200411" which includes the
%parameters for the maxGamma decoder and the KCB HMM (training on 218
%songs, 25 chord dictionary).

%21/04/11 Modification on Harmony_Progression_Toolbox.
%Add the .m file "MIREX_train_test_system" for MIREX 2011 chord train-test system
%competition.
%Add the .m file "MIREX_preTrainSystem" for MIREX 2011 chord pretrained
%system competition.

%27/04/11 Modification on the folder "pre_trainSystem"
%Add the .mat file "MIREX_fullChord_PretrainSystem_270411" which includes
%the parameters for the maxGamma decoder and the KCB HMM (training on 218
%songs, 121 chord dictionary).

%18/05/11 Modification on the Harmony_Progression_Toolbox.
%Add code_compile_shell.m to compile the mex functions.

%05/07/11 Modification on the Harmony_Progression_Toolbox.
%Add HP_system_GUI.m as a GUI interface for users (ver1.0).

%07/07/11 Modification on HP_system_GUI.m
%Add a GUI function to put HP chord prediction into mp3 as an ID3 tag
%(USLT).
%Add mp3_toolbox to the folder "Toolbox" (mp3read() and mp3write()).

%13/07/11 Modification on HP_system_GUI.m
%Add chord predictions on mp3 on both USLT and SYLT frames.

%13/07/11 Modification on ./Harmony_Progression_Toolbox/Toolbox/mini_mutagen_id3tagger/HP_saving_ID3_chordPredictionl.py
%Add chord preditions on both USLT and SYLT frames.

%13/07/11 Modification on ./Harmony_Progression_Toolbox/Mainprocess_script/MIR_generate_prediction_string.m
%Change the output format: chord time_stamp (milliseconds) chord time_stamp ...

%07/11/11 Modification on ./Harmony_Progression_Toolbox/Ground_truth_extraction/Alphabet/
%Add reduce_to_key.m for extracting key information.
%Also modify the code of extract_ground_truth.m / get_global_binary_table.m
%for extracting keys.

%07/11/11 Add new module - training HP parameters
%Add function: HP_mainProcess_KCBHMM_trainParameters.m
%Add function: HP_mainProcess_extractAnnotations.m
%Add function: HP_reTrain_system.m

%06/06/12 Fix bug on cal_CQ_chroma_loudness.m
%27/06/12 Fix bug on extract_ground_truth.m
%02/07/12 add patches on reduce_to_MM.m
%23/07/12 Correct mistake in when re-train for complex chord model (no influence on the results)
%14/08/2012 Fix bug on reduce_to_quads.m (for suspension chord, add sus2 and sus4)
