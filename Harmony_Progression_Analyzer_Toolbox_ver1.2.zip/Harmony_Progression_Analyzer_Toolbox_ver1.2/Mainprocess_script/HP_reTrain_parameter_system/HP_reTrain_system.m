function HP_reTrain_system(train_audio_annotation_dir, saveFile_dir, parameter_saveFile,  toolbox_dir, chord_flag, useKey_flag, parallel_flag)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function 
%MIREX_train_test_system(train_audio_annotation_dir, saveFile_dir,test_audio_dir, prediction_dir,  toolbox_dir, chord_flag, useKey_flag, parallel_flag)
%
%Re-training the HP parameters.
%
% INPUTS
%train_audio_dir - The directory and file names of the train audio and annotations (in a .txt file).
%Remark: for example for "/path/to/trainFile1.wav", there will be a corresponding 
%anns ground truth file called "/path/to/trainFile1.wav.txt".
%key ground truth file called "/path/to/trainFile1.wave.key"
%saveFile_dir - The temp directory to store the chromagrams and annotations.
%parameter_saveFile - The output directory and file names for the parameter file.
%chord_flag - 'minmaj': train HP parameters for 25 maj/min chord classes;
%             'mm': train HP parameters for 121 complex chord classes.
%useKey_flag - 1. Using key annotations as well;
%              0. Otherwise.
%parallel_flag - 1. Using parallel processor for feature extraction.
%                0. Otherwise.
%
%---------------------------------------------
%Function created by Y. Ni
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%0. Configulation
% toolbox_dir = pwd;
addpath(genpath(toolbox_dir));

%A. parallel processing?
if (nargin<7)
    parallel_flag=0;
end

if (nargin<6)
    useKey_flag=0;
end

if (nargin<5)
    chord_flag='minmaj';
end

%B. The file names of training chromagram features and the annotations
train_audio_names={};
train_annotation_names={};
train_key_annotation_names={};

countSongs=0;
fid=fopen(train_audio_annotation_dir,'r');
tline=fgetl(fid);
while(ischar(tline))
    tline=regexprep(tline,'\s+$',''); %delte \n
    if (~isempty(tline))
        if (strcmp(tline(end-3:end),'.wav'))
            countSongs=countSongs+1;
            train_audio_names{countSongs}=tline;
            train_annotation_names{countSongs}=[tline,'.txt'];
            if (useKey_flag)
                train_key_annotation_names{countSongs}=[tline,'.keyInfo'];
            end
        end
    end
    tline=fgetl(fid);
end

disp(['All together, there are: ',int2str(countSongs),' training songs.']);
disp('');

saveFileName_train_chroma='train_chroma';
saveFileName_train_beat='train_beat';
saveFileName_train_annotation='train_annotations';


%1. Extracting chromagram features
if (parallel_flag)
    
    %A. training chromagram
    [saveFile_dir,saveFileName_train_chroma,saveFileName_train_beat]=MIR_parallel_mainProcess_extractFeatures(train_audio_names,saveFile_dir,saveFileName_train_chroma,saveFileName_train_beat);
else
    %A. training chromagram
    [saveFile_dir,saveFileName_train_chroma,saveFileName_train_beat]=MIR_mainProcess_extractFeatures(train_audio_names,saveFile_dir,saveFileName_train_chroma,saveFileName_train_beat);
end

%2. Extracting the annotations
[saveFileName_train_annotation] = HP_mainProcess_extractAnnotations(train_annotation_names,train_key_annotation_names, saveFile_dir,saveFileName_train_beat,saveFileName_train_annotation,chord_flag);

%3. Re-training the HP parameters
HP_mainProcess_KCBHMM_trainParameters(saveFile_dir, saveFileName_train_chroma, saveFileName_train_annotation, parameter_saveFile);
