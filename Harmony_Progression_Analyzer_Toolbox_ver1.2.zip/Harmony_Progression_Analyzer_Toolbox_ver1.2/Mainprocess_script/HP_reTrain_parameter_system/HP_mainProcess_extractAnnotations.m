function [saveFileName_annotation] = HP_mainProcess_extractAnnotations(anns_ground_truth_names,key_ground_truth_names,saveFile_dir,saveFileName_beat,saveFileName_annotation,chordFlag)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function [saveFileName_annotation] 
%= HP_mainProcess_extractAnnotations(anns_ground_truth_names,key_ground_truth_names,saveFile_dir,saveFileName_beat,saveFileName_annotation,chordFlag)
%
%Main Process (template) Two:
%Extracting the annotations from the ground truth.
%Including: binary_table, chord_classes, chord_class_dict (Map), key_classes, key_class_dict (Map).
%Default: using beat-synchronized features (beat_times required).
%
%Remark:
%The chord ground truth format should be in C. Harte's format!
%The key ground truth format should be in restricted format (see reduce_to_key.m)!
%Structure format: "start_times" "end_times" "chords".
%
% INPUTS
%anns_ground_truth_names - The file names of the chord ground truths.
%key_ground_truth_names - The file names of the key ground truths.
%saveFile_dir - The directory to save the chromagram features and beat times.
%saveFileName_beat - The file name of the beat and sample times.
%saveFileName_annotation - The file name of the (training) annotations.
%chordFlag - 'minmaj': major/minor 25 classes; 'mm': 121 complex chord classes.
%
% OUTPUTS
%saveFileName_annotation - The file name of the (training) annotations.
%
%---------------------------------------------
%Function created by Y. Ni
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%0. Configulation
disp('Main process two: Annotation extraction (taking < 1 mins).');
disp('****************************************');
disp('');

if (nargin<6)
    alphabet='minmaj'; %Default using 25 chord classes
else
    alphabet=chordFlag;
end

%A. The reduced-chord format (minmaj, triads, quads, mm, etc).
format='lab';
%C. The beat time directory
options.directory=saveFile_dir;
load([options.directory,saveFileName_beat]);
if (nargin<5); saveFileName_annotation='annotationSaveFile'; end


%1. Construct the binary table and the class dictionary
if (iscell(anns_ground_truth_names))
    numSong=length(anns_ground_truth_names);
else
    error('Error in HP_mainProcess_extractAnnotations.m: the chord ground truth names should be in a cell.');
end

[binary_table,chord_classes,chord_class_dict]=get_global_binary_table(anns_ground_truth_names,format,alphabet);

%2. Get the reduced-chord annotations for each song
disp('Start extracting the chord annotations.');
disp('--------------------------------------------------------');
disp('');

tic
chord_annotations=cell(1,numSong);
for song=1:numSong
    chord_annotations{song}=extract_ground_truth(anns_ground_truth_names{song},...
    'CH',chord_classes,chord_class_dict,alphabet,beat_times{song},'beatsynch'); 
end
toc

%3. Get the bass annotations for each song
disp('Start extracting the bass annotations.');
disp('--------------------------------------------------------');
disp('');

tic
bass_annotations=cell(1,numSong);
alphabet='bass';
for song=1:numSong
    bass_annotations{song}=extract_ground_truth(anns_ground_truth_names{song},...
    'CH',chord_classes,chord_class_dict,alphabet,beat_times{song},'beatsynch'); 
end
toc

%4. Get the key annotations for each song
disp('Start extracting the key annotations.');
disp('--------------------------------------------------------');
disp('');

if (isempty(key_ground_truth_names))
    %If there is no key information
    tic
    key_annotations=cell(1,numSong);
    key_classes={};
    key_class_dict={};
    
    for song=1:numSong
        key_annotations{song}=ones(1,length(beat_times{song})+1); %If no key information, assume to be C:maj
    end
    toc
else
    %Extract key information
    if (iscell(key_ground_truth_names))
        numSong=length(key_ground_truth_names);
    else
        error('Error in HP_mainProcess_extractAnnotations.m: the key ground truth names should be in a cell.');
    end
    
    tic
    alphabet='key';
    key_annotations=cell(1,numSong);
    [~,key_classes,key_class_dict]=get_global_binary_table(key_ground_truth_names,format,alphabet);
    
    
    for song=1:numSong
        try
            key_annotations{song}=extract_ground_truth(key_ground_truth_names{song},...
                'CH',key_classes,key_class_dict,alphabet,beat_times{song},'beatsynch');
        catch
            key_annotations{song}=key_class_dict('C:maj')*ones(1,length(beat_times{song})+1); %If no key information, assume to be C:maj
        end
    end
    toc
end


%*. Delete the 'X' class (if existed)
[num_class,num_notes]=size(binary_table);
for k=1:num_class
    if (sum(binary_table(k,:))==num_notes)
        binary_table(k,:)=[];
        del_class=chord_classes{k}{1};
        chord_classes(k)=[];
        remove(chord_class_dict,del_class);
        break;
    end
end



%4. Save the annotations
save([options.directory,saveFileName_annotation],'chord_annotations','key_annotations','bass_annotations','beat_times','sample_times','binary_table','chord_classes','chord_class_dict','key_classes','key_class_dict');

disp('done'); 