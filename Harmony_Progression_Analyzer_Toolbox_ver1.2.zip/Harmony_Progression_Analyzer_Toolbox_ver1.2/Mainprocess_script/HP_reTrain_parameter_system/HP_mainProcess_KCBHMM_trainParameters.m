function HP_mainProcess_KCBHMM_trainParameters(saveFile_dir, train_chroma_fileName, train_anns_fileName, parameter_file)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function 
%HP_mainProcess_KCBHMM_trainParameters(saveFile_dir, train_chroma_fileName, train_anns_fileName, parameter_file)
%
%Main Process (template) three:
%Training the KCB-HMM parameters.
%   Emission:
%   P(C|c)=Gaussian (chord chromagram emmission)
%   P(B|b)=Gaussian (bass chromagram emission)
%   Transition:
%   P(c2|c1)=p(c1->c2) the chord transition model
%Remark: the chord transition model will transposition 12 times to get the
%most likely paths.
%   P(b1|c1)=p(c1->b1) the chord bass transition model
%   P(b2|b1)=p(b1->b2) the bass transition model
%
%Remark:
%1. The training data file should contain:
%bass_normal_chromagram, treble_normal_chromagram, sample_times.
%2. The training annotation file should contain:
%binary_table, chord_classes, chord_class_dict, key_classes, key_class_dict.
%
% INPUTS
%saveFile_dir - The directory to save the chromagram features and beat times.
%train_chroma_fileName - The file name of the training chromagram (mat file)
%train_anns_fileName - The file name of the training annoations (from
%                      HP_mainProcess_extractAnnotations.m).
%parameter_file   - The directories and names to store the parameter file.
%
%---------------------------------------------
%Function created by Y. Ni
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%0. Configulation
disp('Main process three: Training the KCB-HMM parameters.');
disp('***************************************');
disp('');

%A. The training data directory
pseudo_count=1.0;    %The pseudo count for all transition matrix
keyNum_del=10;      %Delete the key transitions which occur less than keyNum_del times

dataDB=saveFile_dir; %The chromagram and annotation directory
trainDataFile=train_chroma_fileName;
trainAnnotationFile=train_anns_fileName;


%1. Loading data
disp('Step 1. Loading the data....');
disp('--------------------------------------------------------');
disp('');

%1.1 Loading the chromagram features
trainData=load([dataDB,trainDataFile]);
numTrainSong=length(trainData.treble_normal_chromagrams); %#training songs


%%%%%%%%%%%%Combine the features (24 dims) %%%%%%%%%%%%
nDim_treble=size(trainData.treble_normal_chromagrams{1},1);
nDim_bass=size(trainData.bass_normal_chromagrams{1},1);
train_normal_chromas=cell(1,numTrainSong);
for i=1:numTrainSong
    train_normal_chromas{i}=[trainData.treble_normal_chromagrams{i};trainData.bass_normal_chromagrams{i}];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%1.2 Loading the annotations
trainAnnotation=load([dataDB,trainAnnotationFile]);
classes=trainAnnotation.chord_classes;
class_dict=trainAnnotation.chord_class_dict;
key_classes=trainAnnotation.key_classes;
key_class_dict=trainAnnotation.key_class_dict;
binary_table=trainAnnotation.binary_table;

%1.3 key/chord/bass transposition
numKeys=24;
key_annotations=trainAnnotation.key_annotations;
%A. Get all transpositions of the sequences
GT_transpositions=KCB_annotation_transition(trainAnnotation.chord_annotations,key_annotations,trainAnnotation.bass_annotations,trainAnnotation.binary_table, numKeys);

%1.4 bass selections (only take the root note, first inversion and second inversion) for majmin setup; 
%for complex chord setup the bass notes are extracted according to the chord label. 

if (length(classes)<=25)
    %%%Reduced to bass notes for complex each chord %%%
    [nstates,num_note]=size(binary_table);
    num_bass=num_note+1;
    
    state_to_bass=cell(1,nstates);
    state_to_bass_binary=zeros(nstates,num_bass);
    state_to_bass_binary(:,1:num_note)=binary_table;
    for i=1:nstates-1
        state_to_bass{i}=find(state_to_bass_binary(i,:));
    end
    %The no chord (no-bass) class
    state_to_bass_binary(end,end)=1;
    state_to_bass{end}=num_bass;
    
else
    %%%Reduced to bass notes for complex each chord %%%
    [nstates,num_note]=size(binary_table);
    num_bass=num_note+1;
    complex_keys=class_dict.keys();
    reduced_note=reduce_to_bass(complex_keys);
    
    state_to_bass_binary=zeros(nstates,num_bass);
    state_to_bass=cell(1,nstates);
    
    for i=1:length(complex_keys)
        if (reduced_note(i)<=num_bass)
            state_to_bass_binary(class_dict(complex_keys{i}),reduced_note(i))=1;
        end
    end
    
    for i=1:nstates-1
        state_to_bass{i}=find(state_to_bass_binary(i,:));
    end
    
    %For no-chord
    state_to_bass_binary(end,end)=1;
    state_to_bass_binary(end,:)=0;
    state_to_bass{end}=num_bass;
end


%2. Pre-process of the annotations and chromagrams (add slience at the
%beginning and the end)
disp('Step 2.Pre-processing....');
disp('--------------------------------------------------------');
disp('');
normal_chromas_bass=cell(1,numTrainSong);
normal_chromas_treble=cell(1,numTrainSong);
ch_annotations=cell(1,numTrainSong);
bass_annotations=cell(1,numTrainSong);
for i=1:numTrainSong
    ch_annotations{i}=[nstates trainAnnotation.chord_annotations{i} nstates];
    normal_chromas_bass{i}=[zeros(nDim_bass,1) trainData.bass_normal_chromagrams{i} zeros(nDim_bass,1)];
    normal_chromas_treble{i}=[zeros(nDim_treble,1) trainData.treble_normal_chromagrams{i} zeros(nDim_treble,1)];
    train_normal_chromas{i}=[zeros(nDim_treble+nDim_bass,1) train_normal_chromas{i} zeros(nDim_treble+nDim_bass,1)];
    key_annotations{i}=[numKeys+1 key_annotations{i} numKeys+1];
    bass_annotations{i}=[num_bass, trainAnnotation.bass_annotations{i}, num_bass];
end

%3. Normal maxGamma parameter training (Maximum Likelihood Estimation)
disp('Step 3. Train normal HMM parameters....');
disp('--------------------------------------------------------');
disp('');

tic
[mu_maxGamma, Sigma_maxGamma] = hmm_train_gaussian(train_normal_chromas, ch_annotations, nstates);
[transmat_maxGamma,initState_maxGamma] = hmm_train_transmat(ch_annotations, nstates, pseudo_count);
toc



%4. KCB-HMM parameter training (Maximum Likelihood Estimation)
disp('Step 4. Train KCB-HMM parameters....');
disp('--------------------------------------------------------');
disp('');

tic
%4.1 Train the Gaussian observation probability model for chord
%A. Chord Gaussian
[mu_chord, Sigma_chord] = hmm_train_gaussian(normal_chromas_treble, ch_annotations, nstates);
[org_transmat,initState] = hmm_train_transmat(ch_annotations, nstates, pseudo_count);

%B. Bass Gaussian
[mu_bass, Sigma_bass] = hmm_train_gaussian(normal_chromas_bass, bass_annotations, num_bass);
[org_transmat_bass,initState_bass] = hmm_train_transmat(bass_annotations, num_bass);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%4.2 Train the key/chord/bass transition probability
%A. P(c2|c1,k2)
[transmat] = hmm_train_keybased_chord_transmat(GT_transpositions.chord_annotations, GT_transpositions.key_annotations, nstates, numKeys, pseudo_count);

%B. P(b2|b1)
[bassPrev_bass_transmat] = hmm_train_bass_transmat(GT_transpositions.bass_annotations, num_bass, pseudo_count);

%C. P(b1|c1)
[chord_bass_transmat] = hmm_train_chord_bass_transmat(GT_transpositions.chord_annotations,GT_transpositions.bass_annotations, state_to_bass_binary);


%D. P(k2|k1)
[key_transmat,key_transBag]=hmm_train_key_transmat(key_annotations, numKeys, keyNum_del);


%5. Save the parameters
save(parameter_file,'Sigma_bass','Sigma_chord','Sigma_maxGamma','bassPrev_bass_transmat','binary_table','chord_bass_transmat','classes','class_dict','key_classes','key_class_dict','initState','initState_maxGamma','key_transBag','key_transmat','mu_bass','mu_chord','mu_maxGamma','state_to_bass','state_to_bass_binary','transmat','transmat_maxGamma');


disp('done'); 
