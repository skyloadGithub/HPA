function [bass_normal_chromagrams,treble_normal_chromagrams,beat_times,sample_times]=MIR_mainProcess_extractFeatures_forHPGUI(audio_name,global_options,text_handle)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function [bass_normal_chromagrams,treble_normal_chromagrams,beat_times,sample_times]=
%MIR_mainProcess_extractFeatures_forHPGUI(audio_name,global_options, text_handle)
%
%Main Process One:
%Extracting the chromagram features from the audio.
%Generating the following contents:
%1. Generating the harmony of the audio (HPSS).
%2. Computing the tuning of the audio.
%3. Computing the beat times of the audio.
%4. Extracting the chromagrams (default: bass (F:55-207, R:2); treble
%                              (F:220-1661, R:5).
%
% INPUTS
%audio_name - The audio name (1 string for HP GUI interface).
%global_options The global options for extracting the chromagram features
%text_handle - The handle of the text to show the process.
%
% OUTPUTS
%bass_normal_chromagrams - The bass chromagrams.
%treble_normal_chromagrams - The treble chromagrams.
%beat_times - The beat times, 1 x (N-1) vector.
%sample_times - The sample times, N x 2 matrix.
%
%---------------------------------------------
%Function created by Y. Ni
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%1. Initialization
set(text_handle,'string','Main Process One: extracting the loudness based chromagram features.');
pause(0.5);
disp('Main Process One: extracting the loudness based chromagram features.');

if nargin<2
    %A. frequency range and resolution factor of bass chromagram
    bass_fmin=55;
    bass_fmax=207;
    bass_resolution_fact=2;
    %B. frequency range and resolution factor of treble chromagram
    treble_fmin=220;
    treble_fmax=1661;
    treble_resolution_fact=5;
    %C. resampling rate
    resample_rate=11025;
else
    %A. bass chromagrams
    if ~isfield(global_options,'bass_fmin'); bass_fmin=55; else bass_fmin=global_options.bass_fmin; end
    if ~isfield(global_options,'bass_fmax'); bass_fmax=207; else bass_fmax=global_options.bass_fmax; end
    if ~isfield(global_options,'bass_resolution_fact'); bass_resolution_fact=2; else bass_resolution_fact=global_options.bass_resolution_fact; end
    
    %B. treble chromagrams
    if ~isfield(global_options,'treble_fmin'); treble_fmin=220; else treble_fmin=global_options.treble_fmin; end
    if ~isfield(global_options,'treble_fmax'); treble_fmax=1661; else treble_fmax=global_options.treble_fmax; end
    if ~isfield(global_options,'treble_resolution_fact'); treble_resolution_fact=5; else treble_resolution_fact=global_options.treble_resolution_fact; end
    
    %C. Resampleing rate
    if ~isfield(global_options,'SR'); resample_rate=11025; else resample_rate=global_options.SR; end

end
    

%C. The audio directory
options=struct;
options.wavwrite=0;
options.display=0;
options.resample_rate=resample_rate;


%2. Extracting the chromagrams
t_start=tic;
[xharmony,tunings,SR,beat_times,options]=...
    extract_harmony_from_audio(audio_name,options);
t_end=toc(t_start);
set(text_handle,'string',['Extracted the Harmonic content using HPSS (',num2str(t_end),' s).']);
pause(0.5);
disp(['Extracted the Harmonic content using HPSS (',num2str(t_end),' s).']);


%B. Extract features from the harmony (bass)
t_start=tic;
options.fmin=bass_fmin;
options.fmax= bass_fmax;
options.resolution_fact=bass_resolution_fact;
[trash, bass_normal_chromagrams, sample_times]=extract_feature_from_harmony(xharmony,tunings,SR,beat_times,options);
t_end=toc(t_start);

set(text_handle,'string',['Extracted the bass chromagrams (',num2str(t_end),' s).']);
pause(0.5);
disp(['Extracted the bass chromagrams (',num2str(t_end),' s).']);


%C. Extract features from the harmony (treble)
t_start=tic;
options.fmin=treble_fmin;
options.fmax= treble_fmax;
options.resolution_fact=treble_resolution_fact;
[trash, treble_normal_chromagrams]=extract_feature_from_harmony(xharmony,tunings,SR,beat_times,options);
t_end=toc(t_start);

set(text_handle,'string',['Extracted the treble chromagrams (',num2str(t_end),' s).']);
pause(0.5);
disp(['Extracted the treble chromagrams (',num2str(t_end),' s).']);



