function [HP_prediction, classes] = HP_PretrainSystem_forHP_GUI(test_chromas_bass, test_chromas_treble, pretrainFile_dir, pretrainFile_name, wFlag, text_handle)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function HP_prediction = 
%HP_PretrainSystem_forHP_GUI(test_chromas_bass, test_chromas_treble, pretrainFile_dir, pretrainFile_name, wFlag, text_handle)
%
%Main Process Two:
%(Designed for beat-chromagram features, can use min/maj (25) or full chord (121) chord dictionaries)
%1. Normal HMM (maxGamma decoder)
%2. Key-chord-bass (KCB) HMM
%   Predict key/chord/bass simutaneously
%3. Principle:
%   Emission:
%   P(C|c)=Gaussian (chord chromagram emmission)
%   P(B|b)=Gaussian (bass chromagram emission)
%   Transition:
%   P(c2|c1,k2)=p(c1->c2|k2) the key dependent chord transition model
%   P(b1|c1)=p(c1->b1) the key independent chord bass transition model
%   P(b2|b1)=p(b1->b2) the key independent bass transition model
%   P(k2|k1)=p(mod(k2-k1,numKeys)) the key transition model
%
%Remark: should read the Pretrained parameters (in the folder "pre_trainSystem").
%
% INPUTS
%test_chromas_bass - The bass chromagram.
%test_chromas_treble - The treble chromagram.
%pretrainFile_dir - The directory to load the pretrained system.
%pretrainFile_name - The file name of the pretrained system (mat file).
%wFlag - 0. Return the normal maxGamma prediction.
%        1. Return HP prediction.
%text_handle - The handle of the text to show the process.
%
% OUTPUTS
%HP_prediction - The HP chord prediction (indices format).
%classes - The chord names for each index.
%
%---------------------------------------------
%Function created by Y. Ni
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%0. Configulation
set(text_handle,'string','Main Process Two: running HP system for chord predictions.');
pause(0.5);
disp('Main Process Two: running HP system for chord predictions.');

t_start=tic;
%A. Loading the pretrained system
load([pretrainFile_dir, pretrainFile_name]);

%B. Decoder configulation
maxGammaReduction=1; %1. Using max Gamma prediction to reduce the number of chords
                     %0. Using all chord matrix
keyReduction=1;      %1. Using key reduction (producing non-symmetric hyper-transmat matrix and save searching time)
                     %0. Using normal hyper-transmat matrix


%1. Pre-processing the data

%%%%%%%%%%%%Combine the features (24 dims) %%%%%%%%%%%%
nDim_treble=size(test_chromas_treble,1);
nDim_bass=size(test_chromas_bass,1);
test_normal_chromas=[test_chromas_treble;test_chromas_bass];

test_normal_chromas=[zeros(nDim_treble+nDim_bass,1) test_normal_chromas zeros(nDim_treble+nDim_bass,1)];
test_chromas_bass=[zeros(nDim_bass,1) test_chromas_bass zeros(nDim_bass,1)];
test_chromas_treble=[zeros(nDim_treble,1) test_chromas_treble zeros(nDim_treble,1)];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%2. Normal maxGamma decoder
[sigma_inv,sigma_det_inv] = gaussian_sigma_inverse(Sigma_maxGamma);
B = hmm_mixgauss_prob(test_normal_chromas,mu_maxGamma,sigma_inv,sigma_det_inv,0);
normalViterbiMatrix=maxGammaDecoder(initState_maxGamma,B,transmat_maxGamma);

if (wFlag==0) %write down the maxGamma predictions
    HP_prediction=normalViterbiMatrix;
    return;
end


%3. KCB HMM-Viterbi
%3.1 Train the Gaussian observation probability model for chord
%A. Chord Gaussian
[sigma_inv_chord,sigma_det_inv_chord] = gaussian_sigma_inverse(Sigma_chord);
initState=log(initState);

%B. Bass Gaussian
[sigma_inv_bass,sigma_det_inv_bass] = gaussian_sigma_inverse(Sigma_bass);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%3.2 Train the key/chord/bass transition probability
%A. P(c2|c1,k2)
transmat=log(transmat);

%B. P(b2|b1)
bassPrev_bass_transmat=log(bassPrev_bass_transmat);

%C. P(b1|c1)
chord_bass_transmat=log(chord_bass_transmat);


%D. P(k2|k1)
key_transmat=log(key_transmat); %Take the log


%Variation one: without MaxGamma chord reduction
if (maxGammaReduction==0)
    %3.3 Create the hyper transition matrix (hyper-transmat)
    if (keyReduction) %key reduction version
        [hyperTransmat,hyperLinks, transLinks]=createHyperTransmat_var(key_transmat,transmat,key_transBag,chord_bass_transmat,bassPrev_bass_transmat,state_to_bass);
    else              %Non-key reduction version
        [hyperTransmat,hyperLinks]=createHyperTransmat(key_transmat,transmat,chord_bass_transmat,bassPrev_bass_transmat,state_to_bass);
    end
    
    %3.4 Key-specific Viterbi decoder
    %A. Compute the emission probability (chord and bass)
    %Chord emission (log form)
    B_chord = hmm_mixgauss_prob(test_chromas_treble,mu_chord,sigma_inv_chord,sigma_det_inv_chord,1);
    
    %Bass emission (log form)
    B_bass = hmm_mixgauss_prob(test_chromas_bass,mu_bass,sigma_inv_bass,sigma_det_inv_bass,1);
    
    %B. KBC Viterbi decoder
    if (keyReduction)
        [KCBViterbi_chord_Matrix,KCBViterbi_score,KCBViterbi_key_Matrix,KCBViterbi_bass_Matrix]=key_bass_viterbiDecoder(initState,hyperTransmat,hyperLinks,B_chord,B_bass,1,transLinks);
    else
        [KCBViterbi_chord_Matrix,KCBViterbi_score,KCBViterbi_key_Matrix,KCBViterbi_bass_Matrix]=key_bass_viterbiDecoder(initState,hyperTransmat,hyperLinks,B_chord,B_bass,1);
    end
    
    
%Variation two: using MaxGamma chord reduction
else
    %3.4 Key-specific Viterbi decoder
    %A. Compute the emission probability (chord and bass)
    %Chord emission (log form)
    B_chord = hmm_mixgauss_prob(test_chromas_treble,mu_chord,sigma_inv_chord,sigma_det_inv_chord,1);
    
    %Bass emission (log form)
    B_bass = hmm_mixgauss_prob(test_chromas_bass,mu_bass,sigma_inv_bass,sigma_det_inv_bass,1);
    
    %B. Creating the song specific transmat matrix
    reduced_notes=unique(normalViterbiMatrix);
    if (isempty(reduced_notes))
        error('Error in HP_PretrainSystem_forHP_GUI: No reduced notes from the max-Gamma decoder.');
    end
    
    %C. KBC song specific Viterbi decoder
    if (keyReduction)
        [song_hyperTransmat,song_hyperLinks,song_transLinks] = createHyperTransmat_var(key_transmat,transmat,key_transBag,chord_bass_transmat,bassPrev_bass_transmat,state_to_bass,reduced_notes);
        [KCBViterbi_chord_Matrix,KCBViterbi_score,KCBViterbi_key_Matrix,KCBViterbi_bass_Matrix]=key_bass_viterbiDecoder(initState,song_hyperTransmat,song_hyperLinks,B_chord,B_bass,1,song_transLinks);
    else
        [song_hyperTransmat,song_hyperLinks] = createHyperTransmat(key_transmat,transmat,chord_bass_transmat,bassPrev_bass_transmat,state_to_bass,reduced_notes);
        [KCBViterbi_chord_Matrix,KCBViterbi_score,KCBViterbi_key_Matrix,KCBViterbi_bass_Matrix]=key_bass_viterbiDecoder(initState,song_hyperTransmat,song_hyperLinks,B_chord,B_bass,1);
    end
end

if (wFlag==1) %write down the KCB predciction
    HP_prediction=KCBViterbi_chord_Matrix;
end

t_end=toc(t_start);

set(text_handle,'string',['Main Process two takes ',num2str(t_end),' seconds.']);
disp(['Main Process two takes ',num2str(t_end),' seconds.']);
return;



