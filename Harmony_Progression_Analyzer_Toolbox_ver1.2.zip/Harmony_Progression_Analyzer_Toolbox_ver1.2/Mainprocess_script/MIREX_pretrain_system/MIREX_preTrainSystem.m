function MIREX_preTrainSystem(audio_dir, saveFile_dir, prediction_dir, toolbox_dir, parallel_flag, modelLabel)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function MIREX_preTrainSystem(audio_dir, saveFile_dir, prediction_dir, toolbox_dir, parallel_flag, modelLabel)
%
%The HP Pre-trained system.
%
% INPUTS
%audio_dir - The directory and file names of the audio (.txt file).
%Remark: each line is a path for a song, should end with .wav.
%saveFile_dir - The temp directory to store the chromagrams and annotations.
%prediction_dir - The directory for the predictions.
%Remark: the prediction filename is audio_file_name_prediction.txt.
%toolbox_dir - The directory of the toolbox
%parallel_flag - 1. Using parallel processor for feature extraction.
%                0. Otherwise.
%modelLabel - minmaj: the minor/major chord system; full: the MM chord system.
%
%---------------------------------------------
%Function created by Y. Ni
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%0. Configulation
% toolbox_dir = pwd;
% addpath(genpath(toolbox_dir));


%A. parallel processing?
if (nargin<6)
    modelLabel='minmaj'; %default minmaj system
elseif (nargin<5)
    parallel_flag=0; %default non-parallel
end

%B. The file names of chromagram features and the predictions
if (~(strcmp(prediction_dir(end),'\') || strcmp(prediction_dir(end),'/')))
    prediction_dir=[prediction_dir,'\'];
end

audio_names={};
prediction_fileNames={};
countSongs=0;
fid=fopen(audio_dir,'r');
tline=fgetl(fid);
while(ischar(tline))
    tline=regexprep(tline,'\s+$',''); %delte \n
    if (~isempty(tline))
        fslashes=strfind(tline,'/');
        
        if isempty(fslashes)
            % No slash, so local or linux
            bslashes=strfind(tline,'\');
            if isempty(bslashes)
                % Local file
                filename=tline;
            else
                % Linux style
                lastslash=bslashes(end);
                filename=tline(lastslash+1:end-4);
            end
            
        else
            % Windows style
            lastslash=fslashes(end);
            filename=tline(lastslash+1:end-4);
        end
        
        tline=regexprep(tline,'\s+$',''); %delte \n
        if (strcmp(tline(end-3:end),'.wav'))
            countSongs=countSongs+1;
            audio_names{countSongs}=tline;
            prediction_fileNames{countSongs}=[prediction_dir,filename,'_prediction.txt'];
        end
    end
    
    tline=fgetl(fid);
end
fclose(fid);

disp(['All together, there are: ',int2str(countSongs),' songs.']);
disp('');

saveFileName_test_chroma='test_chroma';
saveFileName_test_beat='test_beat';
pretrainFile_dir=[toolbox_dir,'pre_trainSystem/'];

if (strcmpi(modelLabel,'minmaj'))
    pretrainFile_name='MIREX_minmaj_PretrainSystem_reFinedAnns_091111';
elseif(strcmpi(modelLabel,'full'))
    pretrainFile_name='MIREX_fullChord_PretrainSystem_reFinedAnns_091111';
end


%1. Extracting chromagram features
if (parallel_flag)
    [saveFile_dir,saveFileName_test_chroma]=MIR_parallel_mainProcess_extractFeatures(audio_names,saveFile_dir,saveFileName_test_chroma,saveFileName_test_beat);
else
    [saveFile_dir,saveFileName_test_chroma]=MIR_mainProcess_extractFeatures(audio_names,saveFile_dir,saveFileName_test_chroma,saveFileName_test_beat);
end

%2. HP Prediction
MIREX_mainProcess_KCBHMM_PretrainSystem(saveFile_dir, saveFileName_test_chroma, prediction_fileNames, pretrainFile_dir, pretrainFile_name);


