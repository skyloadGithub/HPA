function [saveFile_dir,saveFileName_chroma,saveFileName_beat]=MIR_parallel_mainProcess_extractFeatures(audio_names,saveFile_dir,saveFileName_chroma,saveFileName_beat)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function [saveFile_dir,saveFileName_chroma,saveFileName_beat]
%=MIR_parallel_mainProcess_extractFeatures(audio_names,saveFile_dir,saveFileName_chroma,saveFileName_beat)
%
%Main Process (parallel template) One:
%Extracting the chromagram features from the audio.
%Generating the following contents:
%1. Generating the harmony of the audio (HPSS).
%2. Computing the tuning of the audio.
%3. Computing the beat times of the audio.
%4. Extracting the chromagrams (default: bass (F:55-207, R:2); treble
%                              (F:220-1661, R:5).
%
% INPUTS
%audio_names - The audio directories and names (a 1 x N cell array).
%saveFile_dir - The directory to save the chromagram features and beat times.
%saveFileName_chroma - The file name of the chromagram features.
%saveFileName_beat - The file name of the beat and sample times.
%
% OUTPUTS
%saveFile_dir - The directory to save the chromagram features and beat times.
%saveFileName_chroma - The file name of the chromagram features.
%saveFileName_beat - The file name of the beat and sample times.
%
%---------------------------------------------
%Function created by Y. Ni
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

matlabpool open
%0. Configulation
disp('Main process one: Feature extraction (taking < 30 mins).');
disp('*************************************');
disp('');


%A. frequency range and resolution factor of bass chromagram
bass_fmin=55;
bass_fmax=207;
bass_resolution_fact=2;
%B. frequency range and resolution factor of treble chromagram
treble_fmin=220;
treble_fmax=1661;
treble_resolution_fact=5;
%C. The audio directory and save directory
options=struct;
if (nargin<4); saveFileName_beat='beatSaveFile'; end
if (nargin<3); saveFileName_chroma='chromagramSaveFile'; end
if (nargin<2)
    options.directory='./temp/';
    mkdir(options.directory);
else
    options.directory=saveFile_dir;
end


%1. Get filenames of audios
options.wavwrite=0;
options.display=0;
N_songs=length(audio_names);          %#songs
beat_times=cell(1,N_songs);           %store the beat time 1xNbeats
tunings=zeros(1,N_songs);             %store the tunings
sample_times=cell(1,N_songs);         %store the sample times Nintervals x 2
bass_chromagrams=cell(1,N_songs);          %store the loudness based chromagrams (bass)
bass_normal_chromagrams=cell(1,N_songs);   %store the normalized chromagrams (bass)
treble_chromagrams=cell(1,N_songs);        %store the loudness based chromagrams (treble)
treble_normal_chromagrams=cell(1,N_songs); %store the normalized chromagrams (treble)

  
%2. For each song 
disp('Extract the chromagrams (bass and treble) for each song.');
disp('--------------------------------------------------------');
disp('');

tic
parfor i=1:N_songs  
    %A. Extract harmony from the audio, get tuning and beats as well
    songname=audio_names{i};
    [xharmony,par_tunings,SR,par_beat_times,par_options]=...
        extract_harmony_from_audio(songname,options);
        
    %B. Extract features from the harmony (bass)
    par_options.fmin=bass_fmin;
    par_options.fmax= bass_fmax;
    par_options.resolution_fact=bass_resolution_fact;
    [par_bass_chromagrams, par_bass_normal_chromagrams, par_sample_times]=extract_feature_from_harmony(xharmony,par_tunings,SR,par_beat_times,par_options);
    
    %C. Extract features from the harmony (treble)
    par_options.fmin=treble_fmin;
    par_options.fmax= treble_fmax;
    par_options.resolution_fact=treble_resolution_fact;
    [par_treble_chromagrams, par_treble_normal_chromagrams]=extract_feature_from_harmony(xharmony,par_tunings,SR,par_beat_times,par_options);
    
    %D. Return the results
    tunings(i)=par_tunings;
    beat_times{i}=par_beat_times;
    bass_chromagrams{i}=par_bass_chromagrams;
    bass_normal_chromagrams{i}=par_bass_normal_chromagrams;
    sample_times{i}=par_sample_times;
    treble_chromagrams{i}=par_treble_chromagrams;
    treble_normal_chromagrams{i}=par_treble_normal_chromagrams;
end
toc

matlabpool close

%3. Save the chromagrams
disp('Save the chromagram features.');
disp('--------------------------------------------------------');
disp('');
save([options.directory,saveFileName_chroma],'audio_names','bass_chromagrams','bass_normal_chromagrams','treble_chromagrams','treble_normal_chromagrams','tunings','beat_times','sample_times');
save([options.directory,saveFileName_beat],'beat_times','sample_times');

disp('done');