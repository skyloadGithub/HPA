function [saveFileName_annotation] = MIR_mainProcess_extractAnnotations(ground_truth_names,saveFile_dir,saveFileName_beat,saveFileName_annotation)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function [saveFileName_annotation] 
%= MIR_mainProcess_extractAnnotations(ground_truth_names,saveFile_dir,saveFileName_beat,saveFileName_annotation)
%
%Main Process (template) Two:
%Extracting the annotations from the ground truth.
%Including: binary_table, classes, class_dict (Map).
%Default: using beat-synchronized features (beat_times required).
%
%Remark:
%The ground truth format should be in C. Harte's format!
%I.e. start_times end_times chords.
%
% INPUTS
%ground_truth_names - The file names (or the directory) of the ground truths.
%saveFile_dir - The directory to save the chromagram features and beat times.
%saveFileName_beat - The file name of the beat and sample times.
%saveFileName_annotation - The file name of the (training) annotations.
%
% OUTPUTS
%saveFileName_annotation - The file name of the (training) annotations.
%
%---------------------------------------------
%Function created by Y. Ni
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%0. Configulation
disp('Main process two: Annotation extraction (taking < 1 mins).');
disp('****************************************');
disp('');

%A. The reduced-chord format (minmaj, triads, quads, mm, etc).
alphabet='minmaj';
format='rlab';
%C. The beat time directory
options.directory=saveFile_dir;
load([options.directory,saveFileName_beat]);
if (nargin<4); saveFileName_annotation='annotationSaveFile'; end


%1. Construct the binary table and the class dictionary
if (iscell(ground_truth_names))
    numSong=length(ground_truth_names);
else
    ground_truth_names=getAllFiles(ground_truth_names);
    numSong=length(ground_truth_names);
end
[binary_table,classes,class_dict]=get_global_binary_table(ground_truth_names,format,alphabet);


%2. Get the reduced-chord annotations for each song
disp('Start extracting the chord annotations.');
disp('--------------------------------------------------------');
disp('');

tic
annotations=cell(1,numSong);
for song=1:numSong
    annotations{song}=extract_ground_truth(ground_truth_names{song},...
    'CH',classes,class_dict,alphabet,beat_times{song},'beatsynch'); 
end
toc

%3. Get the bass annotations for each song
disp('Start extracting the bass annotations.');
disp('--------------------------------------------------------');
disp('');

tic
bass_annotations=cell(1,numSong);
alphabet='bass';
for song=1:numSong
    bass_annotations{song}=extract_ground_truth(ground_truth_names{song},...
    'CH',classes,class_dict,alphabet,beat_times{song},'beatsynch'); 
end
toc

%4. Save the annotations
save([options.directory,saveFileName_annotation],'annotations','bass_annotations','beat_times','sample_times','binary_table','classes','class_dict');

disp('done'); 
    
