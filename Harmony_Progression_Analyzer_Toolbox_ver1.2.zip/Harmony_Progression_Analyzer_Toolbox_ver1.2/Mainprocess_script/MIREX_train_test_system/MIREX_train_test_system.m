function MIREX_train_test_system(train_audio_annotation_dir, saveFile_dir,test_audio_dir, prediction_dir,  toolbox_dir, parallel_flag)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function MIREX_train_test_system(train_audio_annotation_dir, saveFile_dir,test_audio_dir, prediction_dir,  toolbox_dir, parallel_flag)
%
%The HP train-test system.
%
% INPUTS
%train_audio_dir - The directory and file names of the train audio and annotations.
%Remark: for example for "/path/to/trainFile1.wav", there will be a corresponding 
%ground truth file called "/path/to/trainFile1.wav.txt".
%saveFile_dir - The temp directory to store the chromagrams and annotations.
%test_audio_dir - The directory and file names of the test audio.
%prediction_dir - The output directory and file names for the audio.
%Remark: the test_auido_names and prediction_fileNames should be in the same
%        order! The prediction filename is test_audio_name_prediction.txt.
%parallel_flag - 1. Using parallel processor for feature extraction.
%                0. Otherwise.
%
%---------------------------------------------
%Function created by Y. Ni
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%0. Configulation
% toolbox_dir = pwd;
addpath(genpath(toolbox_dir));

%A. parallel processing?
if (nargin<6)
    parallel_flag=0;
end

%B. The file names of training chromagram features and the predictions
train_audio_names={};
train_annotation_names={};
countSongs=0;
fid=fopen(train_audio_annotation_dir,'r');
tline=fgetl(fid);
while(ischar(tline))
    tline=regexprep(tline,'\s+$',''); %delte \n
    if (~isempty(tline))
        if (strcmp(tline(end-3:end),'.wav'))
            countSongs=countSongs+1;
            train_audio_names{countSongs}=tline;
            train_annotation_names{countSongs}=[tline,'.txt'];
        end
    end
    tline=fgetl(fid);
end

disp(['All together, there are: ',int2str(countSongs),' training songs.']);
disp('');


%C. The file names of test chromagram features and the predictions
if (~(strcmp(prediction_dir(end),'\') || strcmp(prediction_dir(end),'/')))
    prediction_dir=[prediction_dir,'\'];
end
fclose(fid);

test_audio_names={};
prediction_fileNames={};
countSongs=0;
fid=fopen(test_audio_dir,'r');
tline=fgetl(fid);
while(ischar(tline))
    tline=regexprep(tline,'\s+$',''); %delte \n
    if (~isempty(tline))
        fslashes=strfind(tline,'/');
        if isempty(fslashes)
            % No slash, so local or linux
            bslashes=strfind(tline,'\');
            if isempty(bslashes)
                % Local file
                filename=tline;
            else
                % Linux style
                lastslash=bslashes(end);
                filename=tline(lastslash+1:end-4);
            end
            
        else
            % Windows style
            lastslash=fslashes(end);
            filename=tline(lastslash+1:end-4);
        end
        
        if (strcmp(tline(end-3:end),'.wav'))
            countSongs=countSongs+1;
            test_audio_names{countSongs}=tline;
            prediction_fileNames{countSongs}=[prediction_dir,filename,'_prediction.txt'];
        end
    end
    
    tline=fgetl(fid);
end

fclose(fid);
disp(['All together, there are: ',int2str(countSongs),' test songs.']);
disp('');


saveFileName_train_chroma='train_chroma';
saveFileName_test_chroma='test_chroma';
saveFileName_train_beat='train_beat';
saveFileName_test_beat='test_beat';
saveFileName_train_annotation='train_annotations';


%1. Extracting chromagram features
if (parallel_flag)
   
    %A. training chromagram
    [saveFile_dir,saveFileName_train_chroma,saveFileName_train_beat]=MIR_parallel_mainProcess_extractFeatures(train_audio_names,saveFile_dir,saveFileName_train_chroma,saveFileName_train_beat);
    %B. test chromagram
    [saveFile_dir,saveFileName_test_chroma]=MIR_parallel_mainProcess_extractFeatures(test_audio_names,saveFile_dir,saveFileName_test_chroma,saveFileName_test_beat);
else
    %A. training chromagram
    [saveFile_dir,saveFileName_train_chroma,saveFileName_train_beat]=MIR_mainProcess_extractFeatures(train_audio_names,saveFile_dir,saveFileName_train_chroma,saveFileName_train_beat);
    %B. test chromagram
    [saveFile_dir,saveFileName_test_chroma]=MIR_mainProcess_extractFeatures(test_audio_names,saveFile_dir,saveFileName_test_chroma,saveFileName_test_beat);
end

%2. Extracting the annotations
[saveFileName_train_annotation] = MIR_mainProcess_extractAnnotations(train_annotation_names,saveFile_dir,saveFileName_train_beat,saveFileName_train_annotation);

%3. CB train-test system
MIREX_mainProcess_CBHMM_train_test(saveFile_dir, saveFileName_train_chroma, saveFileName_test_chroma, saveFileName_train_annotation, prediction_fileNames);

