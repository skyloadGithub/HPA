function predictionStr=MIR_generate_prediction_string(states,sample_times,classes)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function MIR_writePrediction_to_file(states,sample_times,classes,filename)
%
% This function takes a vector of states (indices) and sample times (start and 
% end) and writes a mirex-style .txt file.
%
% INPUTS  - states. Vector of indices (integers)
%         - sample_times. Vector of start and end times of feature
%           dimensions as feature, so length(states)x2.
%         - classes. The chord dictionary, chord index -> chord name(s).
%
% OUTPUTS - predictionStr. The prediction string for ID3 tag.
%           Format: chord start_time_stamp chord start_time_stamp....
%
%---------------------------------------------
%Function created by Y. Ni
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%  1. Initialise %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
chords=cell(1,length(states));
for i=1:length(states)
   chords{i}=classes{states(i)}{1}; 
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%% 3. Write a text file %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%         
         
% Open a text file for writin
predictionStr=[];

% Convert to character array
C=char(chords');

% Print double, double, string

%%%%%%%%%%%%%%%%%%%%%%%%%FOR USLT frame %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% current_chord=strtrim(C(1,:));
% current_start_time=sample_times(1,1);
% current_end_time=sample_times(1,2);
% if (size(C,1)==1)
%     predictionStr=[predictionStr, num2str(current_start_time),' ',current_chord,' ',num2str(current_end_time),' '];
% else
%     for j=2:size(C,1)
%         temp_chord=strtrim(C(j,:));
%         if (strcmp(temp_chord,current_chord))
%             current_end_time=sample_times(j,2);
%         else
%             predictionStr=[predictionStr, num2str(current_start_time),' ',current_chord,' '];
%             current_chord=temp_chord;
%             current_start_time=sample_times(j,1);
%             current_end_time=sample_times(j,2);
%         end
%     end
%     %Print the last chord
%     predictionStr=[predictionStr, num2str(current_start_time),' ',current_chord,' ',num2str(current_end_time)];
% end
%%%%%%%%%%%%%%%%%%%%%%%%%FOR USLT frame %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%FOR SYLT frame %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sample_times=floor(sample_times(:,1)*1000); %Transfer it to milliseconds
current_start_time=sample_times(1);
current_chord=strtrim(C(1,:));

if (size(C,1)==1)
    predictionStr=[predictionStr, current_chord,' ',int2str(current_start_time)];
else
    for j=2:size(C,1)
        temp_chord=strtrim(C(j,:));
        if (~strcmp(temp_chord,current_chord))
            predictionStr=[predictionStr,current_chord,' ',int2str(current_start_time),' '];
            current_chord=temp_chord;
            current_start_time=sample_times(j);
        end
    end
    %Print the last chord
    predictionStr=[predictionStr, current_chord,' ',int2str(current_start_time)];
end
%%%%%%%%%%%%%%%%%%%%%%%%%FOR SYLT frame %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


return;

