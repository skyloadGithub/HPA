function MIR_writePrediction_to_file(states,sample_times,classes,filename)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function MIR_writePrediction_to_file(states,sample_times,classes,filename)
%
% This function takes a vector of states (indices) and sample times (start and 
% end) and writes a mirex-style .txt file.
%
% INPUTS  - states. Vector of indices (integers)
%         - sample_times. Vector of start and end times of feature
%           dimensions as feature, so length(states)x2.
%         - classes. The chord dictionary, chord index -> chord name(s).
%         - filename. Desired name of file.
%
% OUTPUTS - none.
%
%---------------------------------------------
%Function created by M. McVicar
%Function revised by Y. Ni
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%  1. Initialise %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
chords=cell(1,length(states));
for i=1:length(states)
   chords{i}=classes{states(i)}{1}; 
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%% 3. Write a text file %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%         
         
% Open a text file for writin
fid = fopen([filename], 'w');

% Convert to character array
C=char(chords');

% Print double, double, string
current_chord=strtrim(C(1,:));
current_start_time=sample_times(1,1);
current_end_time=sample_times(1,2);

if (size(C,1)==1)
    fprintf(fid,'%3f %3f %s\n', current_start_time, current_end_time,...
        current_chord);
else
    for j=2:size(C,1)
        temp_chord=strtrim(C(j,:));
        if (strcmp(temp_chord,current_chord))
            current_end_time=sample_times(j,2);
        else
            fprintf(fid,'%3f %3f %s\n', current_start_time, current_end_time,...
                current_chord);
            current_chord=temp_chord;
            current_start_time=sample_times(j,1);
            current_end_time=sample_times(j,2);
        end
    end
    %Print the last chord
    fprintf(fid,'%3f %3f %s\n', current_start_time, current_end_time,...
        current_chord);
end

% for j=1:size(C,1)
%     fprintf(fid,'%3f %3f %s\n', sample_times(j,1), sample_times(j,2),...
%         strtrim(C(j,:)));
% end

% Close file
fclose(fid);


