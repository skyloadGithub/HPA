function [transmat,initstat] = hmm_train_transmat(hiddenData, nstates, pseudo_count_trans,pseudo_count_inits)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
%[transmat,initstat] = hmm_train_transmat(hiddenData, nstates, pseudo_count)
%
%This function trains the maximum likelihood estimaton (MLE) for the transition 
% and inital probabilities of an HMM model.
%
% INPUTS
%hiddenData - the hidden state sequences. 1xN cell with each cell is a 1xNi
%             vector.
%nstates - the number of Gaussians (states).
%pseudo_count_trans - the pseudo-count of the transition matrix.
%pseudo_count_inits - the pseudo-count of the initial matrix.
%
% OUTPUTS
%transmat - the transition probabilities, a nstates x nstates matrix.
%initstat - the initial probabilities, a nstates x 1 vector.
%
%---------------------------------------------
%Function created by Y. Ni
%Function revised by M. McVicar
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%1. configulation
transmat=zeros(nstates,nstates);
initstat=zeros(nstates,1);
N=length(hiddenData); %The number of examples

if (nargin<3)
    pseudo_count_trans=1;
end

if (nargin<4)
    pseudo_count_inits=eps;

end


%2. compute the counts of the transitions
for i=1:N
    Ni=length(hiddenData{i}); %The length of the sequence
    if (Ni>0)
        initstat(hiddenData{i}(1))=initstat(hiddenData{i}(1))+1;
        for j=2:Ni
            if (hiddenData{i}(j-1)<=nstates && hiddenData{i}(j)<=nstates)
                transmat(hiddenData{i}(j-1),hiddenData{i}(j))=transmat(hiddenData{i}(j-1),hiddenData{i}(j))+1;
            end
        end
    end
end

%3. Normalization
initstat=initstat+pseudo_count_inits;
initstat=initstat/sum(initstat);

transmat=transmat+pseudo_count_trans;
for i=1:nstates
    transmat(i,:)=transmat(i,:)/sum(transmat(i,:));
end

return;




