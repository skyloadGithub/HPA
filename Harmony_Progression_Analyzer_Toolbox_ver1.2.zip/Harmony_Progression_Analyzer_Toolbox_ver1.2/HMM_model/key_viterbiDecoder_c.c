/*
*key_viterbiDecoder.c
*A key viterbi decoder in C code.
[viterbiPath,maxViterbiValue] = key_viterbiDecoder_c(init_states,transitM,emitM,state_to_C)

This function generates the Viterbi path for an HMM model.

Reference: "A tutorial on Hidden Markov models and selected applications in speech recognition" (L. Rabiner, 1989)
Section III B. (pp. 263-264)

INPUTS
ini_states - the probabilities of initial states (log form).
emitM - the chord emission probability matrix (log form).
transitM - the transition probability matrix (log form).
state_to_C - a vector, matching the hyper state to the chord indices.

OUTPUTS
viterbiPath - 1 x Nexample vector, the viterbi path (hyper transmat indices).
maxViterbiValue - the probability of this path (log form).

---------------------------------------------
Function created by Y. Ni
Function revised by M. McVicar
Intelligent Systems Lab
University of Bristol
U.K.
2011
 */

#include "mex.h"
#include "matrix.h"

/* If you are using a compiler that equates NaN to zero, you must
 * compile this example using the flag -DNAN_EQUALS_ZERO. For example:
 *
 *     mex -DNAN_EQUALS_ZERO findnz.c
 *
 * This will correctly define the IsNonZero macro for your Compiler */

#if NAN_EQUALS_ZERO
#define IsNonZero(d) ((d)!=0.0 || mxIsNaN(d))
#else
#define IsNonZero(d) ((d)!=0.0)
#endif

void mexFunction(int nlhs,       mxArray *plhs[],
        int nrhs, const mxArray *prhs[]) {
    
    /* Declare variables */
    size_t Nstates, Nchord;
    size_t Nexamples;
    size_t n, prev_n, t;
    double NinfNum;/*the array matrix*/
    mxArray *viterbiM, *pathM; 
    double *viterbiM_point, *pathM_point, *prev_viterbiM_point, *temp_prev;/*the pointers*/
    double *init_state_point, *transmat_point, *emitT_point; /*the pointers*/
    double *state_to_C_point;
    double maxValue, maxIndex, tempValue; /*the maximum value and maximum index*/
    double *viterbiPath_point;
    
    /*Warning message*/
    if (nrhs != 4) {
        mexErrMsgTxt("There are four inputs: initial states, transition matrix, chord emission matrix, and state to chords.");
    }
    
    if (nlhs > 2){
        mexErrMsgTxt("Too many output arguments.");
    }
    
    
    
    /*1. Initialization*/
    NinfNum=-mxGetInf(); /*get infinite number*/
    Nstates=mxGetM(prhs[1]); /*The number of hyper states*/
    Nchord=mxGetM(prhs[2]);  /*The number of chords*/
    Nexamples=mxGetN(prhs[2]); /*The number of exmaples*/
    
    viterbiM=mxCreateDoubleMatrix(Nstates, Nexamples, mxREAL); /*store the viterbi value*/
    pathM=mxCreateDoubleMatrix(Nstates, Nexamples, mxREAL);    /*store the trace back vector*/
    
    init_state_point=mxGetPr(prhs[0]); /*The initial states*/
    transmat_point=mxGetPr(prhs[1]);   /*The transition matrix*/
    emitT_point=mxGetPr(prhs[2]);       /*The chord emission matrix*/
    state_to_C_point=mxGetPr(prhs[3]); /*The pointer to states mapping to C (already index from 0 to Nchord-1)*/
    
    
    
    /*2. Assign the initial value*/
    viterbiM_point=mxGetPr(viterbiM);
    pathM_point=mxGetPr(pathM);
    prev_viterbiM_point=mxGetPr(viterbiM);
    
    for (n=0;n<Nstates;n++){
        *viterbiM_point++=init_state_point[n]; /*Assign the initial value*/
        pathM_point++; /*pass the initial state*/
    }
    
    /*Jump over the first example*/
    emitT_point+=Nchord;    
    
    
    /*3. Fill in the viterbi matrix*/
    for (t=1;t<Nexamples;t++){
        for (n=0;n<Nstates;n++){
            maxValue=NinfNum;
            maxIndex=-1;
            tempValue=0;
            /*3.1 Get the maximum value*/
            temp_prev=prev_viterbiM_point;
            for (prev_n=0;prev_n<Nstates;prev_n++){
                tempValue=*temp_prev;
                temp_prev++; /*To the next state*/
                
                
                
                if (mxIsFinite(tempValue)){
                    
                    tempValue+=transmat_point[n*Nstates+prev_n]; /*add the transition*/
                    
                    if (tempValue>maxValue){
                        maxValue=tempValue;
                        maxIndex=prev_n;
                    }
                }
            }
            /*3.2 assign the value to the current state*/
            *viterbiM_point++=maxValue+emitT_point[(size_t) state_to_C_point[n]];
            *pathM_point++=maxIndex;
        }
        prev_viterbiM_point+=Nstates;        /*update the previous pointer*/
        emitT_point+=Nchord;                                    /*update the chord emission pointer*/
    }
    

/*     4. Get the maximum value and track back*/
/*     4.1 Get the state with max value*/
    maxValue=NinfNum;
    maxIndex=-1;
    t=(Nexamples-1)*Nstates; /*the last exmaple*/
    viterbiM_point=mxGetPr(viterbiM); /*reset the viterbi point*/
    for (n=0;n<Nstates;n++){
        tempValue=viterbiM_point[t+n];
        if (tempValue>maxValue){
            maxValue=tempValue;
            maxIndex=n;
        }
    }
    
    /*4.2 Track back*/
    pathM_point=mxGetPr(pathM); /*reset the pathM point*/
    plhs[1]=mxCreateDoubleScalar(maxValue); /*return the likelihood (log form)*/
    plhs[0]=mxCreateDoubleMatrix(1, Nexamples, mxREAL);
    viterbiPath_point=mxGetPr(plhs[0]); /*assign the pointer*/
    t=Nexamples-1;
    viterbiPath_point[t]=maxIndex+1; /*change the state to the Matlab index*/
    
    while(t>0){
        viterbiPath_point[t-1]=pathM_point[t*Nstates+(int)viterbiPath_point[t]-1]+1;
        t--;
    }
}
    