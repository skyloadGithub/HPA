function [maxGammaPath,maxGammaValue,sequenceProb] = maxGammaDecoder(init_states,emitM,transitM)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
%[maxGammaPath,sequenceProb,maxGammaValue] = maxGammaDecoder(init_states,emitM,transitM)
%
%This function generate the maxGamma (maximizing the expected number of 
%correct individual states) path for an HMM model.
%
%Reference: "A tutorial on Hidden Markov models and selected applications in speech recognition" (L. Rabiner, 1989)
%Section III B. (pp. 263-264)
%
% INPUTS
%ini_states - the probabilities of initial states (i.e. pi in the paper).
%emitM - the emission probability matrix. 
%transitM - the transition probability matrix.
%
% OPUTPUTS
%maxGammaPath - 1 x #example vector, the viterbi path.
%sequenceProb - 1 x #example vector, the max probility of chord at time t.
%maxViterbiValue - the probability of this path (log form).
%
%---------------------------------------------
%Function created by Y. Ni
%Function revised by M. McVicar
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%1. Initialisation
[Nclass,Nexample]=size(emitM);

%2. Forward Backward Procedure
alpha=zeros(Nclass+1,Nexample); %the forward matrix, the last item is the sum of column t (time t)
beta=zeros(Nclass+1,Nexample);  %the backward matrix, the last item is the sum of column t(time t)


for c=1:Nclass
    alpha(c,1)=init_states(c)*emitM(c,1);
    beta(c,end)=1/Nclass;
end

%Step *. normalized alpha(:,1)
alpha(end,1)=sum(alpha(1:Nclass,1));
%alpha(1:Nclass,1)=alpha(1:Nclass,1)/alpha(end,1);
%beta(end,end)=1;


%3. Forward computation
for i=2:Nexample
    %3.1 alpha(j,i)=[sum_{k=1}^{Nclass}alpha(k,i-1)*transitM(k,j)]*emitM(j,i)
    for j=1:Nclass
        alpha(j,i)=alpha(1:Nclass,i-1)'*transitM(:,j)*emitM(j,i);%*alpha(end,i-1);
    end
    %3.2 normalized alpha(:,i)
    alpha(end,i)=sum(alpha(1:Nclass,i));
    alpha(1:Nclass,i)=alpha(1:Nclass,i)/alpha(end,i);
%    alpha(end,i)=alpha(end,i)*alpha(end,i-1); %Get the exact value
end

%4. Backward computation
for i=Nexample-1:-1:1
    %4.1 beta(j,i)=[sum_{k=1}^{Nclass}transitM(j,k)*beta(k,i+1)*emitM(j,i+1)]
    for j=1:Nclass
        beta(j,i)=transitM(j,:)*(beta(1:Nclass,i+1).*emitM(:,i+1));%*beta(end,i+1);
    end
    %4.2 normalized beta(:,i)
    beta(end,i)=sum(beta(1:Nclass,i));
    beta(1:Nclass,i)=beta(1:Nclass,i)/beta(end,i);
 %   beta(end,i)=beta(end,i)*beta(end,i+1); %Get the exact value
end

%5. Choose c_{t} which are individually most likely
maxGammaPath=zeros(1,Nexample);
sequenceProb=zeros(1,Nexample);
for i=1:Nexample
    tempProb=alpha(1:Nclass,i).*beta(1:Nclass,i);
    tempProb=tempProb/sum(tempProb);
    [maxProb,maxIndex]=max(tempProb);
    maxGammaPath(i)=maxIndex;
    sequenceProb(i)=maxProb;
end

maxGammaValue=sum(log(sequenceProb+eps));


return;