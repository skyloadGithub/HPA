function [hyperTransmat,hyperLinks, transLinks] = createHyperTransmat_var(key_transmat,chord_transmat,key_transBags,chord_bass_transmat,bassPrev_bass_transmat,chord_bass_bags,chord_restriction)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
%[hyperTransmat,hyperLinks, transLinks] 
%= createHyperTransmat_var(key_transmat,chord_transmat,key_transBags,chord_bass_transmat,bassPrev_bass_transmat,chord_bass_bags,chord_restriction)
%
%To create a hyper transition matrix to a key viterbi or a key bass viterbi.
%Differ from createHyperTransmat.m:
%The hyperTransmat is not symmetric (to reduce search space). The corresponding 
%states from state transLinks(i,j) -> state j is specific in transLinks(i,j).
%
% INPUTS
%key_transmat - the key transition matrix.
%chord_transmat - the key specific chord transition matrix #chord x #chord x #key.
%key_transBags - 1 x numKeys cells, i-th cell contains the possible keys transit to i-th key.
%chord_bass_transmat - the chord -> bass transition matrix #chord x #bass.
%bassPrev_bass_transmat - the bass -> bass transition matrix #bass x #bass.
%chord_bass_bags - 1 x #chord cells, storing chord i -> all possible basses.
%chord_restriction - (optional) the selected chords from maxGamma decoder
%                    (to reduce the search space).
%
% OUTPUTS
%hyperTransmat - a hyper transition matrix.
%hyperLinks - the corresponding key/chord/bass in the hyper position.
%transLinks - states from state transLinks(i,j) -> state j.
%Format: for key specific model: [key;chord] x #hyper_states
%        for key bass specific model: [key;chord;bass] x #hyper_states
%
%---------------------------------------------
%Function created by Y. Ni
%Function revised by M. McVicar
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%A. If key viterbi model
if nargin < 4
    %1. Initialization
    numKey_x=length(key_transBags{1}); %The number of possible transit keys
    numKey_y=size(key_transmat,1); 
    numChord=size(chord_transmat,1);
    
    numStates_x=numKey_x*numChord;
    numStates_y=numKey_y*numChord;
    hyperTransmat=zeros(numStates_x,numStates_y);
    transLinks=hyperTransmat;
    hyperLinks=zeros(2,numStates_x);
    
    
    %2. Fill in the hyper transmat matrix
    for k2=1:numKey_y
        k2_start=(k2-1)*numChord;
        for k1=1:numKey_x
            k1_start=(k1-1)*numChord;
            k1_pos=key_transBags{k2}(k1);
            k1_posStart=(k1_pos-1)*numChord;
            for c1=1:numChord
                hyper_pos1=k1_start+c1;
                %If no transition between chord
                for c2=1:numChord
                    hyper_pos2=k2_start+c2;
                    hyperTransmat(hyper_pos1,hyper_pos2)=key_transmat(k1_pos,k2)+chord_transmat(c1,c2,k2);
                    transLinks(hyper_pos1,hyper_pos2)=k1_posStart+c1;
                end
            end
        end
    end
    
    
    
    %3. Create the mapping from the [key;chord;bass] to the hyper states
    for k2=1:numKey_y
        for c1=1:numChord
            hyper_pos1=(k2-1)*numChord+c1;
            hyperLinks(:,hyper_pos1)=[k2;c1];
        end
    end
    
%B. If key bass viterbi model
else
    %1. Initialization
    if (nargin < 7) %If using all chords
        numKey_x=length(key_transBags{1}); %The number of possible transit keys
        numKey_y=size(key_transmat,1);
        numChord=size(chord_transmat,1);
        chordList=1:numChord;
        chord_start=zeros(1,numChord);
        numChordBass=length([chord_bass_bags{:}]);
        for i=2:numChord
            chord_start(i)=chord_start(i-1)+length(chord_bass_bags{i-1});
        end
        numStates_x=numKey_x*numChordBass;
        numStates_y=numKey_y*numChordBass;
    else %If using maxGamma optimized chords
        numKey_x=length(key_transBags{1}); %The number of possible transit keys
        numKey_y=size(key_transmat,1);
        numChord=length(chord_restriction);
        chordList=chord_restriction;
        chord_start=zeros(1,numChord);
        numChordBass=length([chord_bass_bags{chord_restriction}]);
        for i=2:numChord
            chord_start(i)=chord_start(i-1)+length(chord_bass_bags{chordList(i-1)});
        end
        numStates_x=numKey_x*numChordBass;
        numStates_y=numKey_y*numChordBass;
    end
        
    
    hyperTransmat=zeros(numStates_x,numStates_y);
    transLinks=hyperTransmat;
    hyperLinks=zeros(3,numStates_x);
    
    
    %2. Fill in the hyper transmat matrix
    for k2=1:numKey_y
        k2_start=(k2-1)*numChordBass;
        for k1=1:numKey_x
            k1_start=(k1-1)*numChordBass;
            k1_pos=key_transBags{k2}(k1);
            k1_posStart=(k1_pos-1)*numChordBass;
            for c1_ind=1:numChord
                c1=chordList(c1_ind);
                c1_start=k1_start+chord_start(c1_ind);
                c1_posStart=k1_posStart+chord_start(c1_ind);
                %If no transition between chord
                for c2_ind=1:numChord
                    c2=chordList(c2_ind);
                    c2_start=k2_start+chord_start(c2_ind);                    
                    for b1_ind=1:length(chord_bass_bags{c1})
                        b1=chord_bass_bags{c1}(b1_ind);
                        hyper_pos1=c1_start+b1_ind;
                       
                        %Else update the transmat probability
                        for b2_ind=1:length(chord_bass_bags{c2})
                            b2=chord_bass_bags{c2}(b2_ind);
                            hyper_pos2=c2_start+b2_ind;
                            hyperTransmat(hyper_pos1,hyper_pos2)=key_transmat(k1_pos,k2)+chord_transmat(c1,c2,k2)+chord_bass_transmat(c2,b2)+bassPrev_bass_transmat(b1,b2);
                            transLinks(hyper_pos1,hyper_pos2)= c1_posStart+b1_ind;
                        end  
                    end
                end
            end
        end
    end
     
    
    
    %3. Create the mapping from the [key;chord;bass] to the hyper states
    for k2=1:numKey_y
        for c1_ind=1:numChord
            c1=chordList(c1_ind);
            for b1_ind=1:length(chord_bass_bags{c1})
                hyper_pos1=(k2-1)*numChordBass+chord_start(c1_ind)+b1_ind;
                hyperLinks(:,hyper_pos1)=[k2;c1;chord_bass_bags{c1}(b1_ind)];
            end
        end
    end
end
