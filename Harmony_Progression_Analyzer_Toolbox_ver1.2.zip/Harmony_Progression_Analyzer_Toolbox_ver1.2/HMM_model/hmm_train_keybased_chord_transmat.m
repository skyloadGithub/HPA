function [transmat] = hmm_train_keybased_chord_transmat(chord_transpositions, key_transpositions, nstates, numKeys, pseudo_count_trans)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
%[transmat] = 
%hmm_train_keybased_chord_transmat(chord_transpositions, nstates, numKeys, pseudo_count_trans)
%
%This function trains the maximum likelihood estimaton (MLE) for the
%key-specific chord transition.
%
% INPUTS
%chord_transpositions - all transposition chord annotations for the 
%                    training songs, 1xN cells each cell has 12 transpositions.
%key_transpositions - all transposition key annotations for the training
%                    song, 1xN cells each cell has 12 transpositions. 
%nstates - the number of chord states (Gaussians).
%numKeys - the number of keys.
%pseudo_count_trans - the pseudo-count of the transition matrix.
%
% OUTPUTS
%transmat - the chord transition probabilities, a nstates x nstates x key matrix.
%
%---------------------------------------------
%Function created by Y. Ni
%Function revised by M. McVicar
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%1. Configulation
if (nargin<5)
    pseudo_count_trans=1;
end

transmat=zeros(nstates,nstates,numKeys);  %full transition matrix
N_key=numKeys+1;                   %no-key indices
N=length(chord_transpositions);

%2. Count the chord transitions
for i=1:N
    for k=1:length(chord_transpositions{i})
        if (~isempty(key_transpositions{i}{k}) && length(chord_transpositions{i}{k})>1)
            temp_annotation_seq=chord_transpositions{i}{k};
            temp_key=key_transpositions{i}{k};
            %For each chord transition, add the transition count
            for j=2:length(temp_annotation_seq)
                if (temp_annotation_seq(j-1)<=nstates && temp_annotation_seq(j)<=nstates && temp_key(j)<N_key)
                    transmat(temp_annotation_seq(j-1),temp_annotation_seq(j),temp_key(j))=transmat(temp_annotation_seq(j-1),temp_annotation_seq(j),temp_key(j))+1;
                end
            end
        end
    end
end
            

%3. Normalization
for k=1:numKeys
    transmat(:,:,k)=transmat(:,:,k)+pseudo_count_trans;
    
    %Transition probability = p(c2|c1,k)=p(c1->c2|k)
    for i=1:nstates
        n=sum(transmat(i,:,k));
        if (n>0)
            transmat(i,:,k)=transmat(i,:,k)/n;
        end
    end
end
return;