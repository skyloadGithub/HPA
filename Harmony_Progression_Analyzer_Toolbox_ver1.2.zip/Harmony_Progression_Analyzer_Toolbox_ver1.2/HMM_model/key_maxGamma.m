function [maxGammaChord,maxGammaScore,maxGammaKey] = key_maxGamma(init_states,transitM,emitM,key_transitM,key_transBag)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
%[maxGammaChord,maxGammaScore,maxGammaKey] =
%key_maxGamma(init_states,transitM,emitM,key_transitM,key_transBag)
%
%This function generates a key-specific maxGamma path for an HMM model.
%Principle: 
%p(emit|c) = emitM; 
%p(c2|c1,k2)=p(c1->c2|k2) = transitM; 
%p(k2|k1)=key_transitM.
%
% INPUTS
%ini_states - the probabilities of initial states.
%emitM - the emission probability matrix, nstates x #example matrix.
%transitM - the key specific transition matrix, 
%           nstates x nstates x numKeys matrix.
%key_transitM - the key transition matrix, numKeys x numKeys matrix.
%    Remark: the size of key_transitM might be (numKeys+1 x numKeys+1) with
%            the last one denotes non-key index (the corresponding chord 
%            transmat is the global chord transmat).
%key_transBag - key_transBag{i} stores key indecies that key i can transit to.
%
% OUTPUTS
%maxGammaChord - 1x#example vector, the maxGamma path.
%maxGammaScore - the probability of this path (not in used, set as 0).
%maxGammaKey - 1x#example vector, the corresponding key path.
%
%---------------------------------------------
%Function created by Y. Ni
%Function revised by M. McVicar
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%1. Configulation
[Nseq,Nexample]=size(emitM);
Nkey=length(key_transitM);


%2. Forward Backward Procedure
alpha=zeros(Nseq,Nkey,Nexample); %the forward matrix
beta=zeros(Nseq,Nkey,Nexample);  %the backward matrix

%2.1 Initialization of the fist values
for c=1:Nseq
    temp_ini_value=init_states(c)*emitM(c,1);
    for k=1:Nkey
        alpha(c,k,1)=temp_ini_value;
        beta(c,k,end)=1/Nseq;
    end
end

%3. Forward computation
for i=2:Nexample
    %3.1 alpha(j,k,i)=[sum_{m,n}alpha(m,n,i-1)*transitM(m,j,k)*key_transitM(n,k)]*emitM(j,i)
    normal_value=0;
    for j=1:Nseq
        for k=1:Nkey
            temp_value=0;
             for k_key_index=1:length(key_transBag{k}) %for each previous key state
                k_key=key_transBag{k}(k_key_index);
                for k_chord=1:Nseq %for each previous chord state
                    temp_value=temp_value+alpha(k_chord,k_key,i-1)*transitM(k_chord,j,k)*key_transitM(k_key,k);
                end
             end
             alpha(j,k,i)=temp_value*emitM(j,i);
             normal_value=normal_value+alpha(j,k,i);
        end
    end
    %3.2 normalized alpha(:,i)
    alpha(:,:,i)=alpha(:,:,i)/normal_value;
end

%4. Backward computation
for i=Nexample-1:-1:1
    %4.1 beta(j,k,i)=[sum_{m,n}beta(m,n,i+1)*transitM(j,m,n)*key_transitM(k,n)]*emitM(j,i)
    normal_value=0;
    for j=1:Nseq
        for k=1:Nkey
            temp_value=0;
            for k_key_index=1:length(key_transBag{k}) %for each previous key state
                k_key=key_transBag{k}(k_key_index);
                for k_chord=1:Nseq %for each previous chord state
                    temp_value=temp_value+beta(k_chord,k_key,i+1)*transitM(j,k_chord,k_key)*key_transitM(k,k_key)*emitM(k_chord,i+1);
                end
            end
             beta(j,k,i)=temp_value;
             normal_value=normal_value+temp_value;
        end
    end
    %4.2 normalized beta(:,i)
    beta(:,:,i)=beta(:,:,i)/normal_value;
end

%5. Choose c_{t} which are individually most likely
maxGammaChord=zeros(1,Nexample);
maxGammaKey=zeros(1,Nexample);

for i=1:Nexample
    tempProb=alpha(:,:,i).*beta(:,:,i);
    [maxValue,maxChord]=max(tempProb,[],1);
    [maxValue,maxKey]=max(maxValue);
    maxChord=maxChord(maxKey);
    maxGammaChord(i)=maxChord;
    maxGammaKey(i)=maxKey;
end

maxGammaScore=0;

return;



