function [key_transmat,key_transBag] = hmm_train_key_transmat(keyData, numKeys, keyNum_del, pseudo_count_trans)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
%[key_transmat,key_transBag] = hmm_train_key_transmat(keyData, numKeys, keyNum_del, pseudo_count_trans)
%
%This function trains the maximum likelihood estimaton (MLE) for the key transition
%probabilities.
%
% INPUTS
%keyData - the hidden key state sequences. 1xN cell with each cell is a
%          1xNi vector.
%numKeys - the number of keys.
%keyNum_del - delete the key transition that less than keyNum_del times.
%pseudo_count_trans - the pseudo-count of the transition matrix.
%
% OUTPUTS
%key_transmat - the key transition probabilities, a numKeys x numKeys matrix.
%key_transBag - key_transBag{i} stores key indecies that transit to key i.
%
%---------------------------------------------
%Function created by Y. Ni
%Function revised by M. McVicar
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%1. Configulation
if (nargin<4)
    pseudo_count_trans=0.0;
end

key_transmat=zeros(numKeys,numKeys);
key_transBag=cell(1,numKeys);          %key transition bag (from key_transBags{i}-> key i)
N=length(keyData); %The number of examples
N_key=numKeys+1;   %no-key index

%2. Computing the transitions (also transposed transitions)
for t=1:N
    temp_annotation=keyData{t};
    for j=2:length(temp_annotation)
        if (temp_annotation(j)<N_key && temp_annotation(j-1)<N_key)
            transitionPos=temp_annotation(j)-temp_annotation(j-1);
            for k=1:numKeys
                k_j=mod(transitionPos+k,numKeys);
                if (k_j==0)
                    k_j=numKeys;
                end
                key_transmat(k,k_j)=key_transmat(k,k_j)+1;
            end
        end
    end
end


key_transmat(key_transmat<keyNum_del)=0;
key_transmat=key_transmat+pseudo_count_trans;


%3. Normalization
for k=1:numKeys
    n=sum(key_transmat(k,:));
    if (n>0)
        key_transmat(k,:)=key_transmat(k,:)/n;
    end
end

%4. Filling in the key_transBag from key_transBag{k}->k
for k=1:numKeys
    key_transBag{k}=find(key_transmat(:,k)>0);
end


return;
