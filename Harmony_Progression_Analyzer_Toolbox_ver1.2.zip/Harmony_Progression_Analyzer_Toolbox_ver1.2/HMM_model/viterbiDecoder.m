function [viterbiPath, maxViterbiValue] = viterbiDecoder(init_states,transitM,emitM)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
% [viterbiPath,maxViterbiValue] = viterbiDecoder(init_states,transitM,emitM)
% 
% This function generates the Viterbi path for an HMM model.
% 
% Reference: "A tutorial on Hidden Markov models and selected applications in speech recognition" (L. Rabiner, 1989)
% Section III B. (pp. 263-264)
% 
% INPUTS
% ini_states - the probabilities of initial states (log form).
% emitM - the emission probability matrix (log form).
% transitM - the transition probability matrix (log form).
% 
% OUTPUTS
% viterbiPath - 1 x Nexample vector, the viterbi path.
% maxViterbiValue - the probability of this path (log form).
% 
% ---------------------------------------------
% Function created by Y. Ni
% Function revised by M. McVicar
% Intelligent Systems Lab
% University of Bristol
% U.K.
% 2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%1. configulation
[Nseq,Nexample]=size(emitM);

viterbiM=-inf(Nseq,Nexample); %the path matrix
pathM=zeros(Nseq,Nexample);    %the trace back index matrix

viterbiM(:,1)=init_states; %Get the initial probability

%2. filling the dynamic programing table
for i=2:Nexample %for each example
    for j=1:Nseq %for each state of the current example
        maxVal=-inf;
        maxIndex=-1;
        %2.1 loop through each previous state
        for k=1:Nseq 
            tempVal=viterbiM(k,i-1)+transitM(k,j);     
            if tempVal>maxVal
                maxVal=tempVal;
                maxIndex=k;
            end
        end
        %2.2 Get the path with the max prob
        viterbiM(j,i)=maxVal+emitM(j,i);
        pathM(j,i)=maxIndex;
    end
end



%%3. Find the most probability path and output
viterbiPath=zeros(1,Nexample);

[maxViterbiValue,maxIndex]=max(viterbiM(:,Nexample));

viterbiPath(Nexample)=maxIndex;
for i=Nexample:-1:2
    maxIndex=pathM(maxIndex,i);
    viterbiPath(i-1)=maxIndex;
end

return;
            