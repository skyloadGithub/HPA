function [sigma_inv,sigma_det_inv] = gaussian_sigma_inverse(Sigma)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
%[sigma_inv,sigma_det_inv] = gaussian_sigma_inverse(Sigma,nstates,logLabel)
%
%This function computes the inverse matrix of the covariance matrix Sigma.
%
% INPUTS
%Sigma - the covariance matrix. nstates x nstates x num_Gaussian.
%
% OUTPUTS
%sigma_inv - the inverse matrix of Sigma.
%sigma_det_inv - the inverse determinant (including the constant term) of each Sigma matrix.
%Remark: sigma_det_inv is in log form.
%
%---------------------------------------------
%Function created by Y. Ni
%Function revised by M. McVicar
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%1. configulation
ndim=size(Sigma,1);
nstates=size(Sigma,3);
sigma_inv=zeros(size(Sigma));
sigma_det_inv=zeros(nstates,1);
pi2=(2*pi)^(ndim);

%2. compute the inverse

for chord=1:nstates
    %A. If this chord appear in the training set
    if (any(any(Sigma(:,:,chord))))
        sigma_inv(:,:,chord)=pinv(Sigma(:,:,chord));
        sigma_det_inv(chord)=log(1/(sqrt(pi2*det(Sigma(:,:,chord)))));
    %B. Else
    else
        sigma_inv(:,:,chord)=Sigma(:,:,chord);
        sigma_det_inv(chord)=-inf;
        
    end
end

    
return;
