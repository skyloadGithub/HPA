function [mu, Sigma] = hmm_train_gaussian(obsData, hiddenData, nstates, sigma_prior)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
%function [mu, Sigma] = hmm_train_gaussian(obsData, hiddenData, nstates,
%                       sigma_prior)
%
%This function trains the maximum likelihood estimaton (MLE) for mixture of Gaussians
%given the observation data and the hidden state sequences.
%
% INPUTS
%obsData - the observation sequences. 1xN cell with each cell is a dxNi
%          matrix.
%hiddenData - the hidden state sequences. 1xN cell with each cell is a 1xNi
%             vector.
%nstates - the number of Gaussians (states)
%sigma_prior - the prior for Sigma (default 0.01)
%
% OUTPUTS
%mu - the mean matrix of the Gaussians, dxnstates matrix.
%Sigma - the variance matrix of the Gaussians, dxdxnstates matrix.
%
%Reference: R. O. Duda, P. E. Hart and D. G. Stock, Pattern Classification, 2001
%
%---------------------------------------------
%Function created by Y. Ni
%Function revised by M. McVicar
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%1. Configulation
obsData=[obsData{:}];
hiddenData=[hiddenData{:}]; 

d=size(obsData,1); %Get the dimension and the number of examples

%1.1 Get the sigma prior
if (nargin<4)
    sigma_prior=0.01*eye(d,d);
else
    sigma_prior=sigma_prior*eye(d,d);
end

%2. Derive the MLE of mu and Sigma
mu=zeros(d,nstates);
Sigma=zeros(d,d,nstates);

for c=1:nstates
    
    c_index=find(hiddenData==c);
    if (~isempty(c_index))
        %2.1 mu=1/n_{c}sum_{i}x_{i,c}
        temp_data=obsData(:,c_index);
        mu(:,c)=mean(temp_data,2); %get the mean
    
        %2.2 Sigma=1/n_{c}sum_{i}(x_{i,c}-mu_{c})(x_{i,c}-mu_{c})^{T}
        temp_data=temp_data*temp_data'/length(c_index);
    
        Sigma(:,:,c)=temp_data-mu(:,c)*mu(:,c)'+sigma_prior;
    end
end

return;



