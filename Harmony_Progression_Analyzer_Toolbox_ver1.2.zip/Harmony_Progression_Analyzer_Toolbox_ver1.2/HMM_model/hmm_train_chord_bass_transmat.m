function [chord_bass_transmat] = hmm_train_chord_bass_transmat(chord_transpositions, bass_transpositions, chord_bass_restriction,pseudo_count_trans)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
%[chord_bass_transmat] = 
%hmm_train_chord_bass_transmat(chord_transpositions, bass_transpositions, chord_bass_restriction,pseudo_count_trans)
%
%This function trains the maximum likelihood estimaton (MLE) for the
%symmetric chord to bass transition matrix.
%
% INPUTS
%chord_transpositions - all transposition chord annotations for the 
%                    training songs, 1xN cells each cell has 12 transpositions.
%bass_transpositions - all transposition bass annotations for the training song.
%chord_bass_restriction - nstates x num_bass matrix, 
%                        (i,j)=chord i can emit bass j.
%pseudo_count_trans - the pseudo-count of the transition matrix.
%
% OUTPUTS
%chord_bass_transmat - the chord to bass transition probabilities, a nstates x num_bass matrix.
%
%---------------------------------------------
%Function created by Y. Ni
%Function revised by M. McVicar
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%1. Configulation
if (nargin<4)
    pseudo_count_trans=0;
end

[nstates,num_bass]=size(chord_bass_restriction);
chord_bass_transmat=zeros(nstates,num_bass);
N=length(chord_transpositions);

%2. Count the transitions
for i=1:N
    for k=1:length(chord_transpositions{i})
        if (~(isempty(chord_transpositions{i}{k}) || isempty(bass_transpositions{i}{k})))
            temp_chord_seq=chord_transpositions{i}{k};
            temp_bass_seq=bass_transpositions{i}{k};
            for j=1:length(temp_chord_seq)
                if (temp_chord_seq(j)<=nstates && temp_bass_seq(j)<=num_bass)
                    chord_bass_transmat(temp_chord_seq(j),temp_bass_seq(j))=chord_bass_transmat(temp_chord_seq(j),temp_bass_seq(j))+1;
                end
            end
        end
    end
end


%3. Normalization
chord_bass_transmat=chord_bass_transmat+pseudo_count_trans;
chord_bass_transmat=chord_bass_transmat.*chord_bass_restriction;
for i=1:nstates
    n=sum(chord_bass_transmat(i,:));
    if (n>0)
        chord_bass_transmat(i,:)=chord_bass_transmat(i,:)/n;
    end
end

return;


