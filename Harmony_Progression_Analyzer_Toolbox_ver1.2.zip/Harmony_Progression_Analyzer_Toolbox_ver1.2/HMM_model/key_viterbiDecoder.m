function [viterbiChord_path,maxViterbiValue,viterbiKey_path] = key_viterbiDecoder(init_states,hyperTransmat,hyperLinks,emitM,c_flag,transLinks)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
%[viterbiChord_path,maxViterbiValue,viterbiKey_path] 
%= key_viterbiDecoder(init_states,hyperTransmat,hyperLinks,emitM,c_flag,transLinks)
%
%This function generates a key/bass specific Viterbi path for an HMM model.
%Principle: 
%p(emitM|c) = emitM;
%p(c2|c1,k2)=p(c1->c2|k2) = transitM; 
%p(k2|k1)=p(k1->k2);
%
% INPUTS
%ini_states - the probabilities of initial states (log form).
%emitM - the chord emission probability matrix, nstates x #example matrix (log form).
%hyperLinks - the link between the keys/chords and the hyper
%             transmat. [key;chord] x hyper_states.
%c_flag - if 1 using C implementation (faster); else using matlab
%         implementations.
%transLinks - (optional) using non-symmetric transition matrix (save search space). 
%             stores states from state transLinks(i,j) -> state j.
%
% OUTPUTS
%viterbiChord_path - 1x#example vector, the viterbi chord path.
%maxViterbiValue - the probability of this path (log form).
%viterbiKey_path - 1x#example vector, the corresponding key path.
%
%---------------------------------------------
%Function created by Y. Ni
%Function revised by M. McVicar
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Variation one: using symmetric transition matrix
if (nargin<6)
    %1. Configulation
    Nexample=size(emitM,2);
    
    nhyperStates=length(hyperTransmat);
    
    viterbiM=-inf(nhyperStates,Nexample); %the path matrix
    pathM=zeros(nhyperStates,Nexample);    %the trace back index matrix
    
    
    %2. Initialization
    for hyper_pos2=1:nhyperStates
        viterbiM(hyper_pos2,1)=init_states(hyperLinks(2,hyper_pos2));
    end
    
    %3. For the main loop (a modified viterbi decoder)
    %A. Using C implementation
    if (c_flag)
        [hyperPath,maxViterbiValue]=key_viterbiDecoder_c(viterbiM(:,1),hyperTransmat,emitM,hyperLinks(2,:)'-1);
        viterbiChord_path=hyperLinks(2,hyperPath);
        viterbiKey_path=hyperLinks(1,hyperPath);
        %B. Using matlab implementation
    else
        %for each example
        for i=2:Nexample
            %   tic
            for hyper_pos2=1:nhyperStates
                maxVal=-inf;
                maxIndex=-1;
                for hyper_pos1=1:nhyperStates
                    tempVal=viterbiM(hyper_pos1,i-1)+hyperTransmat(hyper_pos1,hyper_pos2);
                    if tempVal>maxVal
                        maxVal=tempVal;
                        maxIndex=hyper_pos1;
                    end
                end
                
                %Update the values
                viterbiM(hyper_pos2,i)=emitM(hyperLinks(2,hyper_pos2),i)+maxVal;
                pathM(hyper_pos2,i)=maxIndex;
            end
            %    toc
        end
        
        %4. Find the most probability chord/key path and output
        viterbiChord_path=zeros(1,Nexample);
        viterbiKey_path=zeros(1,Nexample);
        
        [maxViterbiValue,maxIndex_info]=max(viterbiM(:,Nexample));
        
        viterbiChord_path(Nexample)=hyperLinks(2,maxIndex_info);
        viterbiKey_path(Nexample)=hyperLinks(1,maxIndex_info);
        
        for i=Nexample:-1:2
            maxIndex_info=pathM(maxIndex_info,i);
            %Update the key/chord information
            viterbiChord_path(i-1)=hyperLinks(2,maxIndex_info);
            viterbiKey_path(i-1)=hyperLinks(1,maxIndex_info);
        end
    end
    
%Variation two: using non-symmetric transition matrix
else
    %1. Configulation
    Nexample=size(emitM,2);
    
    [nhyperStates_x,nhyperStates_y]=size(hyperTransmat);
    
    viterbiM=-inf(nhyperStates_y,Nexample); %the path matrix
    pathM=zeros(nhyperStates_y,Nexample);    %the trace back index matrix
    
    
    %2. Initialization
    for hyper_pos2=1:nhyperStates_y
        viterbiM(hyper_pos2,1)=init_states(hyperLinks(2,hyper_pos2));
    end
    
    %3. For the main loop (a modified viterbi decoder)
    %A. Using C implementation
    if (c_flag)
        [hyperPath,maxViterbiValue]=key_viterbiDecoder_var_c(viterbiM(:,1),hyperTransmat,emitM,hyperLinks(2,:)'-1,transLinks-1);
        viterbiChord_path=hyperLinks(2,hyperPath);
        viterbiKey_path=hyperLinks(1,hyperPath);
        %B. Using matlab implementation
    else
        %for each example
        for i=2:Nexample
            %   tic
            for hyper_pos2=1:nhyperStates_y
                maxVal=-inf;
                maxIndex=-1;
                for hyper_pos1=1:nhyperStates_x
                    tempVal=viterbiM(transLinks(hyper_pos1,hyper_pos2),i-1)+hyperTransmat(hyper_pos1,hyper_pos2);
                    if tempVal>maxVal
                        maxVal=tempVal;
                        maxIndex=transLinks(hyper_pos1,hyper_pos2);
                    end
                end
                
                %Update the values
                viterbiM(hyper_pos2,i)=emitM(hyperLinks(2,hyper_pos2),i)+maxVal;
                pathM(hyper_pos2,i)=maxIndex;
            end
            %    toc
        end
        
        %4. Find the most probability chord/key path and output
        viterbiChord_path=zeros(1,Nexample);
        viterbiKey_path=zeros(1,Nexample);
        
        [maxViterbiValue,maxIndex_info]=max(viterbiM(:,Nexample));
        
        viterbiChord_path(Nexample)=hyperLinks(2,maxIndex_info);
        viterbiKey_path(Nexample)=hyperLinks(1,maxIndex_info);
        
        for i=Nexample:-1:2
            maxIndex_info=pathM(maxIndex_info,i);
            %Update the key/chord information
            viterbiChord_path(i-1)=hyperLinks(2,maxIndex_info);
            viterbiKey_path(i-1)=hyperLinks(1,maxIndex_info);
        end
    end
end

return;