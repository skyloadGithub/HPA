function emit = hmm_mixgauss_prob(obs,mu,sigma_inv,sigma_det_inv,logLabel)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
%emit = hmm_mixgauss_prob(obs,mu,sigma_inv,sigma_det_inv,logLabel)
%
%This function computes the emission probabilities of a given observation sequence.
%
% INPUTS
%obs - the observation data, d x Ni matrix.
%mu - the mean matrix of the Gaussians.
%sigma_inv - the inverse covariance matrix of the Gaussians. 
%sigma_det_inv - the inverse determinant (including the constant term) of
%                each Sigma matrix.
%logLabel - 1: return log form of emission probabilities; 
%           0: return normal form of emission probabilities.
%
% OUTPUTS
%emit - the emission probability of the observation.
%
%---------------------------------------------
%Function created by Y. Ni
%Function revised by M. McVicar
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%1. Configulation
obs_len=size(obs,2);
nstates=size(mu,2);
emit = zeros(nstates,obs_len);

%2. Computing the gaussian probabilities
for chord=1:nstates
    tempObs=(obs-repmat(mu(:,chord),1,obs_len));
    for l=1:obs_len
        emit(chord,l)=sigma_det_inv(chord)-0.5*tempObs(:,l)'*sigma_inv(:,:,chord)*tempObs(:,l); %the log gaussian distribution
    end
end

if (~logLabel)
    emit=exp(emit);
end
    

return;


