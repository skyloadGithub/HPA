function [bass_transmat] = hmm_train_bass_transmat(bass_transpositions, num_bass, pseudo_count_trans)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
%[bass_transmat] = hmm_train_bass_transmat(bass_transpositions, num_bass, pseudo_count_trans)
%
%This function trains the maximum likelihood estimaton (MLE) for the
%symmetric bass transition matrix.
%
% INPUTS
%bass_transpositions - all transposition bass annotations for the training song.
%num_bass - the number of bass
%pseudo_count_trans - the pseudo-count of the transition matrix.
%
% OUTPUTS
%bass_transmat - the bass transition probabilities, a num_bass x num_bass matrix.
%
%---------------------------------------------
%Function created by Y. Ni
%Function revised by M. McVicar
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%1. Configulation
if (nargin==1)
    num_bass=13; %Default
elseif (nargin==2)
    pseudo_count_trans=1.0;
end

bass_transmat=zeros(num_bass);
N=length(bass_transpositions);


%2. For all transpositions
for i=1:N
    for k=1:length(bass_transpositions{i})
        if (length(bass_transpositions{i}{k})>1)
            temp_bass_seq=bass_transpositions{i}{k};
            for j=2:length(temp_bass_seq)
                if (temp_bass_seq(j-1)<=num_bass && temp_bass_seq(j)<=num_bass)
                    bass_transmat(temp_bass_seq(j-1),temp_bass_seq(j))=bass_transmat(temp_bass_seq(j-1),temp_bass_seq(j))+1;
                end
            end
        end
    end
end


%3. Normalization
bass_transmat=bass_transmat+pseudo_count_trans;
for i=1:num_bass
    n=sum(bass_transmat(i,:));
    if (n>0)
        bass_transmat(i,:)=bass_transmat(i,:)/n;
    end
end

return;

