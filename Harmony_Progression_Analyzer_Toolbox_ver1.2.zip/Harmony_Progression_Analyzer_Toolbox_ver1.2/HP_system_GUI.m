function varargout = HP_system_GUI(varargin)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Harminic Progression (HP) chord recognition system
%GUI for interatively processing.
%For Batch processing, use the command line function MIREX_shell.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%1. Initialization - DO NOT EDIT
% Begin initialization code 
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @HP_system_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @HP_system_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code 
%1. Initialization - DO NOT EDIT



% --- Initialization function
function HP_system_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Initialize the hanldes and the directories (default)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%I.1 Add the toolbox path
toolbox_dir = pwd;
addpath(genpath(toolbox_dir));

%I.2 Add handles to the handle control list
handles.output = hObject;

handles.options=struct;
%A. File parameters
handles.options.toolbox_dir=toolbox_dir;
handles.options.test_audio_file =''; %The directory for the test audio, will be added by the open function.
handles.options.test_audio_filename=''; %The audio file name
handles.options.prediction_dir ='';  %The directory to output the prediction, will be added by the save function.
handles.options.modelLabel = 'minmaj'; %The mode of the system, 'minmaj' (minor/major chords) or 'full' (121 MM chords)

%B. Chromagram parameters
handles.options.SR=11025; %The re-sampling rate
handles.options.bass_fmin=55;
handles.options.bass_fmax=207;
handles.options.bass_resolution_fact=2;
handles.options.treble_fmin=220;
handles.options.treble_fmax=1661;
handles.options.treble_resolution_fact=5;

%C. Output
handles.chord_predictions=[]; %The predictions
handles.chord_names=[];       %The chord names
handles.sample_times=[];      %The sample times
handles.saved_flag=0;         %If saved, then 1 (for chord)
handles.LBC_saved_flag=0;     %If saved, then 1 (for LBC features)

% Update handles structure
guidata(hObject, handles);

%LOGO plot
logo=imread('HP_system_logo.jpg');
image(logo,'parent',handles.logo_plot);
axis(handles.logo_plot,'off');


return;

% UIWAIT makes HP_system_GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);

% --- Initialization function


% --- Outputs function (not in used currently).
function varargout = HP_system_GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
return;
% --- Outputs function (not in used currently).


% --- Reading the wav files and parameter settings
function open_song_ClickedCallback(hObject, eventdata, handles)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Return the directory and file name of the test song
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


[filename, pathname] = uigetfile('*.wav', 'Pick a Wav-file');
if isequal(filename,0) || isequal(pathname,0)
    set(handles.indicator_text,'string','No wav file is selected.')
else
    %1. Get the file name
    full_dir=[pathname,filename];
    if (isempty(wavfinfo(full_dir)))
        set(handles.indicator_text,'string','Error: the selcted file is not a wav file, can not be read by wavread().');
        set(handles.indicator_text,'foregroundcolor','red');
    else
    %2. If the file can be processed
    
        %A. Plot the wave file
        handles.options.test_audio_file=full_dir;
        handles.options.test_audio_dir=pathname;
        handles.options.test_audio_filename=filename(1:end-4);
        
        [d,sr]=wavread(full_dir);
        d=resample(d,handles.options.SR,sr);
        x=[1:length(d)]/handles.options.SR;
        delete(handles.logo_plot);
        
        %B. output the name and the length of the song
        set(handles.indicator_text,'string',['Wav file: ',filename, ' (',num2str(x(end)),' s)']);
        set(handles.indicator_text,'foregroundcolor','black');
        
        set(handles.wave_plot,'visible','on');
        plot(handles.wave_plot,x,d);
        axis(handles.wave_plot,[0 x(end)+1 -1 1]);
        clear x d
        pause(0.1);
        
        %B. Enable the task/parameters settings
        set(handles.task_pannel,'visible','on');
        set(handles.par_pannel,'visible','on');
        set(handles.run_button,'visible','on');
        set(handles.exit_button,'visible','on');
      

        %C. Disable the load function until it click new button
        set(handles.open_song,'enable','off');
        
        %D. Set play function on
        set(handles.play_button,'enable','on');
        
        %E. Save the object changes
        guidata(hObject,handles);
    end   
end
return;
% --- Reading the wav files and parameter settings




% --- Main Process.
function run_button_Callback(hObject, eventdata, handles)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Main Process for chrod predictions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%1. Configulation
success_flag=0;

%A. Loading parameters
bass_fmin=str2double(get(handles.bass_fmin,'string'));
bass_fmax=str2double(get(handles.bass_fmax,'string'));
bass_interval=floor(12*log2(bass_fmax/bass_fmin)+0.5)+1;
bass_r=str2double(get(handles.bass_r,'string'));
treble_fmin=str2double(get(handles.treble_fmin,'string'));
treble_fmax=str2double(get(handles.treble_fmax,'string'));
treble_r=str2double(get(handles.treble_r,'string'));
treble_interval=floor(12*log2(treble_fmax/treble_fmin)+0.5)+1;

switch get(handles.sr_popupmenu,'value')
    case 1
        resample_rate=11025;
    case 2
        resample_rate=11025;
    case 3
        resample_rate=8000;
end


%B. Error checking
if (isnan(bass_fmin) || bass_fmin<=0)
    questdlg('Error: bass fmin is out of expected range.',...
        'Parameter setting error','Ok','Ok');
elseif (isnan(bass_fmax) || bass_fmax<=0)
     questdlg('Error: bass fmax is out of expected range.',...
        'Parameter setting error','Ok','Ok');
elseif (isnan(bass_r) || bass_r<=0)
     questdlg('Error: bass resolution is out of expected range.',...
        'Parameter setting error','Ok','Ok');
elseif (isnan(treble_fmin) || treble_fmin<=0)
     questdlg('Error: treble fmin is out of expected range.',...
        'Parameter setting error','Ok','Ok');
elseif (isnan(treble_fmax) || treble_fmax<=0)
    questdlg('Error: treble fmax is out of expected range.',...
        'Parameter setting error','Ok','Ok');
elseif (isnan(treble_r) || treble_r<=0)
    questdlg('Error: treble resolution is out of expected range.',...
        'Parameter setting error','Ok','Ok');
elseif (bass_fmin>=bass_fmax)
    questdlg('Error: bass fmin should be smaller than bass fmax.',...
        'Parameter setting error','Ok','Ok');
elseif (treble_fmin>=treble_fmax)
     questdlg('Error: treble fmin should be smaller than treble fmax.',...
        'Parameter setting error','Ok','Ok');
elseif (mod(bass_interval,12)>0)
    questdlg(['Warning: the bass interval is ', int2str(bass_interval),'semi-tones, but currently HP only supports integral octaves (12x semitones).'],...
        'Parameter setting error','Ok','Ok');
elseif (mod(bass_interval,12)>0)
    questdlg(['Warning: the treble interval is ', int2str(treble_interval),'semi-tones, but currently HP only supports integral octaves (12x semitones).'],...
        'Parameter setting error','Ok','Ok');
else
    success_flag=1;
end

%C. If error, reset the parameters.
if (success_flag==0)
    set(handles.indicator_text,'string','Error: could not process the song due to parameter errors.');
    set(handles.indicator_text,'foregroundcolor','red');
    set(handles.chord_plot,'visible','off');
    set(handles.bass_fmin,'string',num2str(handles.options.bass_fmin));
    set(handles.bass_fmax,'string',num2str(handles.options.bass_fmax));
    set(handles.bass_r,'string',num2str(handles.options.bass_resolution_fact));
    set(handles.treble_fmin,'string',num2str(handles.options.treble_fmin));
    set(handles.treble_fmax,'string',num2str(handles.options.treble_fmax));
    set(handles.treble_r,'string',num2str(handles.options.treble_resolution_fact));
    return;
else
    %Else, reading the parameters
    
    set(handles.indicator_text,'string','Reading the parameters successfully, start the HP system...');
    set(handles.indicator_text,'foregroundcolor','black');
    pause(0.5);
    
    handles.options.bass_fmin=bass_fmin;
    handles.options.bass_fmax=bass_fmax;
    handles.options.bass_resolution_fact=bass_r;
    handles.options.treble_fmin=treble_fmin;
    handles.options.treble_fmax=treble_fmax;
    handles.options.treble_resolution_fact=treble_r;
    handles.options.SR=resample_rate;
    set(handles.bass_fmin,'enable','off');
    set(handles.bass_fmax,'enable','off');
    set(handles.bass_r,'enable','off');
    set(handles.treble_fmin,'enable','off');
    set(handles.treble_fmax,'enable','off');
    set(handles.treble_r,'enable','off');
    set(handles.sr_popupmenu,'enable','off');
    
    set(handles.save_annotation,'enable','off');
    set(handles.new_hp,'enable','off');

    set(handles.chord_plot,'visible','off');


    if (get(handles.min_maj_button,'value'))
        handles.options.modelLabel = 'minmaj';
    elseif (get(handles.full_button,'value'))
        handles.options.modelLabel = 'full';
    else
        handles.options.modelLabel = 'LBC_extraction';
    end
    
    
    %Optional: set all functions in playlist off
    set(handles.play_button,'enable','off');
    set(handles.stop_play_button,'enable','off');
    set(handles.pause_play_button,'enable','off');
    set(handles.min_maj_button,'enable','off');
    set(handles.full_button,'enable','off');
    set(handles.LBC_button,'enable','off');
end


%2. Main chrod recognition process
%2.1 Feature extraction
[bass_normal_chromagrams,treble_normal_chromagrams,~,sample_times]=MIR_mainProcess_extractFeatures_forHPGUI(handles.options.test_audio_file,handles.options,handles.indicator_text);

if (strcmp(handles.options.modelLabel,'LBC_extraction')) %Feature extraction task
    num_note=size(bass_normal_chromagrams,1);
    fid=fopen([handles.options.test_audio_file,'.tmp'],'w');
    for i=1:size(sample_times,1)
        %A. output the beat time
        fprintf(fid,[num2str(sample_times(i,1)),' ']);
        fprintf(fid,[num2str(sample_times(i,2)),' ']);

        %B. Bass chromagram
        for j=1:num_note
            fprintf(fid,[num2str(bass_normal_chromagrams(j,i)),' ']);
        end
        %C. Treble chromagram
        for j=1:num_note
            fprintf(fid,[num2str(treble_normal_chromagrams(j,i)),' ']);
        end
        fprintf(fid,'\n');
    end
    fclose(fid);
    %D. Display information
    handles.LBC_saved_flag=0;
    set(handles.indicator_text,'string','Extracted LBC chromagrams. Store it in a .tmp file.');
    set(handles.indicator_text,'foregroundcolor','black');
else
    %2.2 Chord predictions
    pretrainFile_dir=[handles.options.toolbox_dir,'\pre_trainSystem\'];
    if (strcmpi(handles.options.modelLabel,'minmaj'))
        pretrainFile_name='MIREX_minmaj_PretrainSystem_reFinedAnns_091111';
    elseif(strcmpi(handles.options.modelLabel,'full'))
        pretrainFile_name='MIREX_fullChord_PretrainSystem_reFinedAnns_091111';
    end
    
    [HP_predictions, classes] = HP_PretrainSystem_forHP_GUI(bass_normal_chromagrams, treble_normal_chromagrams, pretrainFile_dir, pretrainFile_name, 1, handles.indicator_text);
    handles.chord_predictions=HP_predictions(2:end-1);
    handles.chord_names = classes;
    handles.sample_times = sample_times;
    handles.saved_flag=0;  %Reset save flag
    
    %2.3 Visualization
    set(handles.chord_plot,'visible','on');
    imagesc(handles.chord_predictions,'parent',handles.chord_plot);
    axis off
end

clear bass_normal_chromagrams treble_normal_chromagrams beat_times sample_times

%2.4 Save the object changes
set(handles.save_annotation,'enable','on');
set(handles.new_hp,'enable','on');

set(handles.bass_fmin,'enable','on');
set(handles.bass_fmax,'enable','on');
set(handles.bass_r,'enable','on');
set(handles.treble_fmin,'enable','on');
set(handles.treble_fmax,'enable','on');
set(handles.treble_r,'enable','on');
set(handles.sr_popupmenu,'enable','on');

set(handles.min_maj_button,'enable','on');
set(handles.full_button,'enable','on');
set(handles.LBC_button,'enable','on');

%Optional: set all functions in playlist on
if (isfield(handles,'player'))
    if (isplaying(handles.player.handle))
        set(handles.stop_play_button,'enable','on');
        set(handles.pause_play_button,'enable','on');
        handles.player.pause=0;
    else
        set(handles.play_button,'enable','on');
        handles.player.pause=0;
    end
else
    set(handles.play_button,'enable','on');
end


guidata(hObject,handles);

return;
% --- Main Process.



% --- Writting the predictions (on .txt file)
function save_annotation_ClickedCallback(hObject, eventdata, handles)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Save the annotations on a .txt file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if (strcmp(handles.options.modelLabel,'LBC_extraction')) %Feature extraction task
    [filename, pathname] = uiputfile([handles.options.test_audio_filename,'_',handles.options.modelLabel,'_LBC.txt'], 'Specify a file name to save the loudness based chromagram (LBC).');
    %1. Create a file name
    if isequal(filename,0) || isequal(pathname,0)
        set(handles.indicator_text,'string','No txt file is created.')
    else
        %2. save the predictions
        full_dir=[pathname,filename];
        copyfile([handles.options.test_audio_file,'.tmp'],full_dir);
        delete([handles.options.test_audio_file,'.tmp']);
        handles.LBC_saved_flag=1;
        set(handles.indicator_text,'string','Save the LBC file successfully.')
    end
else
    [filename, pathname] = uiputfile([handles.options.test_audio_filename,'_',handles.options.modelLabel,'_prediction.txt'], 'Specify a file name to save the chord predictions.');
    %1. Create a file name
    if isequal(filename,0) || isequal(pathname,0)
        set(handles.indicator_text,'string','No txt file is created.')
    else
        %2. save the predictions
        full_dir=[pathname,filename];
        MIR_writePrediction_to_file(handles.chord_predictions,handles.sample_times,handles.chord_names,full_dir);
        handles.saved_flag=1;
        set(handles.indicator_text,'string','Save the chord predictions successfully.')
    end
end

%Save the object changes
guidata(hObject,handles);

return;
% --- Writting the predictions (on .txt file)




% --- Creating a new application
function new_hp_ClickedCallback(hObject, eventdata, handles)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Creating new applications
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if (strcmp(handles.options.modelLabel,'LBC_extraction')) %Feature extraction task
    if (exist([handles.options.test_audio_file,'.tmp'],'file') && handles.LBC_saved_flag==0)
        selection = questdlg('Warning: seems you have not save the LBC extraction, continue to new application anyway?',...
            'New HP App Request Function','Yes','No','No');
    else
        selection='Yes';
    end
else
    if (~isempty(handles.chord_predictions) && handles.saved_flag==0)
        selection = questdlg('Warning: seems you have not save the chord predictions, continue to new application anyway?',...
            'New HP App Request Function','Yes','No','No');
    else
        selection='Yes';
    end
end

switch selection,
    case 'Yes',
        if (isfield(handles,'player') && isplaying(handles.player.handle))
            stop(handles.player.handle);
        end
        
        if (exist([handles.options.test_audio_file,'.tmp'],'file')) %delete the temp files
            delete([handles.options.test_audio_file,'.tmp']);
        end
        
        delete(gcf);
        HP_system_GUI;
    case 'No'
        return;
end

return;

% --- Exit function.
function exit_button_Callback(hObject, eventdata, handles)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Exit
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if (strcmp(handles.options.modelLabel,'LBC_extraction')) %Feature extraction task
    if (exist([handles.options.test_audio_file,'.tmp'],'file') && handles.LBC_saved_flag==0)
        selection = questdlg('Warning: seems you have not save the LBC extraction, continue to new application anyway?',...
            'New HP App Request Function','Yes','No','No');
    else
        selection='Yes';
    end
else
    if (~isempty(handles.chord_predictions) && handles.saved_flag==0)
        selection = questdlg('Warning: seems you have not save the chord predictions, continue to new application anyway?',...
            'New HP App Request Function','Yes','No','No');
    else
        selection='Yes';
    end
end

switch selection,
    case 'Yes',
        if (isfield(handles,'player') && isplaying(handles.player.handle))
            stop(handles.player.handle);
        end
        
        if (exist([handles.options.test_audio_file,'.tmp'],'file')) %delete the temp files
            delete([handles.options.test_audio_file,'.tmp']);
        end
        
        delete(gcf);
    case 'No'
        return;
end

return;




%%%%%%%%%%%%%%%%%%%%%%%%%Optional: play the songs %%%%%%%%%%%%%%%%%%%%%%%%%
% ---- play the song
function play_button_ClickedCallback(hObject, eventdata, handles)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Play the song button
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if (~isfield(handles,'player'))   %If it is a new play
    handles.player=struct;
    [d,sr]=wavread(handles.options.test_audio_file);
    handles.player.handle=audioplayer(d,sr);
    handles.player.handle.StopFcn = { @my_callback_enablePlay,handles};
    handles.player.pause=0;
    play(handles.player.handle);
    clear d sr
elseif (handles.player.pause==1) %If it is pause
    resume(handles.player.handle);
    handles.player.pause=0;
else
    handles.player.pause=0;
    play(handles.player.handle);
end
    

set(handles.play_button,'enable','off');
set(handles.pause_play_button,'enable','on');
set(handles.stop_play_button,'enable','on');

guidata(hObject,handles);
return;



% --- stop playing
function stop_play_button_ClickedCallback(hObject, eventdata, handles)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Stop playing
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
stop(handles.player.handle);
set(handles.play_button,'enable','on');
set(handles.stop_play_button,'enable','off');
set(handles.pause_play_button,'enable','off');
handles.player.pause=0;
guidata(hObject,handles);
return;


% --- pause playing
function pause_play_button_ClickedCallback(hObject, eventdata, handles)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Pause playing
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pause(handles.player.handle);
handles.player.pause=1;
set(handles.play_button,'enable','on');
set(handles.stop_play_button,'enable','on');
set(handles.pause_play_button,'enable','off');
guidata(hObject,handles);
return;

% --- enable playing again
function my_callback_enablePlay(obj, event, handles)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Enable playing
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
set(handles.play_button,'enable','on');
set(handles.stop_play_button,'enable','off');
set(handles.pause_play_button,'enable','off');
return;
%%%%%%%%%%%%%%%%%%%%%%%%%Optional: play the songs %%%%%%%%%%%%%%%%%%%%%%%%%





function bass_fmin_Callback(hObject, eventdata, handles)
% hObject    handle to bass_fmin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bass_fmin as text
%        str2double(get(hObject,'String')) returns contents of bass_fmin as a double


% --- Executes during object creation, after setting all properties.
function bass_fmin_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bass_fmin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bass_fmax_Callback(hObject, eventdata, handles)
% hObject    handle to bass_fmax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bass_fmax as text
%        str2double(get(hObject,'String')) returns contents of bass_fmax as a double


% --- Executes during object creation, after setting all properties.
function bass_fmax_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bass_fmax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bass_r_Callback(hObject, eventdata, handles)
% hObject    handle to bass_r (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bass_r as text
%        str2double(get(hObject,'String')) returns contents of bass_r as a double


% --- Executes during object creation, after setting all properties.
function bass_r_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bass_r (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function treble_fmin_Callback(hObject, eventdata, handles)
% hObject    handle to treble_fmin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of treble_fmin as text
%        str2double(get(hObject,'String')) returns contents of treble_fmin as a double


% --- Executes during object creation, after setting all properties.
function treble_fmin_CreateFcn(hObject, eventdata, handles)
% hObject    handle to treble_fmin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function treble_fmax_Callback(hObject, eventdata, handles)
% hObject    handle to treble_fmax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of treble_fmax as text
%        str2double(get(hObject,'String')) returns contents of treble_fmax as a double


% --- Executes during object creation, after setting all properties.
function treble_fmax_CreateFcn(hObject, eventdata, handles)
% hObject    handle to treble_fmax (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function treble_r_Callback(hObject, eventdata, handles)
% hObject    handle to treble_r (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of treble_r as text
%        str2double(get(hObject,'String')) returns contents of treble_r as a double


% --- Executes during object creation, after setting all properties.
function treble_r_CreateFcn(hObject, eventdata, handles)
% hObject    handle to treble_r (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





% --- Executes during object creation, after setting all properties.
function sr_popupmenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sr_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in sr_popupmenu.
function sr_popupmenu_Callback(hObject, eventdata, handles)
% hObject    handle to sr_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns sr_popupmenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from sr_popupmenu
