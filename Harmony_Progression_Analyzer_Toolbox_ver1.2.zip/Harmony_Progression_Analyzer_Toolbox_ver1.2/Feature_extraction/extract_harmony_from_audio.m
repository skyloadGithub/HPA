 function [xharmony,semisoff,resample_rate,beat_times,options]=extract_harmony_from_audio(wavfile,options)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
%[xharmony,semisoff,resample_rate,beat_times]=extract_harmony_from_audio(wavfile,options)
% 
% This function reads in a wav file and extracts harmony, 
% using the parameters defined in options. 
%
% INPUTS  
%         - wavfile. name of a microsoft wave file
%         - Options. Structure of paramters. Fields:
%          options.display = 1 if progress is to be displayed on screen, 0
%                            otherwise.
%          options.resample_rate = rate in Hz to resample.
%
%          options.tuning_fft_len = length of fft to use for tuning
%          options.f_ctr = central frequency for tuning
%          options.f_sd = bound on the frequencies for tuning
%
%          options.HPSS_fftlen = length of fft used to split harmony and percussion
%          options.HPSS_hoplen = hop to use for HPSS
%          options.HPSS_window = window size for HPSS
%          options.gamma = power spectrum reduction factor in [0,1]
%          options.alpha = overlap parameter in [0,1]
%          options.kmax = number of iterations of HPSS
%          options.wavwrite = 1: write the harmonic component to wav,
%                             0: otherwise.
%
%          options.feature_beatsynch = 1 for beat synchronisation, else 0.
%          options.beat_tightness = for beat tracker (default 3).
%          options.startbpm = for beat tracker (default 120).
%          options.feature_hoplen = number of hop samples for a frame (used
%                                   in non-beat synchronized version).
%
% OUTPUTS 
%
%         - xharmony. The harmony of the song.
%         - semisoff. The tuning of the song.
%         - resample_rate. The re-sample rate of the song.
%         - beat_times. The beat times (or sampling times if non-beat
%           synchronized).
%         - options. Return options used.
%  
%---------------------------------------------
%Function created by M. McVicar
%Function revised by Y. Ni
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%  1. Set default parameters %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Check for options
if nargin < 2; options = struct; end
if isempty(options); options=struct; end

% General Options
if ~isfield(options,'display'); options.display=1; end

% Wave Options
if ~isfield(options,'resample_rate'); options.resample_rate=11025; end

% Tuning Options
if ~isfield(options,'tuning_fftlen'); options.tuning_fftlen=4096; end
if ~isfield(options,'f_ctr'); options.f_ctr=400; end
if ~isfield(options,'f_sd'); options.f_sd=1; end

% Harmonic/Percussive source separation Options
if ~isfield(options,'HPSS_fftlen'); options.HPSS_fftlen=1024; end
if ~isfield(options,'HPSS_hop'); options.HPSS_hoplen=512; end
if ~isfield(options,'HPSS_window'); options.HPSS_window=4096; end
if ~isfield(options,'gamma'); options.gamma=0.3; end
if ~isfield(options,'alpha'); options.alpha=0.3; end
if ~isfield(options,'kmax'); options.kmax=50; end
if ~isfield(options,'wavwrite');options.wavwrite=0; end

% Beat Estimation Options
if ~isfield(options,'beat_tightness'); options.beat_tightness=3; end
if ~isfield(options,'startbpm'); options.startbpm=120; end
if ~isfield(options,'feature_hoplen'); options.feature_hoplen=256; end
if ~isfield(options,'feature_beatsynch'); options.feature_beatsynch=1; end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%  2. Read in the wavfile and format nicely  %%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%tic;

% Format file name
fslashes=strfind(wavfile,'/');

if isempty(fslashes)
    % No slash, so local or linux
    bslashes=strfind(wavfile,'\');
    if isempty(bslashes)
        % Local file
        filename=wavfile;
    else
        % Linux style
        lastslash=bslashes(end);
        filename=wavfile(lastslash+1:end);
    end
    
else
    % Windows style
    lastslash=fslashes(end);
    filename=wavfile(lastslash+1:end-4);
end

% Display the name of the song
disp(filename);

% Read wave
if options.display==1
    disp('Reading wave file...')
end

[x,sr,nbits]=wavread(wavfile);

% Convert to mono and resmaple.
if size(x,2)==2
    x=mean(x,2);
end

if (options.resample_rate~=sr)
    % resample rate ratio
    x=resample(x,options.resample_rate,sr);
end
resample_rate=options.resample_rate;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%  3. Estimate tuning  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Get the tuning
if options.display==1
    disp('Estimating tuning...')
end
semisoff=estimate_tuning(x,options.resample_rate,...
    options.tuning_fftlen,options.f_ctr,options.f_sd);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%  4. Split Harmony/Percussion  %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if options.display==1
    disp('Splitting harmony and percussion...')
end

xharmony=HPSS(x,options.HPSS_fftlen,options.HPSS_hoplen,...
    options.HPSS_window,options.gamma,options.alpha,options.kmax);

% option: write the harmony wav?
if options.wavwrite==1;
    wavwrite(xharmony,options.resample_rate,nbits,...
        [options.directory,filename,'_harmony.wav']);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%  5. Calculate Beats  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
if options.feature_beatsynch==1
    if options.display==1
        disp('Calculating beats...')
    end
   
    beat_times= estimate_beats(xharmony,options.resample_rate,options.startbpm,...
        options.beat_tightness);
else
    beat_times=[1:options.feature_hoplen:length(xharmony)]/resample_rate;
end

%toc;
