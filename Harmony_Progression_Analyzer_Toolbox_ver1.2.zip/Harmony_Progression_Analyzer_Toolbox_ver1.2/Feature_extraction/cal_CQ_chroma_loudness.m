function [chromagram, normal_chromagram, sample_times]=cal_CQ_chroma_loudness(x,SR, beat_times, hammingK, half_winLenK, freqK, refLabel, A_weightLabel,q_value,normFlag)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
%
%[chromagram,normal_chromagram,sample_times]=cal_CQ_chroma_loudness(x,SR,...
%beat_times, hammingK, half_winLenK, freqK, refLabel, A_weightLabel,q_value,normFlag)
%
%Main function to compute the loudness based beat-sync (or fixed length) chromagram features
%
% INPUTS
%x - the wave signal (from wavread)
%SR - the sample rate 
%beat_time - the beat time (unit: second)
%hammingK - the hamming windows for each frequency
%half_winLenK - the half_length of each hamming window k
%freqK - the k'th frequency
%(Computed by .m function: cal_hamming_window)
%refLabel - the reference label, 'n': no reference (i.e. 1); 
%                                's':the standard human perceivable level, 10^(-12)
%                                'mean':related to the average loudness of the song (i.e. ref=mean(power sequence)); 
%                                'median':related to the average loudness of the song (i.e. ref=median(power sequence));
%                                'q':using the q-quantile power as the reference (need 0<=q_value<=1) 
%                                (i.e. regarding q_value percent of the frames as slience) 
%A_weightLabel - 1:using A weighting; 0:otherwise
%Remark: A-weighting is a scaling curve on the amplitude spectrum, see
%http://en.wikipedia.org/wiki/A-weighting
%q_value - used in q-quantile reference
%normFlag - 'n': normal features and normalization used is: frame=(frame-min(frame))/(max(frame)-min(frame))
%           's': shift version, loudness=10*log10(power/ref+1);
%           normalization used is L1 norm: frame=frame/max(frame)
%
% OUTPUTS
%chromagram - the loudness based chromagram features (length Nb+1)
%normal_chromagram - the normalized loudness chromagram features (length Nb+1)
%sample_times - the sample times for each frame, formated as a Nx2 matrix [start_times,end_times]
%
%---------------------------------------------
%Function created by Y. Ni
%Function revised by M. McVicar
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 0. Defaults
if nargin < 7; refLabel='mean'; end
if nargin < 8; A_weightLabel=1; end
if nargin < 9; q_value=0; end
if nargin < 10; normFlag='n'; end

%1. configulation
bins=12;
Nxorig = length(x);
if (size(x,1)==1) %a row vector
    x=x';
end
x = [x ; zeros(2^ceil(log2(Nxorig))-Nxorig,1)]; %Add the end to make the length to be 2^N
Nx = length(x);
K=length(hammingK);                             %The number of frequency bins
xf=fft(x);

%special: check whether hamming window length is > length(xf)%%%%%%%%%%%%%
warningFlag=zeros(1,K);
for k=1:K
    if (length(hammingK{k})>Nx)
        warning('In function cal_CQ_chroma_loudness: certain hamming winow is wider than the music itself.');
        warningFlag(k)=1;
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%1.1 The beat-time interval
beatSR=ceil(beat_times*SR);                     %Get the beat time (transform it into sample indices)
beatSR(beatSR>=Nxorig)=[];                      %delete those samples that have exceeded the end of the song

if (size(beatSR,1)==1)
    if (beatSR(1)==0)
        beatSR=[beatSR Nxorig];
    else
        beatSR=[0 beatSR Nxorig];
    end
else
    if (beatSR(1)==0)
        beatSR=[beatSR;Nxorig];
    else
        beatSR=[0;beatSR;Nxorig];
    end
end

numF=length(beatSR)-1;

%1.2 reference label
if (strcmp(refLabel,'n'))
    refPower=1;
elseif (strcmp(refLabel,'s'))
    refPower=10^(-12);
elseif (strcmp(refLabel,'mean'))
    meanPowerK=zeros(1,K); 
elseif (strcmp(refLabel,'median'))
    medianPowerK=zeros(1,K);
elseif (strcmp(refLabel,'q'))
    quantile_matrix=zeros(Nxorig,1);            %Store the average power of each frame
    if (q_value<0 || q_value>1)
        error('Error in cal_CQ_chroma_loudness: the q value exceeds boundaries.');
    end
else
    error('Error in cal_CQ_chroma_loudness: can not find the reference label.');
end

%1.3 A-weight parameters
if (A_weightLabel)
    Ap1=12200^2;
    Ap2=20.6^2;
    Ap3=107.7^2;
    Ap4=737.9^2;
end

%2. Compute the CQ matrix for each point (row) and each frequency bin (column)
A_offsets=zeros(K,1);
CQ=zeros(K,numF);
if (strcmp(normFlag,'s')) %shifted chromagram
    for k=1:K
        %2.1. Get the constant Q tranformation
        half_len=half_winLenK(k);
        w=[hammingK{k}(half_len:end);zeros(Nx-length(hammingK{k}),1);hammingK{k}(1:half_len-1)];
        wf = fft(w);
        if (warningFlag(k))
            xft=[xf;zeros(length(wf)-length(xf),1)];
            convolf = xft.*wf;
        else
            convolf = xf.*wf;
        end
        convol = ifft(convolf);
        
        %2.2. A-weighting
        if (A_weightLabel)
            frequency_k2=freqK(k)^2;
            A_scale=Ap1*frequency_k2^2/((frequency_k2+Ap2)*sqrt((frequency_k2+Ap3)*(frequency_k2+Ap4))*(frequency_k2+Ap1));
            A_offsets(k)=2.0+20*log10(A_scale);
        end
        
        
        %2.3. Reference power and A weighting
        if (strcmp(refLabel,'mean'))
            convol=abs(convol(1:Nxorig)).^2;
            meanPowerK(k)=mean(convol);
        elseif (strcmp(refLabel,'median'))
            convol=abs(convol(1:Nxorig)).^2;
            medianPowerK(k)=median(convol);
        elseif (strcmp(refLabel,'q'))
            convol=abs(convol(1:Nxorig)).^2;
            quantile_matrix=quantile_matrix+convol;
        else
            convol=(abs(convol(1:Nxorig))).^2;
        end
        
        
        
        %2.4. Get the beat interval (median)
        for t=1:numF
            CQ(k,t)= median(convol(beatSR(t)+1:beatSR(t+1)));
        end
    end
    
    %2.5 Add the reference power (for mean/median/q-quantiles)
    if (strcmp(refLabel,'mean'))
        refPower=mean(meanPowerK);
        CQ=10*log10(CQ+refPower)-10*log10(refPower)+repmat(A_offsets,1,numF);
    elseif (strcmp(refLabel,'median'))
        refPower=median(medianPowerK);
        CQ=10*log10(CQ+refPower)-10*log10(refPower)+repmat(A_offsets,1,numF);
    elseif (strcmp(refLabel,'q'))
        quantile_value=sort(quantile_matrix); %sort the values, set reference as the value that falls in the q_value%-th of examples
        refPower=quantile_value(floor(q_value*Nxorig))/K;
        CQ=10*log10(CQ+refPower)-10*log10(refPower)+repmat(A_offsets,1,numF);
    else
        CQ=10*log10(CQ+refPower)-10*log10(refPower)+repmat(A_offsets,1,numF);
    end
    
    
    %3. Computer the beat sync-ed chromagram
    chromagram=zeros(bins,numF);
    normal_chromagram=zeros(bins,numF);
    
    for i=1:bins
        chromagram(i,:) = sum(CQ(i:bins:end,:));
    end
    
    
    %4. Compute the normalized chromagram features (L1 norm)
    for i=1:size(chromagram,2)
        temp_max=max(chromagram(:,i));
        if (temp_max>0)
            normal_chromagram(:,i)=chromagram(:,i)/temp_max;
        end
    end
    
elseif (strcmp(normFlag,'n')) %normal chromagram
    for k=1:K
        %2.1. Get the constant Q tranformation
        half_len=half_winLenK(k);
        w=[hammingK{k}(half_len:end);zeros(Nx-length(hammingK{k}),1);hammingK{k}(1:half_len-1)];
        wf = fft(w);
        convolf = xf.*wf;
        convol = ifft(convolf);
        
        %2.2. A-weighting
        if (A_weightLabel)
            frequency_k2=freqK(k)^2;
            A_scale=Ap1*frequency_k2^2/((frequency_k2+Ap2)*sqrt((frequency_k2+Ap3)*(frequency_k2+Ap4))*(frequency_k2+Ap1));
            A_offsets(k)=2.0+20*log10(A_scale);
        end
        
        %2.3. Reference power and A weighting
        if (strcmp(refLabel,'mean'))
            convol=abs(convol(1:Nxorig)).^2;
            meanPowerK(k)=mean(convol);
        elseif (strcmp(refLabel,'median'))
            convol=abs(convol(1:Nxorig)).^2;
            medianPowerK(k)=median(convol);
        elseif (strcmp(refLabel,'q'))
            convol=abs(convol(1:Nxorig)).^2;
            quantile_matrix=quantile_matrix+convol;
        else
            convol=(abs(convol(1:Nxorig))).^2;
        end
        
        %2.4. Get the beat interval (median)
        for t=1:numF
            CQ(k,t)= median(convol(beatSR(t)+1:beatSR(t+1)));
        end
    end
    
    %2.5 Add the reference power (for mean/median/q-quantiles)
    if (strcmp(refLabel,'mean'))
        refPower=mean(meanPowerK);
        CQ=10*log10(CQ)-10*log10(refPower)+repmat(A_offsets,1,numF);
    elseif (strcmp(refLabel,'median'))
        refPower=median(medianPowerK);
        CQ=10*log10(CQ)-10*log10(refPower)+repmat(A_offsets,1,numF);
    elseif (strcmp(refLabel,'q'))
        quantile_value=sort(quantile_matrix); %sort the values, set reference as the value that falls in the q_value%-th of examples
        refPower=quantile_value(floor(qValue*Nxorig))/K;
        CQ=10*log10(CQ)-10*log10(refPower)+repmat(A_offsets,1,numF);
    else
        CQ=10*log10(CQ)-10*log10(refPower)+repmat(A_offsets,1,numF);
    end
    
    
    %3. Computer the beat sync-ed chromagram
    chromagram=zeros(bins,numF);
    normal_chromagram=zeros(bins,numF);
    
    for i=1:bins
        chromagram(i,:) = sum(CQ(i:bins:end,:));
    end
    
    
    %4. Compute the normalized chromagram features (Linear norm)
    for i=1:size(chromagram,2)
        maxCol=max(chromagram(:,i));
        minCol=min(chromagram(:,i));
	if (maxCol>minCol)
            normal_chromagram(:,i)=(chromagram(:,i)-minCol)/(maxCol-minCol);
	else
	    normal_chromagram(:,i)=0;
	end
    end
    
else
    error('Error in cal_CQ_chroma_loudness: no such normFlag.');
end

%*. Do the circle shift
shift_pos=round(12*log2(freqK(1)/27.5)); %The relative position to A0
shift_pos=mod(shift_pos,12)-3;                   %since A0 should shift -3
if (shift_pos~=0)
    chromagram=circshift(chromagram,shift_pos);
    normal_chromagram=circshift(normal_chromagram,shift_pos);
end


%5. return the sample times
beatSR=beatSR/SR; %beat times
if (size(beatSR,1)==1) %a row
    sample_times=[beatSR(1:end-1)',beatSR(2:end)'];
else
    sample_times=[beatSR(1:end-1),beatSR(2:end)];
end

return;
