function [hammingK,half_winLenK,freqBins]=cal_hamming_window(SR, minFreq, maxFreq, resolution_fact,tuning)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
%[hammingK,half_winLenK,freqBins]=cal_hamming_window(SR, minFreq, maxFreq, resolution_fact,tuning)
%This function computes the hamming window for the constant Q transformation.
%
% INPUTS
%SR - the sample rate
%minFreq - the lowest frequency (e.g. 55HZ)
%maxFreq - the highest frequency (e.g. 1661HZ)
%resolution_fact - the resolution of Q (Q_new=Q_org*resolution)
%tuning - tuning parameter, fk=fk*2^(tuning/bins)
%
% OUTPUTS
%hammingK - the hamming windows for each frequency
%half_winLenK - the half_length of each hamming window k
%freqBins - the frequency of each hamming window
%
%---------------------------------------------
%Function created by Y. Ni
%Function revised by M. McVicar
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 0. Defaults
if nargin < 2; minFreq = 220; end
if nargin < 3; maxFreq = 1661; end
if nargin < 4; resolution_fact = 5; end
if nargin < 5; tuning = 0; end

%1. Configulation
bins=12;
pitchClass=12;
pitchInterval=bins/pitchClass;
pitchIntervalMap=zeros(1,bins);

for i=1:pitchClass
    pitchIntervalMap((i-1)*pitchInterval+1:i*pitchInterval)=i;
end
      

%2. Frequency bins
K=ceil(log2(maxFreq/minFreq))*bins;  %The number of bins
freqBins=zeros(1,K);

%semiInterval=[-bins_fact/bins 0 bins_fact/bins];

for i=0:pitchInterval:K-pitchInterval
    octaveIndex=floor(i/bins);
    binIndex=mod(i,bins)+1;
    %freqBins(i+1:i+pitchInterval)=minFreq*2.^(octaveIndex+(pitchIntervalMap(binIndex)-1)/pitchClass+semiInterval); %Get the bins of frequencies
    freqBins(i+1:i+pitchInterval)=minFreq*2.^(octaveIndex+(pitchIntervalMap(binIndex)-1)/pitchClass); %Get the bins of frequencies
end

freqBins=freqBins*2^(tuning/bins);

%3. Constant Q and window size
Q=1/(2^(1/bins)-1)*resolution_fact;
winLenK=ceil(SR*Q./freqBins);


%4. Construct the hamming window
half_winLenK=winLenK;
expFactor=-2*pi*1i*Q*(0:winLenK(1));
expFactor=expFactor';
hammingK=cell(1,K);
for k=1:K
    N=winLenK(k);
    half_winLenK(k)=ceil(N/2);
    hammingK{k}=hamming(N).* exp(expFactor(1:N)/N) / N;
end
