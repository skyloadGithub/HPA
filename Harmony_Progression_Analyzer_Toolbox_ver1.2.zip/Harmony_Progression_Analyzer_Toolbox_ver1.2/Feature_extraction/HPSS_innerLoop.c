/**
 *The inner loop of HPSS computation. Matlab code:
 for k=1:kmax
    %1. Do the boundary update. Its a square
    row=1;
    for col=1:colLen
        Hnew(row,col)=min(max(2*H(row,col),0),W(row,col));
        Pnew(row,col)=W(row,col)-Hnew(row,col);
    end
    
    row=rowLen;
    for col=1:colLen
        Hnew(row,col)=min(max(2*H(row,col),0),W(row,col));
        Pnew(row,col)=W(row,col)-Hnew(row,col);
    end
    
    col=1;
    for row=2:rowLen-1
        Hnew(row,col)=min(max(2*H(row,col),0),W(row,col));
        Pnew(row,col)=W(row,col)-Hnew(row,col);
    end
    
    col=colLen;
    for row=2:rowLen-1
        Hnew(row,col)=min(max(2*H(row,col),0),W(row,col));
        Pnew(row,col)=W(row,col)-Hnew(row,col);
    end
 
    %2. calculate delta, update H and P
    for col=2:colLen-1
        for row=2:rowLen-1
            delk=a1*(H(row,col-1)-2*H(row,col)+H(row,col+1))-a2*(P(row-1,col)-2*P(row,col)+P(row+1,col));
            Hnew(row,col)=min(max(H(row,col)+delk,0),W(row,col));
            Pnew(row,col)=W(row,col)-Hnew(row,col);
        end   % end row
    end   % end  col
    
    %3. Each iteration
    H=Hnew;
    P=Pnew;
end   % end k
 **/

#include "mex.h"
#include "matrix.h"

/*For Linux patch max/min*/
#ifndef max
	#define max( a, b ) ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
	#define min( a, b ) ( ((a) < (b)) ? (a) : (b) )
#endif
    
/* If you are using a compiler that equates NaN to zero, you must
 * compile this example using the flag -DNAN_EQUALS_ZERO. For example:
 *
 *     mex -DNAN_EQUALS_ZERO findnz.c
 *
 * This will correctly define the IsNonZero macro for your Compiler */

#if NAN_EQUALS_ZERO
#define IsNonZero(d) ((d)!=0.0 || mxIsNaN(d))
#else
#define IsNonZero(d) ((d)!=0.0)
#endif

void mexFunction(int nlhs,       mxArray *plhs[],
        int nrhs, const mxArray *prhs[]) {
    
    /* Declare variables */
    size_t rowLen, colLen, boundaryLen; /*The size of the W matrix*/
    size_t Kmax, row, col, k, temp_index;
    double a1, a2, tempValue;
    mxArray *Hnew, *Pnew, *boundary_index; /*the array matrix*/
    size_t *temp_kmax_point; /*the pointer*/
    double *Hnew_point, *Pnew_point, *H_point, *P_point, *W_point, *boundary_point, *temp_pointer;/*the pointers*/
    
    
    /*Warning message*/
    if (nrhs != 6) {
        mexErrMsgTxt("There are five inputs: H, P, W, a1, a2 and Kmax.");
    }
    
    if (nlhs > 2){
        mexErrMsgTxt("Too many output arguments.");
    }
    
    
    
    /*1. Initialization*/
    rowLen=mxGetM(prhs[2]);
    colLen=mxGetN(prhs[2]);
    
    Hnew=mxCreateDoubleMatrix(rowLen, colLen, mxREAL); /*Harmony matrix*/
    Pnew=mxCreateDoubleMatrix(rowLen, colLen, mxREAL);    /*Percussion matrix*/
    boundaryLen=2*rowLen+2*colLen-4;
    boundary_index=mxCreateDoubleMatrix(boundaryLen,1,mxREAL); /*The boundary index matrix*/
   
    
    H_point=mxGetPr(prhs[0]); /*The original Harmony matrix*/
    P_point=mxGetPr(prhs[1]); /*The original Percussion matrix*/
    W_point=mxGetPr(prhs[2]); /*The original W matrix*/
    temp_pointer=mxGetPr(prhs[3]); /*parameter a1*/
    a1=temp_pointer[0];
    temp_pointer=mxGetPr(prhs[4]); /*parameter a2*/
    a2=temp_pointer[0];
    temp_pointer=mxGetPr(prhs[5]); /*parameter Kmax*/
    Kmax=(size_t)(temp_pointer[0]);
    
    
    /*2. Get the indices*/
    temp_pointer=mxGetPr(boundary_index);
    row=0;
    for (col=0;col<colLen;col++)
    {
        *temp_pointer++= (double) col*rowLen+row;
    }
    
    row=rowLen-1;
    for (col=0;col<colLen;col++)
    {
        *temp_pointer++=(double) col*rowLen+row;
    }
    
    col=0;
    for (row=1;row<rowLen-1;row++)
    {
        *temp_pointer++=(double) col*rowLen+row;
    }
    
    col=colLen-1;
    for (row=1;row<rowLen-1;row++)
    {
       *temp_pointer++=(double) col*rowLen+row;
    }
    
   
    
    /*3. Assign values*/
    Hnew_point=mxGetPr(Hnew);
    Pnew_point=mxGetPr(Pnew);
    boundary_point=mxGetPr(boundary_index);
    
    for (k=0;k<Kmax;k++)
    {
        /*3.1 Do the boundary update. Its a square*/
        for (row=0;row<boundaryLen;row++)
        {
            temp_index=(size_t)(boundary_point[row]);
            Hnew_point[temp_index]=min(max(2*H_point[temp_index],0),W_point[temp_index]);
            Pnew_point[temp_index]=W_point[temp_index]-Hnew_point[temp_index];
        }
        
        /*3.2 Do the inner update.*/
        for (col=1;col<colLen-1;col++)
        {
            for (row=1;row<rowLen-1;row++){
                temp_index=col*rowLen+row;
                tempValue=a1*(H_point[temp_index-rowLen]-2*H_point[temp_index]+H_point[temp_index+rowLen])-a2*(P_point[temp_index-1]-2*P_point[temp_index]+P_point[temp_index+1]);
                Hnew_point[temp_index]=min(max(H_point[temp_index]+tempValue,0),W_point[temp_index]);
                Pnew_point[temp_index]=W_point[temp_index]-Hnew_point[temp_index];
            }
        }
            
        /*3.3 exchange the pointer*/
        temp_pointer=Hnew_point;
        Hnew_point=H_point;
        H_point=temp_pointer;
        temp_pointer=Pnew_point;
        Pnew_point=P_point;
        P_point=temp_pointer;
    }
    
    
    
    /*4. Return the values*/
    plhs[0]=mxCreateDoubleMatrix(rowLen, colLen, mxREAL); /*Harmony matrix*/
    plhs[1]=mxCreateDoubleMatrix(rowLen, colLen, mxREAL);    /*Percussion matrix*/
    Hnew_point=mxGetPr(plhs[0]); 
    Pnew_point=mxGetPr(plhs[1]); 
    
    for (row=0;row<rowLen;row++) {
        for (col=0;col<colLen;col++) {
            temp_index=col*rowLen+row;
            Hnew_point[temp_index]=H_point[temp_index];
            Pnew_point[temp_index]=P_point[temp_index];
        }
    }
    
}