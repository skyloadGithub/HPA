function [xharmony,xpercussion]=HPSS(x,nfft,noverlap,window,gamma,alpha,kmax)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% [xharmony,xpercussion]=HPSS(x,nfft,noverlap,window,gamma,alpha,kmax)
%
% Splits the harmony and percussion of a wavfile.
% Prerquist: Fourier transformation function: stft.m/istft.m
%
% INPUTS            
%                   x - wavfile, mono
%                nfft - length of fft to use
%            noverlap - length of overlap of fft
%              window - length of window to use
%               gamma - power spectrum reduction factor
%               alpha - the degree of inital seperation
%                kmax - number of iterations.
%       
% OUTPUTS  
%            xharmony - the harmonic componant
%         xpercussion - the percussive componant
%
%---------------------------------------------
%Function created by M. McVicar
%Function revised by Y. Ni
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%1. Take the short time Fourier transformation
F=stft(x',nfft,window,noverlap);
clear x

%Power spectrum, reduced by gamma
W=abs(F).^(2*gamma);

%  disp('Diffusing Percussion and Harmony')
%2. Initialise Harmony, Percussion and index.
H=0.5*W;
P=0.5*W;

%3. Evaluate the constants
a1=alpha*0.25;
a2=(1-alpha)*0.25;
[rowLen,colLen]=size(W);

%4. Iteratively update the Harmony and Percussion matrix
% Hnew=H;
% Pnew=P;
% for k=1:kmax
%     
%     %4.1 Do the boundary update. Its a square
%     row=1;
%     for col=1:colLen
%         Hnew(row,col)=min(max(2*H(row,col),0),W(row,col));
%         Pnew(row,col)=W(row,col)-Hnew(row,col);
%     end
%     
%     row=rowLen;
%     for col=1:colLen
%         Hnew(row,col)=min(max(2*H(row,col),0),W(row,col));
%         Pnew(row,col)=W(row,col)-Hnew(row,col);
%     end
%     
%     col=1;
%     for row=2:rowLen-1
%         Hnew(row,col)=min(max(2*H(row,col),0),W(row,col));
%         Pnew(row,col)=W(row,col)-Hnew(row,col);
%     end
%     
%     col=colLen;
%     for row=2:rowLen-1
%         Hnew(row,col)=min(max(2*H(row,col),0),W(row,col));
%         Pnew(row,col)=W(row,col)-Hnew(row,col);
%     end
%     
%     
%     %4.2 calculate delta, update H and P
%     for col=2:colLen-1
%         for row=2:rowLen-1
%             delk=a1*(H(row,col-1)-2*H(row,col)+H(row,col+1))-a2*(P(row-1,col)-2*P(row,col)+P(row+1,col));
%             Hnew(row,col)=min(max(H(row,col)+delk,0),W(row,col));
%             Pnew(row,col)=W(row,col)-Hnew(row,col);
%         end   % end row
%     end   % end  col
%     
%     %4.3 Each iteration
%     H=Hnew;
%     P=Pnew;
%     fprintf('.');
% end   % end k
% fprintf('\n');

[H,P]=HPSS_innerLoop(H,P,W,a1,a2,kmax);

%Binarise the result
Hfinal=H;
Pfinal=P;

clear Hnew Pnew

%  disp('Binarising')
%5. Get final P and H by binarising, i.e. taking the largest magnitude of H or P
for col=1:colLen
    for row=1:rowLen
        if H(row,col) < P(row,col)
            Hfinal(row,col)=0;
            Pfinal(row,col)=W(row,col);
        else
            Hfinal(row,col)=W(row,col);
            Pfinal(row,col)=0;
        end
    end   % end row
end   % end  col


clear H P
%6. now convert back to waveform
% disp('Converting back to waveform')
omegaH=Hfinal;
omegaP=Pfinal;

update_factor=1/(2*gamma);
for row=1:size(F,1)
    for col=1:size(F,2)
        phasepart=exp(1j*angle(F(row,col)));
        omegaH(row,col)=(Hfinal(row,col)^update_factor)*phasepart;
        omegaP(row,col)=(Pfinal(row,col)^update_factor)*phasepart;
    end
end


clear F Hfinal Pfinal

% take inverse short time Fourier transformation
% disp('Computing ISTFT')
xharmony=istft(omegaH,nfft,window,noverlap);
% xpercussion=istft(omegaP,nfft,window,noverlap);
xpercussion=[];