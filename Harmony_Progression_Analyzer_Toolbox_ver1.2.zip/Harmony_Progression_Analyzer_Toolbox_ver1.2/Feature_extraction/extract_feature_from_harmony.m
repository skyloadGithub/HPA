function [chromagram, normal_chromagram, sample_times]=extract_feature_from_harmony(xharmony,tuning,SR,beat_times,options)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
%[xharmony,semisoff,resample_rate]=extract_harmony_from_audio(wavfile,options)
% 
% This function computes the loudness based features, 
% using the parameters defined in options. 
%
% INPUTS  
%         - xharmony. The harmony of the song.
%         - tuning. The tuning of the song.
%         - SR. The sample rate of the song.
%         - beat_times. The beat times (or the sample times if non-beat
%           synchronized).
%         - Options. Structure of paramters. Fields required:
%           options.display = 1: if progress is to be displayed on screen, 
%                             0: otherwise.
%         - options.fmin = minimum frequency to consider.
%         - options.fmax = maximum frequency to consider.
%         - options.resolution_fact = the resolution fact of constant Q
%           transformation. The larger the resolution_fact is, the larger
%           the windows for each frequency bin.
%           options.refLabel = the reference power for the loudness.
%               'mean' - relatvie reference power, mean of the power matrix
%               'median' - relative reference power, median of the power
%                          matrix
%               's' - the standard reference, 10^(-12) watt
%               'n' - no reference (i.e. 1 watt reference)
%               'q' - p-quantiles reference, reference depends on q_value
%         - options.q_value - for p-quantiles reference, making the q
%           percent of the lowest power frames as silence and set it as the
%           reference power.
%         - options.A_weightLabel = 1: using A-frequency-weighting;
%                                   0: otherwise.
%         - options.normFlag = 's': using shift feature;
%                              'n': using normal feature.
%
%
% OUTPUTS 
%
%         - chromagram. The chromagram feature matrix.
%         - normal_chromagram. The normalized chromagram feature matrix.
%         - sample_times. Nx2 matrix with start times (1st column) and end
%           times (2nd column) of the frames.
%  
%---------------------------------------------
%Function created by Y. Ni
%Function revised by M. McVicar
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%  1. Set default parameters %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Check for options
if isempty(options); options=struct; end
if ~isfield(options,'display'); options.display=1; end

% Feature Options
if ~isfield(options,'fmin'); options.fmin=55; end
if ~isfield(options,'fmax'); options.fmax=1661; end
if ~isfield(options,'resolution_fact'); options.resolution_fact=5; end
if ~isfield(options,'refLabel'); options.refLabel='s'; end
if ~isfield(options,'A_weightLabel'); options.A_weightLabel=1; end
if ~isfield(options,'q_value'); options.q_value=0.01; end
if ~isfield(options,'normFlag'); options.normFlag='n'; end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%  2. Loudness based chromagram  %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Only do this if desired
if options.display==1
    disp('Compuating Loudness based chromagram...')
end

%2.1 The hamming window
[hammingK,half_winLenK,freqK]=cal_hamming_window(SR, options.fmin, options.fmax,options.resolution_fact,tuning);

%2.2 Compute the chromagram features
[chromagram, normal_chromagram, sample_times]=cal_CQ_chroma_loudness(xharmony,SR, beat_times, hammingK, half_winLenK, freqK, options.refLabel, options.A_weightLabel,options.q_value,options.normFlag);

return;