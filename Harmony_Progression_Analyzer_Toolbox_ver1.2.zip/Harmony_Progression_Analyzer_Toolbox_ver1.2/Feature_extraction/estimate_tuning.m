function semisoff=estimate_tuning(d,sr,fftlen,f_ctr,f_sd)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
%semisoff = estimate_tuning(d,sr,fftlen,f_ctr,f_sd)
%
%This function calculates the semitones off from standard pitch that a wavefile is.
%uses isp_track(), Pitch track based on instantaneous frequency and
%various other things from the Labrosa team (isptoolbox)
%
%Prerquist: isp_ifptrack(...), from "LabROSA-coversongID".
%
% INPUTS 
%        - d. wavfile, mono.
%        - sr. samping rate of the wavefile
%        - fftlen. Length of fft to use
%        - f_crt. The central frequency
%        - f_sd. Bound on the frequencies to look at.
%
% OUTPUTS 
%        - semisoff. number of semitones from 440Hz tuning. Bound by [-0.5,0.5]
%
%---------------------------------------------
%Function created by M. McVicar
%Function revised by Y. Ni
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


fminl = octs2hz(hz2octs(f_ctr)-2*f_sd);
fminu = octs2hz(hz2octs(f_ctr)-f_sd);
fmaxl = octs2hz(hz2octs(f_ctr)+f_sd);
fmaxu = octs2hz(hz2octs(f_ctr)+2*f_sd);

%1. take transform. S = complex transform, p=freuqncies, m=magnitues
[p,m]=isp_ifptrack(d,fftlen,sr,fminl,fminu,fmaxl,fmaxu);

%nzp=linear index of non-zero sinusoids found.
nzp = (p(:)>0);
%Find significantly large magnitudes
gmm = (m(:) > median(m(nzp)));

%2. element-multiply large magnitudes with frequencies.
nzp = nzp .* gmm;
%get non-zero again.
nzp = find(nzp);

%3. convert to octaves
Pocts=p;
Pocts(nzp) = hz2octs(p(nzp));


%4. get tuning
nchr=12;   % size of feature

%make histo, resolution is 0.01, from -0.5 to 0.5
[hn,hx] = hist(nchr*Pocts(nzp)-round(nchr*Pocts(nzp)),-0.5:.01:.5);

%find peaks
semisoff = hx(hn == max(hn));
%if there's multiple peaks:
semisoff=semisoff(1);
end






function octs = hz2octs(freq, A440)
% octs = hz2octs(freq, A440)
% Convert a frequency in Hz into a real number counting 
% the octaves above A0. So hz2octs(440) = 4.0
% Optional A440 specifies the Hz to be treated as middle A (default 440).
% 2006-06-29 dpwe@ee.columbia.edu for fft2chromamx

if nargin < 2;   A440 = 440; end

%A4 = A440 = 440 Hz, so A0 = 440/16 Hz
octs = log(freq./(A440/16))./log(2);
end

function hz = octs2hz(octs,A440)
% hz = octs2hz(octs,A440)
% Convert a real-number octave 
% into a frequency in Hzfrequency in Hz into a real number counting 
% the octaves above A0. So hz2octs(440) = 4.0.
% Optional A440 specifies the Hz to be treated as middle A (default 440).
% 2006-06-29 dpwe@ee.columbia.edu for fft2chromamx

if nargin < 2;   A440 = 440; end

% A4 = A440 = 440 Hz, so A0 = 440/16 Hz

hz = (A440/16).*(2.^octs);

end