function anns=sample_annotations_middle(annotations,annotation_sample_times,sample_times,numStates)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
% anns = sample_annotations_middle(annotations,annotation_sample_times,sample
%        _times,numStates)
% 
% This function creates a time-sampled annotation from a list of chord
% times and window times, in a *non-beat-synchronous* way.
%
% INPUTS  
%         - annotations. A vector of states with no repetitions
%         - annotation_sample_times. A Nx2 vector of ground truth start 
%           (1st column) and end (2nd column) times.
%         - sample_times. A vector of start (1st row) and end (2nd row)
%           window times, taken from the features. These will be averaged
%           to get the window middle.
%         - numStates. An integer corresponding to the last state.
%
% OUTPUTS 
%         - anns. A vector of integers, one element per window.
%
%---------------------------------------------
%Function created by Y. Ni
%Function revised by M. McVicar
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 0. if there's only 1 chord, just sample it
if length(annotations)==1
    anns=repmat(annotations,1,length(sample_times));
else
    
    %1. Initialisation
    number_anns=length(annotation_sample_times);
    number_windows=length(sample_times);
    sampled=zeros(1,number_windows); %Store the annotations of a song
    t_anns=1;
    t_sample=1;
    
    %1.1 Get the window middle times
    sample_times=mean(sample_times,1);
    
    %1.2 For the first frame, if it is less than the start time, then no
    %chord
    while (sample_times(t_sample)<annotation_sample_times(1,1))
        sampled(t_sample)= numStates;
        t_sample=t_sample+1;
    end
    
    %1.3. Assure that t_sample falls in a chord region
    while(annotation_sample_times(t_anns,2)<sample_times(t_sample))
        t_anns=t_anns+1;
    end
    
    %2. go though all time grid
    while(t_sample<=number_windows && t_anns<=number_anns)
        %2.1 If TS(ts)<TA(ta), then this frame falls in this chord region
        if (sample_times(t_sample)<=annotation_sample_times(t_anns,2))
            sampled(t_sample)=annotations(t_anns);
            t_sample=t_sample+1;
        %2.2 Else, find the chord interval this beat falls in
        else
            while(t_anns<=number_anns && annotation_sample_times(t_anns,2)...
                    <sample_times(t_sample))
                t_anns=t_anns+1;
            end
        end
    end
    
    %3. if there are still samples left, assign no chord
    if (t_sample<=number_windows)
        sampled(t_sample:end)=numStates;
    end
    
    %4. return the annotation samples
    anns=sampled;
    
end
end