function anns=sample_annotations_beat(annotations,annotation_sample_times,sample_times,numStates)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
% anns = sample_annotations_beat(annotations,annotation_sample_times,sample_t
%        imes,numStates)
% 
% This function creates a time-sampled annotation from a list of chord
% times and beat times, in a *beat-synchronous* way.
%
% INPUTS  
%         - annotations. A vector of states with no repetitions
%         - annotation_sample_times. A Nx2 vector of ground truth start 
%           (1st column) and end (2nd column) times.
%         - sample_times. A vector of M beat times.
%         - numStates. An integer corresponding to the last state.
%
% OUTPUTS 
%         - anns. A vector of integers (length M+1), one element per window.
%
%---------------------------------------------
%Function created by Y. Ni
%Function revised by M. McVicar
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    
    %1. Initialisation 
    number_samples=size(annotation_sample_times,1);
    number_windows=length(sample_times);
    sampled=zeros(1,number_windows+1); %Store the annotations of a song
    t_anns=1;
    t_prev_anns=1;
    t_sample=1;
    
    
    %1.1 For the first frame, if it is less than the start time, then no
    %chord
    while (sample_times(t_sample)<annotation_sample_times(1,1))
        sampled(t_sample)= numStates;
        t_sample=t_sample+1;
    end
    
    %1.2 Assure that t_sample falls in a chord region
    while(annotation_sample_times(t_anns,2)<sample_times(t_sample))
        t_anns=t_anns+1;
    end
    
    %2. go though all time grid
    while(t_sample<=number_windows && t_anns<=number_samples)
        %2.1 If TS(ts)<TA(ta), then this frame falls in this chord region
        if (sample_times(t_sample)<=annotation_sample_times(t_anns,2))
            %A. if the interval between two beats has more than 1 chord
            if (t_prev_anns<t_anns)
                %Majority vote
                countInterval=1;                    
                intervalC=zeros(1,t_anns-t_prev_anns+1);
                
                %First interval
                if (t_sample==1)
                    intervalC(countInterval)=annotation_sample_times(t_prev_anns,2)-annotation_sample_times(t_prev_anns,1);
                else
                    intervalC(countInterval)=annotation_sample_times(t_prev_anns,2)-sample_times(t_sample-1);
                end
                countInterval=countInterval+1;
                
                %Between intervals
                for j=t_prev_anns+1:t_anns-1                        
                    intervalC(countInterval)=annotation_sample_times(j,2)-annotation_sample_times(j,1);                        
                    countInterval=countInterval+1;                    
                end          
                
                %Last interval
                intervalC(countInterval)=sample_times(t_sample)-annotation_sample_times(t_anns,1);      
                
                %Majority vote
                [maxInterval,maxIndex]=max(intervalC);   
                sampled(t_sample)=annotations(t_prev_anns-1+maxIndex);
                t_prev_anns=t_anns;
            %B. if the interval between two beats falls in 1 chord
            else
                sampled(t_sample)=annotations(t_anns);
            end
            t_sample=t_sample+1;
        %2.2 Else, find the chord interval this beat falls in
        else
            while(t_anns<=number_samples && annotation_sample_times(t_anns,2)<sample_times(t_sample))
                t_anns=t_anns+1;
            end
        end
    end
    
    %3. if there are still samples left, assign no chord
    if (t_sample<=number_windows)
        sampled(t_sample:end)=numStates;
    end
    
    if (t_anns==number_samples) %The last chord after final beats
        sampled(number_windows+1)=annotations(t_anns);
    elseif (t_anns<number_samples)
       countInterval=1;                    
       intervalC=zeros(1,number_samples-t_anns+1);
       %Majority vote
       intervalC(countInterval)=annotation_sample_times(t_anns,2)-sample_times(number_windows);
       countInterval=countInterval+1;
       for j=t_anns+1:number_samples
           intervalC(countInterval)=annotation_sample_times(j,2)-annotation_sample_times(j,1);
           countInterval=countInterval+1;
       end
       [maxInterval,maxIndex]=max(intervalC);
       sampled(number_windows+1)=annotations(t_anns-1+maxIndex);
    end
          
    
    %4. return the annotation samples
    anns=sampled;

        
        
