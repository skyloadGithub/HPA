function annotations =transform_annotation_labels(raw_annotations,classes,class_dict)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
%annotations=transform_annotation_labels(raw_annotations,classes,class_dict)
%
%Transforming the ground truth chords (strings) into chord classes (indices)
%
% INPUTS
%raw_annotations - the annotations (string) 
%classes         - a cell including all N unique chords, chords in cell i has the chord index i
%class_dict      - a map container including all N unique chords, chord (string)-> chord (index)
%
% OUTPUTS
%annotations     - the ground truth annotations (chord class indices)
%
%---------------------------------------------
%Function created by Y. Ni
%Function revised by M. McVicar
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Transform the chords into indices
annotations=zeros(1,length(raw_annotations));
if (iscell(class_dict))
    
    for i=1:length(raw_annotations)
        for class_index=1:length(classes)
            for class_item_index=1:length(classes{class_index})
                if (strcmp(raw_annotations{i},classes{class_index}{class_item_index}))
                    annotations(i)=class_index;
                    break;
                end
            end
            if (annotations(i)>0)
                break;
            end
        end
       
        if (annotations(i)==0) %No-chord
            error('Can not find the annotation in the class. Check!');
        end
    end
else
    for i=1:length(raw_annotations)
        if (isKey(class_dict,raw_annotations{i}))
            annotations(i)=class_dict(raw_annotations{i});
        end
        if (annotations(i)==0) %No-chord
            error('Can not find the annotation in the class. Check!');
        end
    end
end

