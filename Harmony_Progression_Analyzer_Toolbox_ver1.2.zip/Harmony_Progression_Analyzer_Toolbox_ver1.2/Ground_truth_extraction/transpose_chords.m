function [newchords,binarytable]=transpose_chords(chords, pitch, newpitch, binarytable)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function:
%[newchords,binarytable]=transpose_chords(chords, pitch, newpitch, binarytable)
%
%This function transposes chords in key "pitch" to those in a new key "newpitch".
%
% INPUTS
%chords - the chords in key pitch.
%pitch - the original key pitch.
%newpitch - the new key to transpose to.
%binarytable - the binary table (nstates x num_notes) in key pitch.
%
% OUTPUTS
%newchords - the new chords in key newpitch.
%binarytable - if new chords appear, return the new binarytable.
%
%---------------------------------------------
%Function created by M. McVicar
%Function revised by Y. Ni
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%1. configulation
pitchdiff = newpitch-pitch;

%2. transpose chords
if (pitchdiff==0)
    newchords=chords;
else
    newchords = zeros(size(chords));
    for i=1:length(chords)
        bin = binarytable(chords(i),:);   % the binary rep of the current chord
        if pitchdiff>0
            binrot = [bin(end-pitchdiff+1:end) bin(1:end-pitchdiff)];
        else
            binrot = [bin(1-pitchdiff:end) bin(1:-pitchdiff)];
        end
        newchord = findrow(binarytable,binrot);
        if length(newchord)~=1
            warning('In function transpose_chords: transposed chord not in the original binary table.')
            binarytable=[binarytable; binrot];
            newchord=size(binarytable,1);  % the new chord binary is the last row
        end
        newchords(i) = newchord;
    end
end

return;


