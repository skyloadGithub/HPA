function [class_binary,classes,class_dict]=make_quotient_sets(alphabet)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function: 
% [class_binary,classes,class_dict]=make_quotient_sets(alphabet)
%
% This function takes an alphabet of chords and makes a table containing the
% binary representation of each of these chords, as well as a
% representative of each of these classes.
%
% INPUTS 
%         - alphabet. A cell array of strings containing all N unique chords  
%           in Chris Harte format.
%        
% OUTPUTs 
%         - class_binary. A binary databse of size N-by-12 class_rep. 
%         - classes. A cell including all N unique chords, chords in cell i
%           has the chord index i.
%         - class_dict. A map container including all N unique chords. 
%           Format: chord (string)-> chord (index)
%
%---------------------------------------------
%Function created by M. McVicar
%Function revised by Y. Ni (2012 ver)
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2012
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% 1. Initialise one row for each alphabet member, and 12 pitch classes
lookup=zeros(length(alphabet),12);

%2. chord2pitchclasses runs 0-11 (we want 1-12 so add 1)
for a=1:length(alphabet)
    %For unknown chord 'X' (default, last row), set all columns as 1 (not in used)
    if (strcmp(alphabet{a}(1),'X'))
        lookup(a,:)=1;
    else
        lookup(a,1+chord2pitchclasses(alphabet{a}))=1;
    end
end  % convert each member of the alphabet to binary


%3. find indices of matching rows
%find unique rows, their first occurance and which ones they match to
[uni_rows first_occ match]=unique(lookup,'rows','first');   
uniqueinfo=[uni_rows first_occ];                          

[rows cols]=size(uniqueinfo);
uniqueinfo=sortrows(uniqueinfo,cols); % sort by first occurance

%4. run through unique rows and reconstruct a representation
classes=cell(1,size(uniqueinfo,1));
for i=1:size(uniqueinfo,1)
    % find index of repeated rows
    repeats=(find(match==match(uniqueinfo(i,end))))';  
    classes{i}=alphabet(repeats); % get chord
end   % end i

%5. get the binary for each representative
class_binary=zeros(length(classes),12);

for class=1:length(classes)
    if strcmp(classes{class}{1}(1),'X') %Non-defined class
        class_binary(class,:)=1;
    else
        class_binary(class,1+chord2pitchclasses(classes{class}{1}))=1; 
    end
end  % end class

%6. Move the no chord (class_binary=0) to the last row
if (any(class_binary(end,:)))
    for class=1:size(class_binary,1)
        if (sum(class_binary(class,:))==0)
            %A. move the binary table
            temp=class_binary(end,:);
            class_binary(end,:)=0;
            class_binary(class,:)=temp;
            
            %B. move the class index
            temp=classes{class};
            classes{class}=classes{end};
            classes{end}=temp;
            break;
        end
    end
end

%7. Create the dictionary
try
    %If the Matlab version has the map function, create the map function
    class_dict=containers.Map();
    for i=1:length(classes)
        for j=1:length(classes{i})
            class_dict(classes{i}{j})=i;
        end
    end
catch
    warning('In make_quotient_sets.m: this matlab version does not support MAP container, use classes instead.\n');
    class_dict={};
end






    