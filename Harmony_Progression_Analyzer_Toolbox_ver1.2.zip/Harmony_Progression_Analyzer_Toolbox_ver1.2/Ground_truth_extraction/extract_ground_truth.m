function Annotation=extract_ground_truth(textfile,ann_style,classes,...
    class_dict,alphabet,sample_times,sample_method)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function: 
% Annotation=extract_ground_truth(textfile,classes,class_dict,alphabet,...
%    sample_times,sample_method)
% 
% This function reads in a text file and outputs an annotation, indexed by
% binary_table. 
%
%Prerequisite: running [B,classes,class_dict]=get_global_binary_table(...)
%
% INPUTS  
%         - textfile. Name of a text (.txt) or lab (.lab) file which has
%           three columns, start time, end time, chord in CH form. 
%           Example:
%           0.000 0.123 A:maj
%           0.123 0.456 B:min7
%           ...
%         - ann_stlye. 
%           'CH':         reading a CH three column file; 
%           'sonic_vis':  a sonic visualuser two column file (under construction). 
%         - classes. The chord class dictionary (cell), 
%           return by get_global_binary_table()
%         - class_dict.  The chord class dictionary (map container), 
%           return by get_global_binary_table()
%         - alphabet. 
%           'minmaj': reduced the chords to minor and major;
%           'triads': reduced the chords to triads;
%           'quads':  reduced the chords to quads;
%           'full':   use the full complexity of the chords
%           'bass':   to extract bass annotations from chords
%           'key':    to extract key annotations from chords
%         - sample_times. A vector of start and end times (two columns), 
%           corresponding to the feature extraction.
%         - sample_method. 
%           'beatsynch': for beat synchronised sample time
%           'win_middle': for the fixed bandwidth feature sample time
%
% OUTPUTS 
%         - Annotation. A cell array of integers, one element per sample
%           time.
%
%---------------------------------------------
%Function created by M. McVicar
%Function revised by Y. Ni
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%  1. Textscan the file %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Detect annotation style
if strcmp(ann_style,'CH')
fid=fopen(textfile);
scanned_file=textscan(fid,'%f %f %s');

start_times=scanned_file{1};
end_times=scanned_file{2};
annotation_sample_times=[start_times end_times];

chords=scanned_file{3};

fclose(fid);

else
    error('In function extract_ground_truth: can not find the annotation style.');
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%  2. Filter according to the alphabet %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Detect the chord reduction 
switch alphabet
    case 'minmaj'
        %Transform the chords to CH format
        chords=transform_to_CHformat(chords);
        reduced_chords=reduce_to_minmaj(chords);
        Nstates=length(classes);
    case 'triads'
        %Transform the chords to CH format
        chords=transform_to_CHformat(chords);
        reduced_chords=reduce_to_triads(chords);
        Nstates=length(classes);
    case 'quads'
        %Transform the chords to CH format
        chords=transform_to_CHformat(chords);
        reduced_chords=reduce_to_quads(chords);
        Nstates=length(classes);
    case 'full'
        %Transform the chords to CH format
        chords=transform_to_CHformat(chords);
        reduced_chords=chords';
        Nstates=length(classes);
    case 'mm'
        reduced_chords=reduce_to_MM(chords);
        Nstates=length(classes)-1; %The last class is 'X' not 'N'
    case 'bass' 
        reduced_chords=reduce_to_bass(chords);
        Nstates=length(classes);
    case 'key'
        reduced_chords=reduce_to_key(chords);
        Nstates=length(classes);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%  3. Map to the binary table %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (strcmp(alphabet,'bass'))
    %Each component in reduced_chords is the bass note for this chord
    States=reduced_chords;
else
    %Map the chords to the rows in the binary table
    States=zeros(1,length(reduced_chords));
    
    for chord=1:length(reduced_chords)
        for class=1:length(classes)
            for r=1:length(classes{class})
                if strcmp(reduced_chords{chord},classes{class}{r})
                    States(chord)=class;
                end
            end % end r
        end % end class
    end % end chord
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%  4. Sample according to sample_times %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Sampling the annotations according to the sampling time provided by
%feature extraction
if strcmp(sample_method,'beatsynch')
    Annotation=sample_annotations_beat(States,...
        annotation_sample_times,sample_times,Nstates);
elseif strcmp(sample_method,'win_middle')
    Annotation=sample_annotations_middle(States,...
        annotation_sample_times,sample_times,Nstates);
end




