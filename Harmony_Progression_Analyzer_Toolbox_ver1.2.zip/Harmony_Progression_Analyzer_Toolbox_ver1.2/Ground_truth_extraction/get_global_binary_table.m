function [B,classes,class_dict]=get_global_binary_table(directory,format,alphabet)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Function: 
% [B,classes,class_dict]=get_global_binary_table(directory,format,alphabet)
%
% This function creates a binary table, based on all the annotations found
% in directory.
%
% INPUTS 
%         - directory. A root directory of annotations to use.
%           (if it a cell, the it is a cell of ground truth filenames).
%         - format. The suffix of the files. 'txt' or 'lab'.
%         - alphabet. 
%           'key':    extract key class dictionary;
%           'minmaj': reduced the chords to minor and major;
%           'triads': reduced the chords to triads;
%           'quads':  reduced the chords to quads;
%           'full':   use the full complexity of the chords;
%           'mm': the chord dictionary used in M. Mauch's thesis (2010);
%
% OUTPUTs 
%         - B. a binary databse of size N-by-12 class representation. 
%         - classes. A cell including all N unique chords, chords in cell i
%           has the chord index i.
%         - class_dict. A map container including all N unique chords. 
%           Format: chord (string)-> chord (index)
%
%---------------------------------------------
%Function created by M. McVicar
%Function revised by Y. Ni
%Intelligent Systems Lab
%University of Bristol
%U.K.
%2011
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%  1. Textscan the files %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%filenames=getfilenames(directory,['*.' format]);
if (iscell(directory))
    filenames=directory;  
else
    filenames=getAllFiles(directory);
end

numFiles=length(filenames);
chords=cell(1,numFiles);
for i=1:numFiles
    % 1.1 Textscan
    fid=fopen(filenames{i});
    scanned_file=textscan(fid,'%f %f %s');
    
    % 1.2 Just store the chords
    chords{i}=scanned_file{3}';
   
    fclose(fid);
end

% 1.3 Get the unique chords
all_chords=[chords{:}];
unique_chords=unique(all_chords);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%  2. Filter according to the alphabet %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

switch alphabet
    case 'key'
        %For key, it uses a pre-defined 25 classes key dictionary
        reduced_chords={'A:maj','A:min','A#:maj','A#:min','B:maj','B:min','C:maj','C:min','C#:maj','C#:min','D:maj','D:min'...
            'D#:maj','D#:min','E:maj','E:min','F:maj','F:min','F#:maj','F#:min','G:maj','G:min','G#:maj','G#:min'};
    case 'minmaj'
        unique_CH_chords=transform_to_CHformat(unique_chords);
        reduced_chords=reduce_to_minmaj(unique_CH_chords);
    case 'full'
        unique_CH_chords=transform_to_CHformat(unique_chords);
        reduced_chords=unique_CH_chords;
    case 'triads'
        unique_CH_chords=transform_to_CHformat(unique_chords);
        reduced_chords=reduce_to_triads(unique_CH_chords);
    case 'quads'
        unique_CH_chords=transform_to_CHformat(unique_chords);
        reduced_chords=reduce_to_quads(unique_CH_chords);
    case 'mm'
        [reduced_chords,reducedT_chords]=reduce_to_MM(unique_chords);
        for c=1:length(reducedT_chords)
            if (~isempty(reducedT_chords{c}))
                reduced_chords{end+1}=reducedT_chords{c};
            end
        end
end

% Get the reduced chords
reduced_chords{end+1}='N'; %add the no chord symbol
unique_reduced_chords=unique(reduced_chords);

    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%  3. Map to the binary table %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

switch alphabet
    case 'key'
        B=[];
        class_dict=containers.Map();
        classes=cell(1,length(unique_reduced_chords));
        unique_reduced_chords=sort(unique_reduced_chords);
        for i=1:length(classes)
            classes{i}=unique_reduced_chords(i);
            class_dict(classes{i}{1})=i;
        end
    otherwise
        [B,classes,class_dict]=make_quotient_sets(unique_reduced_chords);
end

return;


