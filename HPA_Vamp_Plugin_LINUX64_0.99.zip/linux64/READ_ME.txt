/*
Instruction of the Harmony Progression Analyzer (HPA) Vamp Plugin (64-bit LINUX version 0.99)
(For Automatic Chord Estimation)
*/

This is a Vamp plugin of the HPA system. It is for visualization and the target users are musicians who are less experienced with additional run-time library installation. If you would like to use the batch processing console, please try SONIC ANNOTATOR (see Sec. D) or visit https://patterns.enm.bris.ac.uk/hpa-software-package for the HPA MATLAB/Standalone packages.


/*
A. INSTALLATION
*/   

1. Download the latest (Ver 1.8 or higher) Sonic Visualizer from: http://www.sonicvisualiser.org/download.html (note that this plugin is for 64-bit LINUX version).

2. Create a folder named "vamp" in the home directory (i.e. "$HOME/vamp/"). If you are not clear about this step, see http://www.vamp-plugins.org/download.html. 

3. Copy "HPA.so" and "HPA.cat" to "$HOME/vamp/" and the folder "model" to the same directory of "Sonic Visualiser" executable. After that you should be able to find the plugin functions in the sonic visualiser (under the menu bar "Transform").

REMARK: When the first time you use the plugin, it could be 20-30 seconds slower than usual. Because it is configurating a C++ FFT module (FFTW3) in your computer. After that it will generate a "fftw_wisdom_MEASURE_precompile_plan" file in "./model" and the speed will go back to normal (Tips: please first try the chord estimation system on a short song).   


/*
B. PROBLEM SHOOTING
*/

NONE.


/*
C. FUNCTIONS
*/

REMARK: WHEN YOU USE THE FUNCTIONS, PLEASE KEEP THE "AUDIO FRAMES PER BLOCK" AND THE "WINDOW INCREMENT" (THEY ARE ADVANCED PARAMETERS) IN THE SAME LENGTH (OR SIMPLY USE THE DEFAULT). IF YOU WOULD LIKE TO SAVE THE RESULTS, SIMPLY USE THE OPTION "File->Export Annotation Layer" ON THE TOOLBAR.

The current plugin releases three functions:

1. Beat and Tempo: the automatic beat tracker that estimates the beat times of an audio clip. It returns the beat times (first column, in seconds) and the beats per minute (second column).

2. Chords: the chord module includes two STEPS
           1) the (beat-synced) loudness based chroma extraction. It extracts the beat synchronized chromagram for STEP 2).
	   2) the automatic chord estimation system (HPA) that estimates the chord sequences of an audio clip. The estimation can be in major/minor (25-chord alphabet) or complex (alphabet at the quad level) chord level. The decoder type can be HPA (default, most accurate in the experimental environment), max-Gamma or Viterbi (commonly used in automatic chord recognition). NOTE THAT THE USER SHOULD RUN STEP 1) (NO NEED TO SAVE THE RESULTS) FIRST.

3. Visualisation: the constant hop (the default hop-len is 0.09s) loudness based chromagram. It will show you the harmony progression (at pitch-class level) based on human's perception.


/*
D. SONIC ANNOTATOR
*/

If one would like to use batch processing for a set audio files, they can try the Sonic Annotator console (http://www.omras2.org/SonicAnnotator). Simply run the following command line to check what are the plugins available

"sonic-annotator -l"

An exemplary command line for extracting the beat-synced LBC feature is shown below

"sonic-annotator vamp:HPA:HPA_LBC:beat_synced_LBC -r /your/dir/to/audio/ -w csv -csv-basedir /your/dir/to/save/the/features/"

In the current version the users can apply batch processing on three plugins, i.e.
	1) vamp:HPA:beat_tracker:beat_times - to extract beat times and BPM from the audio.
	2) vamp:HPA:HPA_LBC:beat_synced_LBC - to extract beat-synced loudness based chromagram.
	3) vamp:HPA:LBC:const_hop_LBC - to extract constant-hop loudness based chromagram.
Note that the plugin vamp:HPA:HPA_ACE cannot be used in batch process. 

REMARK: Please execute "sonic-annotator" under its ROOT directory (i.e. don't execute the program using "/path_to_sonic_annotator/sonic-annotator"). This is because the HPA plugins use a relative directory "./model/" to find model parameters. 


/*
E. PROCESSING TIME AND MEMORY CONSUMPTION
*/

1. Processing time: In general, chromagram extraction (Visualisation module) takes around 1/3 of the duration of a music track; automatic chord estimation (Chords module) takes between 1/4 to 1/3 of the duration of a music track; and the beat tracker (Beat and Tempo module) only takes seconds.

2. Memory consumption: In the experiments, the peak memory consumption for an 8-minute music track is ~800M, while that for a 4-minute song is ~320M.


/*
F. CREDITS
*/

HPA is free software under the terms of the Creative Commons Attribution-NonCommercial as published by the Free Software Foundation; either version 3.0 of the License, or (at your option) any later version.

HPA also makes use of the following libraries:

 * FFTW3 -- Copyright Matteo Frigo and MIT, GPL
 * Vamp plugin SDK -- Copyright Chris Cannam, BSD license
 * Resample template -- Copyright Motorola, Inc., See COPY_RIGHT.txt. 

Many thanks to their authors and the authors of the HPA's infrastructures specified in
"Y. Ni, M. Mcvicar, R. Santos-Rodriguez, and T. De Bie. An end-to-end machine learning system for harmonic analysis of music. IEEE Transactions on Audio, Speech and Language Processing, 20(5):1771-1783, 2012. "


/*
G. CONTACT
*/ 

For any problem w.r.t. this plugin, please contact

===========================================
Y. NI
Intelligent Systems Laboratory 
Department of Engineering Mathematics
University of Bristol
Email: Yizhao.NI@googlemail.com
===========================================
