//Define the dictionary label for the output
const char* bass_dictionary[13]={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B",""};
