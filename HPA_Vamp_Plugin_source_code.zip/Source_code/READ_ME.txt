/*
Source of the Harmony Progression Analyzer (HPA) Vamp Plugin
*/

The package includes the HPA source code released under GPL. It includes most function modules of HPA expect the external libraries FFTW and Vamp-SDK (mostly head files). The users can download the two libraries from:

FFTW: http://www.fftw.org/
Vamp-SDK: http://www.vamp-plugins.org/develop.html

The user needs to compile the two libraries and link them to the source. 


/*
CONTACT
*/ 

For any problem w.r.t. this plugin, please contact

===========================================
Y. NI
Intelligent Systems Laboratory 
Department of Engineering Mathematics
University of Bristol
Email: Yizhao.NI@googlemail.com
===========================================
